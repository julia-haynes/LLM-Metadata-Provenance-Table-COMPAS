import asyncio, re
from playwright.async_api import async_playwright

CHECK = """() => {
  const r = {hscroll: document.documentElement.scrollWidth - document.documentElement.clientWidth};
  const clip = [], overlap = [];
  const vis = el => el.offsetParent !== null && el.getClientRects().length;
  document.querySelectorAll('div,td,th,span,p').forEach(el=>{
    if (!vis(el)) return;
    if (el.classList.contains('badges')) return;  // intentionally collapsed, has a visible toggle
    const cs = getComputedStyle(el);
    if ((el.scrollHeight - el.clientHeight > 2 || el.scrollWidth - el.clientWidth > 2)
        && cs.overflow !== 'visible' && cs.overflowY !== 'auto' && cs.overflowY !== 'scroll'
        && cs.overflowX !== 'auto' && cs.overflowX !== 'scroll')
      clip.push(el.className + ' | ' + (el.textContent||'').trim().slice(0,45));
  });
  r.clip = clip.slice(0,8); r.nClip = clip.length;
  // row-band overlap: any two sibling rows whose boxes intersect vertically by >2px
  const rows = [...document.querySelectorAll('.row,.frow,.prow')].filter(vis);
  for (let i=1;i<rows.length;i++){
    const a = rows[i-1].getBoundingClientRect(), b = rows[i].getBoundingClientRect();
    if (a.bottom - b.top > 2 && Math.abs(a.left-b.left) < 5) overlap.push(i);
  }
  r.nOverlap = overlap.length;
  r.visibleCells = document.querySelectorAll('.cell,.vc,.fq').length;
  return r;
}"""

async def run():
    fails = []
    async with async_playwright() as p:
        b = await p.chromium.launch()
        for w in (1280, 1700):
            pg = await b.new_page(viewport={'width': w, 'height': 900})
            errs = []
            pg.on('pageerror', lambda e: errs.append('pageerror: ' + str(e)))
            pg.on('console', lambda m: errs.append('console: ' + m.text)
                  if m.type == 'error' and 'ERR_TUNNEL' not in m.text and 'fonts' not in m.text.lower() else None)
            await pg.goto('file:///home/claude/ledger/pop_synth_ledger.html')
            await pg.wait_for_timeout(1000)
            n = await pg.eval_on_selector_all('.tbtn', 'e=>e.length')
            print(f"=== {w}px ({n} tabs)")
            for i in range(n):
                label = await pg.eval_on_selector_all('.tbtn', f'e=>e[{i}].textContent.trim()')
                await pg.eval_on_selector_all('.tbtn', f'e=>e[{i}].click()')
                await pg.wait_for_timeout(450)
                r = await pg.evaluate(CHECK)
                ok = r['hscroll'] <= 0 and r['nClip'] == 0 and r['nOverlap'] == 0
                print(f"  [{'ok ' if ok else 'BAD'}] {label:<22} hscroll={r['hscroll']:<4} clipped={r['nClip']:<3} overlap={r['nOverlap']:<3} cells={r['visibleCells']}")
                if r['clip']: print("        ", r['clip'][:3])
                if not ok: fails.append((w, label))
            # full parameter list panel
            await pg.eval_on_selector_all('.fullbtn', 'e=>e[0].click()')
            await pg.wait_for_timeout(1200)
            r = await pg.evaluate(CHECK)
            ok = r['hscroll'] <= 0 and r['nClip'] == 0 and r['nOverlap'] == 0
            print(f"  [{'ok ' if ok else 'BAD'}] {'FULL LIST':<22} hscroll={r['hscroll']:<4} clipped={r['nClip']:<3} overlap={r['nOverlap']:<3} cells={r['visibleCells']}")
            if r['clip']: print("        ", r['clip'][:3])
            if not ok: fails.append((w, 'FULL LIST'))
            print(f"  jsErrors={len(errs)}")
            for e in errs[:4]: print("   ", e)
            if errs: fails.append((w, 'js'))
            await pg.close()
        await b.close()
    print("\nAUDIT:", "FAIL " + str(fails) if fails else "CLEAN — 0 h-scroll, 0 clipped, 0 overlaps, 0 JS errors")

asyncio.run(run())
