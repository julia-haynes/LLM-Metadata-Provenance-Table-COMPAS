# -*- coding: utf-8 -*-
"""Spreadsheet output: one column group per paper, sized to however many exist."""
import re
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

NS = "NOT SPECIFIED"
TAG = re.compile(r'<[^>]+>')


def plain(s):
    s = str(s).replace('<br>', ' \n').replace('<br/>', ' \n')
    s = TAG.sub('', s)
    for a, b in [('&amp;', '&'), ('&mdash;', '—'), ('&ndash;', '–'), ('&middot;', '·'),
                 ('&nbsp;', ' '), ('&le;', '≤'), ('&ge;', '≥'), ('&minus;', '−'),
                 ('&gamma;', 'γ'), ('&beta;', 'β'), ('&#9737;', '☉'), ('&rsquo;', '’'),
                 ('&ldquo;', '“'), ('&rdquo;', '”')]:
        s = s.replace(a, b)
    return re.sub(r'[ \t]+', ' ', s).strip()


HDR = PatternFill('solid', fgColor='1F2A3E')
NSF = PatternFill('solid', fgColor='F2F2F2')
SAME = PatternFill('solid', fgColor='DFF3E4')
DIFFF = PatternFill('solid', fgColor='FBE0E4')
ONLY = PatternFill('solid', fgColor='FBF2D6')
WHITE = Font(color='FFFFFF', bold=True, size=10)
NSFONT = Font(color='808080', italic=True, size=10)
QFONT = Font(size=9, italic=True, color='444444')
THIN = Side(style='thin', color='D0D4DA')
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

FILLER = set('the a an of in to and or for with at on from by is are be as not no all et al see '
             'sec eq fig p pp this that its'.split())


def toks(s):
    return {t for t in re.split(r'[^a-z0-9.\-]+', plain(s).lower()) if len(t) > 1 and t not in FILLER}


def equiv(a, b):
    A, B = toks(a), toks(b)
    if not A or not B:
        return False
    sh = len(A & B)
    return sh >= 3 or (sh >= 2 and sh >= 0.5 * min(len(A), len(B)))


def status_of(values):
    """values: list of (pid, value). Returns (label, {pid: fill})."""
    stated = [(p, v) for p, v in values if not str(v).startswith(NS)]
    fill = {p: NSF for p, _ in values}
    if not stated:
        return 'NOT SPECIFIED in any', fill
    if len(stated) == 1:
        fill[stated[0][0]] = ONLY
        return 'Stated in one paper only', fill
    clusters = []
    for p, v in stated:
        hit = next((c for c in clusters if any(equiv(v, ov) for _, ov in c)), None)
        (hit if hit is not None else clusters.append([]) or clusters[-1]).append((p, v))
    if len(clusters) == 1:
        for p, _ in stated:
            fill[p] = SAME
        return 'All stated — same', fill
    if all(len(c) == 1 for c in clusters):
        for p, _ in stated:
            fill[p] = DIFFF
        return 'All stated — DIFFERENT', fill
    big = max(clusters, key=len)
    bigp = {p for p, _ in big}
    for p, _ in stated:
        fill[p] = SAME if p in bigp else DIFFF
    return 'Mixed — pairwise agreement', fill


def _hdr(ws, headers, tints=None):
    ws.append(headers)
    for i, _ in enumerate(headers, 1):
        c = ws.cell(row=1, column=i)
        c.font = WHITE
        c.fill = (tints or {}).get(i, HDR)
        c.alignment = Alignment(vertical='center', wrap_text=True)
    ws.row_dimensions[1].height = 42


def build(mods, flagrows, SECTIONS, n_quotes, param_desc=None, out='pop_synth_ledger_parameters.xlsx'):
    param_desc = param_desc or {}
    papers = [m.PAPER for m in mods]
    pfill = {p['id']: PatternFill('solid', fgColor=_tint(p['colour'])) for p in papers}
    wb = openpyxl.load_workbook('ref.xlsx')

    # ── Core ledger ────────────────────────────────────────────────────────
    ws = wb.create_sheet('Core Ledger', 1)
    heads = ['§', 'Section', 'Parameter', 'What the parameter is', 'Status']
    tints = {}
    for p in papers:
        base = len(heads)
        heads += [f"{p['label']} — value", f"{p['label']} — description",
                  f"{p['label']} — source", f"{p['label']} — VERBATIM QUOTE"]
        for k in range(base + 1, base + 5):
            tints[k] = PatternFill('solid', fgColor=p['colour'].lstrip('#'))
    _hdr(ws, heads, tints)

    r = 2
    for num, title, colour, params in SECTIONS:
        for name in params:
            vals = []
            for m in mods:
                e = m.ENTRIES.get(name) or dict(value=NS, desc='', src='—', quote='')
                vals.append((m.PAPER['id'], plain(e.get('value', NS))))
            label, fill = status_of(vals)
            row = [f'§{num}', plain(title), plain(name), plain(param_desc.get(name, '')), label]
            for m in mods:
                e = m.ENTRIES.get(name) or dict(value=NS, desc='', src='—', quote='', num={})
                q = e.get('quote', '')
                if not q and str(e.get('value', NS)).startswith(NS) and getattr(m, 'DEFERRAL', ''):
                    dsrc = getattr(m, 'DEFERRAL_SRC', '')
                    q = ('[paper-level scope statement, not this row'
                         + (' — ' + dsrc if dsrc else '') + '] ' + m.DEFERRAL)
                nm = {} if str(e.get('value', NS)).startswith(NS) else (e.get('num') or {})
                prim = e.get('primary') or (list(nm)[0] if len(nm) == 1 else None)
                desc = plain(e.get('desc', ''))
                if prim and prim in nm:
                    # numeric row: the cell is a real number, the prose moves to the description
                    val = nm[prim]
                    extra = ' (' + prim + '; others in the Numeric Values sheet)' if len(nm) > 1 else ' (' + prim + ')'
                    desc = 'Stated as: ' + plain(e.get('value', NS)) + extra + '\n' + desc
                elif nm:
                    val = '\n'.join(f'{k} = {v:g}' for k, v in nm.items())
                    desc = 'Stated as: ' + plain(e.get('value', NS)) + '\n' + desc
                else:
                    val = plain(e.get('value', NS))
                row += [val, desc, plain(e.get('src', '—')), q]
            for i, v in enumerate(row, 1):
                c = ws.cell(row=r, column=i, value=v)
                c.alignment = Alignment(vertical='top', wrap_text=not isinstance(v, (int, float)))
                c.border = BORDER
                c.font = Font(size=10)
            for j, m in enumerate(mods):
                vc = 6 + 4 * j
                cell = ws.cell(row=r, column=vc)
                cell.fill = fill[m.PAPER['id']]
                if isinstance(cell.value, (int, float)):
                    cell.font = Font(bold=True, size=11, name='Consolas')
                    cell.alignment = Alignment(vertical='top', horizontal='right')
                elif str(cell.value).startswith(NS):
                    cell.font = NSFONT
                else:
                    cell.font = Font(bold=True, size=10)
                ws.cell(row=r, column=vc + 3).font = QFONT
            r += 1
    widths = [5, 24, 32, 46, 26]
    for _ in papers:
        widths += [26, 62, 20, 62]
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = 'F2'
    ws.auto_filter.ref = f"A1:{get_column_letter(len(heads))}{r-1}"

    # ── Papers (what each paper is and did) ────────────────────────────────
    ws = wb.create_sheet('Papers', 1)
    _hdr(ws, ['Paper', 'Citation', 'arXiv / journal', 'Link to the paper', 'Code', 'Version',
              'Systems covered', 'Systems covered — detail', 'Purpose of the paper',
              'What the model did', 'Cite these (works the result rests on)',
              'Full title', 'Data / code', 'Scope statement (verbatim)'])
    for i, m in enumerate(mods, start=2):
        p = m.PAPER
        cites = '\n'.join(f'{c[0]} — {c[1]}\n    {c[2]}' for c in getattr(m, 'CITATIONS', []))
        vals = [p.get('label', ''), p.get('cite', ''), p.get('arxiv', ''),
                getattr(m, 'PAPER_URL', ''),
                p.get('code_name', ''), p.get('code_version', ''),
                p.get('systems', ''), p.get('systems_detail', ''), p.get('purpose', ''),
                p.get('summary', ''), cites, p.get('title', ''), p.get('extra', ''),
                getattr(m, 'DEFERRAL', '')]
        for j, v in enumerate(vals, 1):
            c = ws.cell(row=i, column=j, value=v)
            c.alignment = Alignment(vertical='top', wrap_text=True)
            c.border = BORDER
            c.font = QFONT if j == 14 else Font(size=10)
        ws.cell(row=i, column=1).fill = pfill[p['id']]
        ws.cell(row=i, column=1).font = Font(bold=True, size=10)
        ws.row_dimensions[i].height = 150
    for i, w in enumerate([18, 24, 26, 42, 12, 14, 24, 60, 60, 90, 90, 60, 40, 60], 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = 'B2'

    # ── Numeric values (tidy: one row per number, ready to pivot) ──────────
    ws = wb.create_sheet('Numeric Values', 2)
    _hdr(ws, ['Paper', 'Code version', 'Systems', '§', 'Section', 'Parameter',
              'Quantity', 'Value', 'Is a stated value', 'Source in paper'])
    r = 2
    for num, title, colour, params in SECTIONS:
        for name in params:
            for m in mods:
                e = m.ENTRIES.get(name) or {}
                stated = not str(e.get('value', NS)).startswith(NS)
                for k, v in (e.get('num') or {}).items():
                    vals = [m.PAPER['label'], m.PAPER.get('code_version', ''),
                            m.PAPER.get('systems', ''), f'§{num}', plain(title),
                            plain(name), k, v, 'yes' if stated else 'context only',
                            plain(e.get('src', ''))]
                    for j, val in enumerate(vals, 1):
                        c = ws.cell(row=r, column=j, value=val)
                        c.alignment = Alignment(vertical='top', wrap_text=(j in (5, 6, 10)))
                        c.border = BORDER
                        c.font = Font(size=10)
                    ws.cell(row=r, column=1).fill = pfill[m.PAPER['id']]
                    ws.cell(row=r, column=7).font = Font(size=10, name='Consolas')
                    ws.cell(row=r, column=8).font = Font(size=10, bold=True)
                    r += 1
    for i, w in enumerate([18, 14, 24, 5, 24, 34, 34, 16, 16, 22], 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = 'G2'
    ws.auto_filter.ref = f"A1:J{r-1}"

    # ── Quote index (audit sheet) ──────────────────────────────────────────
    ws = wb.create_sheet('Quote Index', 3)
    _hdr(ws, ['Paper', 'Where', 'Key', 'Verbatim quote (checked against the PDF text at build time)'])
    r = 2
    for m in mods:
        pid, lab = m.PAPER['id'], m.PAPER['label']
        items = [('DEFERRAL', 'scope statement', getattr(m, 'DEFERRAL', ''))]
        items += [('ENTRIES', k, e.get('quote', '')) for k, e in m.ENTRIES.items()]
        items += [('FLAGS', '--' + k, e.get('quote', '')) for k, e in getattr(m, 'FLAGS', {}).items()]
        for g, cards in getattr(m, 'SUBMODELS', []):
            items += [('SUBMODELS', c[0], c[6] if len(c) > 6 else '') for c in cards]
        items += [('COSMIC', x[0], x[4] if len(x) > 4 else '') for x in getattr(m, 'COSMIC', [])]
        for where, key, q in items:
            if not q:
                continue
            for i, v in enumerate([lab, where, plain(key), q], 1):
                c = ws.cell(row=r, column=i, value=v)
                c.alignment = Alignment(vertical='top', wrap_text=True)
                c.border = BORDER
                c.font = Font(size=10) if i < 4 else QFONT
            ws.cell(row=r, column=1).fill = pfill[pid]
            r += 1
    for i, w in enumerate([20, 16, 40, 100], 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = 'B2'
    ws.auto_filter.ref = f"A1:D{r-1}"

    # ── Sub-models ─────────────────────────────────────────────────────────
    ws = wb.create_sheet('Sub-Models', 4)
    _hdr(ws, ['Paper', 'Group', 'Panel / variation', 'What changed', 'Fiducial',
              'Alternative(s)', 'Effect / notes', 'Source', 'Verbatim quote'])
    r = 2
    for m in mods:
        for g, cards in getattr(m, 'SUBMODELS', []):
            for c in cards:
                vals = [m.PAPER['label'], plain(g), plain(c[0]), plain(c[1]),
                        plain(c[2]).replace('Fid:', '').strip(),
                        plain(c[3]).replace('Alt:', '').strip(),
                        plain(c[4]), plain(c[5]), c[6] if len(c) > 6 else '']
                for i, v in enumerate(vals, 1):
                    cell = ws.cell(row=r, column=i, value=v)
                    cell.alignment = Alignment(vertical='top', wrap_text=True)
                    cell.border = BORDER
                    cell.font = QFONT if i == 9 else Font(size=10)
                ws.cell(row=r, column=1).fill = pfill[m.PAPER['id']]
                ws.cell(row=r, column=5).fill = SAME
                ws.cell(row=r, column=6).fill = DIFFF
                r += 1
    for i, w in enumerate([20, 34, 24, 30, 32, 32, 62, 20, 56], 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = 'C2'

    # ── Cosmic integration ─────────────────────────────────────────────────
    ws = wb.create_sheet('Cosmic Integration', 5)
    _hdr(ws, ['Paper', 'Parameter', 'Value', 'Description', 'Source', 'Verbatim quote'])
    r = 2
    for m in mods:
        for x in getattr(m, 'COSMIC', []):
            vals = [m.PAPER['label'], x[0], x[1], x[2], x[3], x[4] if len(x) > 4 else '']
            for i, v in enumerate(vals, 1):
                c = ws.cell(row=r, column=i, value=plain(v) if i < 6 else v)
                c.alignment = Alignment(vertical='top', wrap_text=True)
                c.border = BORDER
                c.font = QFONT if i == 6 else Font(size=10)
            ws.cell(row=r, column=1).fill = pfill[m.PAPER['id']]
            r += 1
    for i, w in enumerate([20, 26, 30, 62, 24, 56], 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = 'C2'

    # ── extend the two reference sheets ────────────────────────────────────
    idx = {r_['par']: r_ for r_ in flagrows}
    for name in ['Physical Parameters', 'Administrative & Output']:
        ws = wb[name]
        col = 7
        for p in papers:
            for suffix in ['value', 'evidence', 'VERBATIM QUOTE']:
                c = ws.cell(row=1, column=col, value=f"{p['label']} — {suffix}")
                c.font = WHITE
                c.fill = PatternFill('solid', fgColor=p['colour'].lstrip('#'))
                c.alignment = Alignment(vertical='center', wrap_text=True)
                col += 1
        for c in range(1, 7):
            cell = ws.cell(row=1, column=c)
            cell.font = WHITE
            cell.fill = HDR
            cell.alignment = Alignment(vertical='center', wrap_text=True)
        ws.row_dimensions[1].height = 42
        for rr in range(2, ws.max_row + 1):
            par = ws.cell(row=rr, column=2).value or ''
            src = idx.get(par)
            col = 7
            for p in papers:
                v = (src['v'][p['id']] if src else [NS, '', ''])
                for k, val in enumerate(v):
                    cell = ws.cell(row=rr, column=col, value=val)
                    cell.alignment = Alignment(vertical='top', wrap_text=True)
                    cell.border = BORDER
                    if k == 0:
                        if str(val).startswith(NS):
                            cell.fill = NSF
                            cell.font = NSFONT
                        else:
                            cell.fill = pfill[p['id']]
                            cell.font = Font(bold=True, size=10)
                    else:
                        cell.font = QFONT if k == 2 else Font(size=9, color='555555')
                    col += 1
            for c in range(1, 7):
                ws.cell(row=rr, column=c).alignment = Alignment(vertical='top', wrap_text=True)
        for i, w in enumerate([30, 34, 14, 24, 30, 54], 1):
            ws.column_dimensions[get_column_letter(i)].width = w
        col = 7
        for _ in papers:
            for w in [28, 40, 52]:
                ws.column_dimensions[get_column_letter(col)].width = w
                col += 1
        ws.freeze_panes = 'C2'
        ws.auto_filter.ref = f"A1:{get_column_letter(col-1)}{ws.max_row}"

    _readme(wb, papers, flagrows, n_quotes, mods)
    wb.save(out)
    return out


def _tint(hexcolour):
    h = hexcolour.lstrip('#')
    r, g, b = (int(h[i:i + 2], 16) for i in (0, 2, 4))
    mix = lambda v: format(int(v + (255 - v) * 0.80), '02x')
    return mix(r) + mix(g) + mix(b)


def _readme(wb, papers, flagrows, n_quotes, mods=()):
    ws = wb['Read Me']
    start = ws.max_row + 2
    n_spec = sum(1 for r in flagrows if any(v[0] != NS for v in r['v'].values()))
    lines = [
        "",
        "═══ PAPER ASSUMPTION COLUMNS (generated by build.py) ═══",
        "",
        f"Papers in this workbook ({len(papers)}):",
    ]
    for p in papers:
        lines.append(f"  · {p['cite']} — {p['arxiv']}")
        lines.append(f"      {p.get('code_name','')} {p.get('code_version','')} — systems: {p.get('systems','')}")
        lines.append(f"      purpose: {p.get('purpose','')}")
    lines += [
        "",
        "Three columns are added per paper to 'Physical Parameters' and 'Administrative & Output':",
        "  value | evidence (where it is stated) | VERBATIM QUOTE",
        "",
        "Filling rule (applied strictly):",
        "  - A value appears ONLY if the paper states it in its own text, table, equation or figure.",
        "  - Anything the paper does not state is written as 'NOT SPECIFIED' — never inferred from",
        "    COMPAS defaults, from another paper, or from the works a paper cites.",
        "",
        "Verbatim quotes:",
        f"  Every quote in this workbook ({n_quotes} of them) is checked against the paper's own extracted",
        "  text at build time; the build fails if a quote is not literally present. They are chosen to be",
        "  prose-only so they can be pasted straight into Ctrl-F in the PDF. See the 'Quote Index' sheet",
        "  for the full list in one place.",
        "  A NOT SPECIFIED cell carries the paper's own scope statement instead — the sentence explaining",
        "  why that whole class of parameters is absent.",
        "",
        "Sheets:",
        "  Papers             - one row per paper: code and version, which systems the simulation covers,",
        "                       the purpose of the paper, and what the model actually did.",
        "  Numeric Values     - TIDY NUMBERS FOR ANALYSIS. One row per (paper, parameter, quantity, value),",
        "                       so it pivots directly. Quantity keys carry their unit in the name, e.g.",
        f"                       IMF_M_min_Msun, R_z0.2_stable_Gpc3_yr, zeta_ad_HG. {sum(len(e.get('num') or {}) for m in mods for e in m.ENTRIES.values())} numbers in total.",
        "  Core Ledger        - the 10-section ledger structure, one column group per paper, with a Status",
        "                       column (all same / all different / mixed / one paper only / none) and a",
        "                       'What the parameter is' definition column. Where a paper states a number",
        "                       for a parameter, its value cell IS that number - written as a real Excel",
        "                       number, not text - and the paper's own wording moves to the top of the",
        "                       description cell after 'Stated as:'. Non-numeric parameters keep prose.",
        "  Quote Index        - every verbatim quote in one place, for auditing.",
        "  Sub-Models         - the variation grid each paper explores around its fiducial model.",
        "  Cosmic Integration - S(Z,z), SFRD and cosmology inputs; not COMPAS --flags, so no row above.",
        "",
        f"Coverage: {n_spec} of {len(flagrows)} COMPAS flags are pinned down by at least one paper.",
        "",
        "Adding a paper:",
        "  cp papers/_TEMPLATE.py papers/<id>.py, fill it in, put the paper's pdftotext output beside it,",
        "  and run: python3 build.py.  Every output here resizes itself. Designed for up to 25 papers.",
        "",
        "Caveat on the Default column:",
        "  The existing 'Default' column reflects repository commit 5f7cc502 (2026-08-20), NOT the defaults",
        "  of the COMPAS versions used by these papers. Do not read it as any paper's assumption.",
    ]
    for i, line in enumerate(lines):
        c = ws.cell(row=start + i, column=1, value=line)
        if line.startswith("═══"):
            c.font = Font(bold=True, size=11, color='1A4B6E')
        elif line.endswith(":"):
            c.font = Font(bold=True, size=10)
    ws.column_dimensions['A'].width = 118
