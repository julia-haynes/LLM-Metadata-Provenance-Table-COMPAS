# -*- coding: utf-8 -*-
"""Row skeleton of the ledger. Paper-independent: adding a paper does not touch this file."""

SECTIONS = [
  ("1", "INITIAL STELLAR POPULATION", "#c8563a", [
    'Primary mass function (IMF)',
    'Mass ratio distribution',
    'Initial orbital separation / period distribution',
    'Initial eccentricity distribution',
    'Initial stellar rotation',
    'Binary fraction',
    'Metallicity sampling / grid',
    'Solar metallicity reference',
    'Chemically homogeneous evolution (CHE / QHE) treatment',
    'Sample size',
  ]),
  ("2", "STELLAR EVOLUTION &amp; WINDS", "#b56e28", [
    'Stellar evolution framework',
    'Core overshooting',
    'Hot star / OB-type winds',
    'Cool star winds / Reimers η',
    'Wolf–Rayet / He-star winds',
    'LBV / Eddington-limited winds',
    'Stellar track mass range',
  ]),
  ("3", "MASS TRANSFER &amp; ROCHE LOBE OVERFLOW", "#a08a10", [
    'Roche lobe radius',
    'Mass transfer stability criterion',
    'Accretion efficiency (RLOF)',
    'Accretion limit — BH accretor / Eddington multiplier',
    'Angular momentum loss (non-conservative MT)',
    'Orbit circularisation',
    'AIC (accretion-induced collapse)',
    'Ultra-stripped SN',
  ]),
  ("4", "COMMON ENVELOPE (CE) EVOLUTION", "#3a8a50", [
    'CE energy formalism',
    'CE efficiency (α_CE)',
    'Envelope binding energy (λ_CE)',
    'HG donor CE survival / merger condition',
    'Case BB mass transfer handling',
  ]),
  ("5", "SUPERNOVAE &amp; COMPACT REMNANTS", "#2a7a8a", [
    'Remnant mass prescription',
    'NS mass distribution',
    'Pulsational pair-instability SN (PPISN)',
    'ECSN mass thresholds',
    'Maximum NS mass',
    'Neutrino mass loss correction',
    'BH natal kick',
    'BH spin / NS radius',
  ]),
  ("6", "NATAL KICKS", "#3a60a8", [
    'Core-collapse SN kick σ',
    'Low-kick σ (ECSN / USSN / AIC)',
    'Kick mass scaling',
    'Kick direction',
  ]),
  ("7", "TIDES &amp; ORBITAL EVOLUTION", "#6a45a8", [
    'Stellar tides',
    'GW inspiral',
    'Angular momentum loss (γ)',
    'Stellar merger outcome',
  ]),
  ("8", "WHITE DWARF / COMPACT OBJECT PHYSICS", "#a83880", [
    'WD cooling / accretion &amp; collapse',
    'Nova efficiency',
    'Magnetic braking',
    'Rejuvenation (post-accretion mixing)',
  ]),
  ("9", "COSMOLOGICAL MODEL &amp; STAR FORMATION RATE", "#7a7a30", [
    'Cosmological parameters',
    'Metallicity-dependent SFRD',
    'Local merger rate density',
  ]),
  ("10", "KEY ASTROPHYSICAL RESULTS &amp; CHANNELS", "#3a7898", [
    'Formation channel split',
    'Headline quantitative result',
    'Mass-distribution features',
    'Sensitivity of the result',
    'Orbital outcome of stable MT',
    'Implication flagged by the authors',
  ]),
]

ALL_PARAMS = [p for _,_,_,ps in SECTIONS for p in ps]

# ─────────────────────────────────────────────────────────────────────────────
# What each ledger row MEANS, independent of any paper. Shown under the
# parameter name in the table and as its own column in the spreadsheet.
# ─────────────────────────────────────────────────────────────────────────────
PARAM_DESC = {
 # §1
 'Primary mass function (IMF)': 'Distribution the more massive (primary) ZAMS mass is drawn from, and its mass limits.',
 'Mass ratio distribution': 'Distribution of q = M2/M1 at ZAMS, and any floor imposed on the secondary mass.',
 'Initial orbital separation / period distribution': 'Distribution of initial semi-major axis or orbital period, and its range.',
 'Initial eccentricity distribution': 'Distribution of orbital eccentricity at ZAMS.',
 'Initial stellar rotation': 'Initial rotation rates assigned to the components, if any.',
 'Binary fraction': 'Fraction of systems that are binaries, and how single stars are handled in the normalisation.',
 'Metallicity sampling / grid': 'How metallicity is sampled: discrete grid or smooth distribution, and over what range.',
 'Solar metallicity reference': 'Numerical value of Z_sun adopted, which sets the scale for every Z/Z_sun statement.',
 'Chemically homogeneous evolution (CHE / QHE) treatment': 'Whether rotationally mixed, chemically homogeneous evolution is modelled, and under what rule.',
 'Sample size': 'Number of binaries evolved, and how they were sampled.',
 # §2
 'Stellar evolution framework': 'The code, its version, and the underlying single-star evolution models or fitting formulae.',
 'Core overshooting': 'Convective overshooting treatment, which sets core masses and therefore remnant masses.',
 'Hot star / OB-type winds': 'Line-driven wind mass-loss prescription for hot, massive main-sequence and supergiant stars.',
 'Cool star winds / Reimers η': 'Wind prescription for cool giants, usually a Reimers-type law with efficiency eta.',
 'Wolf–Rayet / He-star winds': 'Wind mass loss for stripped helium stars, which sets the final pre-collapse core mass.',
 'LBV / Eddington-limited winds': 'Enhanced mass loss near the Eddington limit / in the luminous blue variable regime.',
 'Stellar track mass range': 'Mass range over which stellar tracks are computed or interpolated.',
 # §3
 'Roche lobe radius': 'Formula used for the volume-equivalent Roche-lobe radius that sets the onset of RLOF.',
 'Mass transfer stability criterion': 'Rule deciding whether RLOF is dynamically stable: a zeta comparison, a critical mass ratio, or both.',
 'Accretion efficiency (RLOF)': 'Fraction beta of transferred mass actually accreted; the rest leaves the system.',
 'Accretion limit — BH accretor / Eddington multiplier': 'Cap on accretion onto a compact object, usually a multiple of the Eddington rate.',
 'Angular momentum loss (non-conservative MT)': 'Where non-accreted matter leaves from, and how much orbital angular momentum it carries.',
 'Orbit circularisation': 'Whether and when an eccentric orbit is circularised at the onset of mass transfer.',
 'AIC (accretion-induced collapse)': 'Treatment of a white dwarf collapsing to a neutron star after accreting past its limit.',
 'Ultra-stripped SN': 'Treatment of supernovae from heavily stripped helium stars in close binaries.',
 # §4
 'CE energy formalism': 'The formalism used to decide the outcome of a common envelope, typically alpha-lambda energy balance.',
 'CE efficiency (α_CE)': 'Efficiency with which orbital energy is used to unbind the envelope.',
 'Envelope binding energy (λ_CE)': 'Structure parameter setting how tightly the envelope is bound.',
 'HG donor CE survival / merger condition': 'Whether a Hertzsprung-gap donor entering a CE is assumed to merge (pessimistic) or can survive (optimistic).',
 'Case BB mass transfer handling': 'Stability treatment of late mass transfer from a helium star onto a compact object.',
 # §5
 'Remnant mass prescription': 'Mapping from pre-collapse core mass to compact remnant mass.',
 'NS mass distribution': 'Distribution of neutron star birth masses.',
 'Pulsational pair-instability SN (PPISN)': 'Treatment of pulsational mass loss that caps black hole masses below the pair-instability gap.',
 'ECSN mass thresholds': 'Core-mass boundaries for electron-capture supernovae.',
 'Maximum NS mass': 'Mass above which a remnant is treated as a black hole rather than a neutron star.',
 'Neutrino mass loss correction': 'Mass removed in neutrinos during collapse, applied on top of the remnant prescription.',
 'BH natal kick': 'Kick imparted to a black hole at formation, and whether it is reduced by fallback.',
 'BH spin / NS radius': 'Birth spin assigned to black holes, or the radius / equation of state assumed for neutron stars.',
 # §6
 'Core-collapse SN kick σ': 'Dispersion of the Maxwellian natal kick distribution for standard core-collapse supernovae.',
 'Low-kick σ (ECSN / USSN / AIC)': 'Separate, smaller kick dispersion for electron-capture, ultra-stripped and AIC events.',
 'Kick mass scaling': 'How the kick magnitude is scaled with ejecta mass, remnant mass or fallback fraction.',
 'Kick direction': 'Angular distribution of the natal kick relative to the orbit.',
 # §7
 'Stellar tides': 'Tidal synchronisation and circularisation treatment.',
 'GW inspiral': 'Prescription for orbital decay by gravitational-wave emission, and when it is switched on.',
 'Angular momentum loss (γ)': 'Specific angular momentum carried away by mass leaving the system, in its orbital form.',
 'Stellar merger outcome': 'What happens to a binary that merges: the product assigned, or whether it simply leaves the sample.',
 # §8
 'WD cooling / accretion &amp; collapse': 'White dwarf cooling, accretion and the conditions under which it collapses.',
 'Nova efficiency': 'Fraction of accreted material retained by a white dwarf through nova cycles.',
 'Magnetic braking': 'Angular momentum loss from magnetised winds in low-mass stars.',
 'Rejuvenation (post-accretion mixing)': 'How an accreting star mixes fresh fuel into its core and is effectively made younger.',
 # §9
 'Cosmological parameters': 'Cosmology used to convert delay times and redshifts into observable rates.',
 'Metallicity-dependent SFRD': 'The metallicity-dependent cosmic star formation history convolved with the yield to give rates.',
 'Local merger rate density': 'Predicted merger rate per comoving volume per year in the local Universe.',
 # §10
 'Formation channel split': 'How the population is divided into formation channels, and on what criterion.',
 'Headline quantitative result': 'The paper\u2019s central quantitative claim.',
 'Mass-distribution features': 'Peaks, gaps and cutoffs predicted in the compact-object mass distribution.',
 'Sensitivity of the result': 'How far the headline result moves across the paper\u2019s own model variations.',
 'Orbital outcome of stable MT': 'What stable mass transfer does to the orbit, and the resulting separation distribution.',
 'Implication flagged by the authors': 'The consequence the authors themselves draw for observations or for other work.',
}

# ─────────────────────────────────────────────────────────────────────────────
# Manual agreement overrides. The automatic token-overlap heuristic is good at
# "do these say the same thing", but blind to cases where two papers name the
# same prescription with materially incompatible settings. Anything listed here
# beats the heuristic and is flagged in the table.
#
#   row name: (mode, reason, groups)
#     mode "differ" -> every paper that states a value is marked different
#     mode "same"   -> every paper that states a value is marked agreeing
#     mode "groups" -> `groups` is a list of lists of paper ids; papers sharing
#                      a group agree with each other and differ from the rest
# ─────────────────────────────────────────────────────────────────────────────
MATCH_OVERRIDE = {
 'Primary mass function (IMF)': ('differ',
   'All name Kroupa (2001), but the sampled mass ranges (0.01-200 vs 5-100 vs 10-150 Msun) are not interchangeable.',
   None),
 'Stellar evolution framework': ('groups',
   'Three different COMPAS releases: van Son 2022a is v02.19.04, van Son 2022b and 2023 are v02.26.03, Willcox is v02.38.07. Defaults moved between all three.',
   [['vanson22b', 'vanson23'], ['willcox23'], ['vanson22a']]),
 'Formation channel split': ('differ',
   'van Son 2022a splits its whole population into CE vs stable-RLOF on whether a CE ever occurred; van Son 2023 splits an evolved population into stable-MT and CE channels; van Son 2022b models the stable channel alone; Willcox classifies stable vs unstable MT and never evaluates a CE outcome.',
   None),
 'Mass transfer stability criterion': ('differ',
   'All three that state one use a zeta criterion, but with different values (zeta_ad,HG 6.5 in van Son 2022a, deliberately lowered to zeta_eff 6.0 in van Son 2022b) and different main-sequence treatments.',
   None),
 'Accretion efficiency (RLOF)': ('differ',
   'van Son 2022a lets beta follow the accretor thermal timescale (10x thermal rate); van Son 2022b fixes beta_acc = 0.5 for its grid. The same lineage, but not the same setting.',
   None),
}
