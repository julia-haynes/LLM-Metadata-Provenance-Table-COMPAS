# -*- coding: utf-8 -*-
"""Scaffold a new paper file:  python3 new_paper.py <id> "Short Label"

Writes papers/<id>.py with all ledger rows pre-filled as NOT SPECIFIED, ready to
edit. Run build.py afterwards; it picks the file up automatically.
"""
import os, sys
from ledger_rows import SECTIONS

def main():
    if len(sys.argv) < 3:
        sys.exit('usage: python3 new_paper.py <id> "Short Label"')
    pid, label = sys.argv[1], sys.argv[2]
    path = f'papers/{pid}.py'
    if os.path.exists(path):
        sys.exit(f'{path} already exists')
    n = len([p for p in os.listdir('papers') if p.endswith('.py') and not p.startswith('_')])
    with open(path, 'w', encoding='utf-8') as f:
        w = lambda s='': f.write(s + '\n')
        w('# -*- coding: utf-8 -*-')
        w(f'"""{label} — fill this in, then run: python3 build.py')
        w('')
        w('Rules enforced by the build:')
        w('  * A value appears ONLY if the paper states it. Otherwise leave it as NS.')
        w('  * Every non-empty quote must appear verbatim in pdf_text, or the build fails.')
        w('  * Keep quotes prose-only (no equations, super/subscripts) so Ctrl-F matches them.')
        w('"""')
        w('NS = "NOT SPECIFIED"')
        w('')
        w('PAPER = dict(')
        w(f'    id={pid!r},')
        w(f'    order={n + 1},')
        w(f'    label={label!r},                # short name used in column headers and chips')
        w('    cite="Author et al. (YEAR)",')
        w('    arxiv="arXiv:XXXX.XXXXX",')
        w('    code="CODE vX.Y.Z",             # badge text, e.g. "COMPAS v02.38.07"')
        w('    code_name="COMPAS",             # code alone, for the Papers sheet')
        w('    code_version="vX.Y.Z",          # version alone, for the Papers sheet')
        w('    focus="BBH / BNS / ...",')
        w('    systems="BBH",                  # what the SIM covers: BBH / BNS / BHNS / BBH + BHNS / ...')
        w('    systems_detail="",              # one or two sentences: what is in and out of the sample')
        w('    purpose="",                     # why the paper was written, in one sentence')
        w('    summary="",                     # what the model actually did, 3-5 sentences')
        w('    colour="",                       # blank = auto-assigned a distinct colour')
        w(f'    pdf_text="{pid}.txt",           # pdftotext output; quotes are checked against it')
        w('    title="Full paper title",')
        w('    extra="",                        # data DOI, repo, software versions')
        w(')')
        w('')
        w('# The paper\'s own sentence explaining why a class of parameters is absent.')
        w('# Shown in NOT SPECIFIED cells. Leave "" if the paper has no such statement.')
        w('DEFERRAL = ""')
        w('')
        w('ENTRIES = {')
        for num, title, colour, params in SECTIONS:
            w(f'  # ── §{num}  {title}')
            for name in params:
                w(f'  {name!r}: dict(value=NS, desc="Not stated.", src="—", quote="", num={{}}),')
            w('')
        w('}')
        w('')
        w('# num: machine-readable numbers, one self-describing key per quantity, unit in')
        w('# the key name (IMF_M_min_Msun, zeta_ad_HG, R_z0.2_stable_Gpc3_yr). These feed the')
        w('# Numeric column and the tidy "Numeric Values" sheet, so keep them plain numbers.')
        w('')
        w('# COMPAS --flags this paper pins down. Keys must match the reference spreadsheet.')
        w('FLAGS = {')
        w('  # "initial-mass-function": dict(value="KROUPA", note="Sec. X", quote="..."),')
        w('}')
        w('')
        w('SUBMODEL_SUBTITLE = ""')
        w('SUBMODELS = [')
        w('  # ("GROUP HEADING", [')
        w('  #   ("panel", "what changed", "<b>Fid:</b> ...", "<b>Alt:</b> ...", "effect", "Sec. X", "verbatim quote"),')
        w('  # ]),')
        w(']')
        w('')
        w('# (parameter, value, description, source, verbatim quote) — [] if no cosmology.')
        w('COSMIC = [')
        w(']')
    print(f'wrote {path}  ({sum(len(p) for _,_,_,p in SECTIONS)} rows scaffolded)')
    print(f'next: put the paper\'s pdftotext output at ./{pid}.txt, fill the file in, run build.py')

if __name__ == '__main__':
    main()
