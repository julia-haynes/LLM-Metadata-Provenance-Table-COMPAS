# -*- coding: utf-8 -*-
"""Build the ledger HTML + XLSX from papers/*.py.

Adding a paper:
    cp papers/_TEMPLATE.py papers/<newid>.py   # fill it in
    python3 build.py

Nothing else changes. The generator sizes the grid, the paper picker, the colour
assignments, the status logic and the spreadsheet columns to however many papers
it finds — tested up to 25.
"""
import glob, importlib.util, json, os, sys, colorsys
import openpyxl
from qverify import load, norm

NS = "NOT SPECIFIED"
MAX_PAPERS = 25

# ───────────────────────────────────────────────────────── discover papers
def load_papers():
    mods = []
    for path in sorted(glob.glob('papers/*.py')):
        base = os.path.basename(path)
        if base.startswith('_'):
            continue
        spec = importlib.util.spec_from_file_location(base[:-3], path)
        m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(m)
        mods.append(m)
    mods.sort(key=lambda m: (m.PAPER.get('order', 99), m.PAPER['id']))
    if len(mods) > MAX_PAPERS:
        sys.exit(f"ERROR: {len(mods)} papers found; this build is designed for at most {MAX_PAPERS}.")
    ids = [m.PAPER['id'] for m in mods]
    assert len(set(ids)) == len(ids), f"duplicate paper ids: {ids}"
    return mods

# Distinct, evenly spaced fallback colours for papers that do not name one.
FALLBACK = []
for i in range(MAX_PAPERS):
    h = (i * 0.61803398875) % 1.0
    r, g, b = colorsys.hls_to_rgb(h, 0.30, 0.45)
    FALLBACK.append('#%02x%02x%02x' % (int(r * 255), int(g * 255), int(b * 255)))

def hex_to_rgb(h):
    h = h.lstrip('#')
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))

def lighten(h, amt=0.45):
    r, g, b = hex_to_rgb(h)
    hh, l, s = colorsys.rgb_to_hls(r / 255, g / 255, b / 255)
    r, g, b = colorsys.hls_to_rgb(hh, min(1, l + amt), min(1, s + 0.15))
    return '#%02x%02x%02x' % (int(r * 255), int(g * 255), int(b * 255))

# ───────────────────────────────────────────────────────── quote verification
def verify(mods):
    total, bad, oneline, missing_text = 0, [], 0, []
    for m in mods:
        pid = m.PAPER['id']
        tf = m.PAPER.get('pdf_text')
        if not tf or not os.path.exists(tf):
            missing_text.append(pid)
            continue
        raw, flat = load(tf)
        lines = [norm(l) for l in raw.split('\n')]

        def chk(q, where):
            nonlocal total, oneline
            if not q:
                return
            total += 1
            nq = norm(q)
            if nq not in flat:
                bad.append((pid, where, q))
            elif any(nq in l for l in lines):
                oneline += 1

        chk(getattr(m, 'DEFERRAL', ''), 'DEFERRAL')
        for k, e in m.ENTRIES.items():
            chk(e.get('quote', ''), f'ENTRIES[{k}]')
        for k, e in getattr(m, 'FLAGS', {}).items():
            chk(e.get('quote', ''), f'FLAGS[--{k}]')
        for grp, cards in getattr(m, 'SUBMODELS', []):
            for c in cards:
                if len(c) > 6:
                    chk(c[6], f'SUBMODELS[{c[0]}]')
        for row in getattr(m, 'COSMIC', []):
            if len(row) > 4:
                chk(row[4], f'COSMIC[{row[0]}]')
    return total, oneline, bad, missing_text

# ───────────────────────────────────────────────────────── assemble
from ledger_rows import SECTIONS, ALL_PARAMS, MATCH_OVERRIDE, PARAM_DESC

def main(only=None, out='pop_synth_ledger'):
    mods = load_papers()
    if only:
        want = [s.strip() for s in only.split(',') if s.strip()]
        have = {m.PAPER['id'] for m in mods}
        missing = [w for w in want if w not in have]
        if missing:
            sys.exit(f"ERROR: no such paper id(s): {', '.join(missing)}. Available: {', '.join(sorted(have))}")
        mods = [m for m in mods if m.PAPER['id'] in want]
        print(f"restricted to {len(mods)} paper(s): {', '.join(want)}")
    for i, m in enumerate(mods):
        if not m.PAPER.get('colour'):
            m.PAPER['colour'] = FALLBACK[i]

    n_q, n_1line, bad, no_text = verify(mods)
    print(f"quotes: {n_q} checked, {n_1line} on a single extracted line")
    if no_text:
        print(f"  (no pdf_text on disk for: {', '.join(no_text)} — quotes unverified)")
    if bad:
        for pid, where, q in bad:
            print(f"  FAIL {pid} {where}: {q[:90]}")
        sys.exit("ERROR: quotes above are not present verbatim in the paper text. Fix or clear them.")

    papers = []
    for m in mods:
        p = dict(m.PAPER)
        p['tint'] = ','.join(str(x) for x in hex_to_rgb(p['colour']))
        p['fg'] = lighten(p['colour'])
        p['deferral'] = getattr(m, 'DEFERRAL', '')
        p['deferral_src'] = getattr(m, 'DEFERRAL_SRC', '')
        p['url'] = getattr(m, 'PAPER_URL', '')
        p['citations'] = [list(c) for c in getattr(m, 'CITATIONS', [])]
        papers.append(p)
    pids = [p['id'] for p in papers]

    # ledger rows -> per-paper cells
    secs = []
    for num, title, colour, params in SECTIONS:
        rows = []
        for name in params:
            cells = {}
            for m in mods:
                e = m.ENTRIES.get(name)
                if e is None:
                    e = dict(value=NS, desc='Row not present in this paper’s file.', src='—', quote='', num={}, primary='')
                cells[m.PAPER['id']] = [e.get('value', NS), e.get('desc', ''),
                                        e.get('src', '—'), e.get('quote', ''),
                                        e.get('num') or {}, e.get('primary', '')]
            rows.append([name, cells, PARAM_DESC.get(name, '')])
        secs.append([num, title, colour, rows])

    # full COMPAS flag list
    wb = openpyxl.load_workbook('ref.xlsx')
    flagrows = []
    for sheet, kind in [('Physical Parameters', 'physical'), ('Administrative & Output', 'admin')]:
        ws = wb[sheet]
        for r in ws.iter_rows(min_row=2, values_only=True):
            cat, par, typ, dflt, allowed, desc = [('' if c is None else str(c)) for c in r[:6]]
            vals = {}
            for m in mods:
                e = getattr(m, 'FLAGS', {}).get(par)
                vals[m.PAPER['id']] = [e['value'], e.get('note', ''), e.get('quote', '')] if e else [NS, '', '']
            flagrows.append(dict(kind=kind, cat=cat, par=par, typ=typ, dflt=dflt,
                                 allowed=allowed, desc=desc, v=vals))
    for m in mods:
        unknown = set(getattr(m, 'FLAGS', {})) - {r['par'] for r in flagrows}
        assert not unknown, f"{m.PAPER['id']}: FLAGS keys not in the COMPAS reference: {unknown}"

    n_phys = sum(1 for r in flagrows if r['kind'] == 'physical')
    n_adm = len(flagrows) - n_phys
    n_spec = sum(1 for r in flagrows if any(v[0] != NS for v in r['v'].values()))

    # sub-models
    submodels = []
    for m in mods:
        submodels.append(dict(id=m.PAPER['id'],
                              subtitle=getattr(m, 'SUBMODEL_SUBTITLE', ''),
                              groups=[[g, [list(c) for c in cards]]
                                      for g, cards in getattr(m, 'SUBMODELS', [])]))
    cosmic = [dict(id=m.PAPER['id'], rows=[list(r) for r in getattr(m, 'COSMIC', [])])
              for m in mods]

    data = dict(papers=papers, sections=secs, flags=flagrows, submodels=submodels,
                override={k: list(v) for k, v in MATCH_OVERRIDE.items()},
                cosmic=cosmic, nPhys=n_phys, nAdm=n_adm, nSpec=n_spec,
                nParams=len(ALL_PARAMS), nQuotes=n_q, NS=NS,
                nNumeric=sum(len(e.get('num') or {}) for m in mods for e in m.ENTRIES.values()))

    html = render(data)
    open(out + '.html', 'w', encoding='utf-8').write(html)

    import build_xlsx_multi
    build_xlsx_multi.build(mods, flagrows, SECTIONS, n_q, param_desc=PARAM_DESC,
                           out=out + '_parameters.xlsx')

    n_num = sum(len(e.get('num') or {}) for m in mods for e in m.ENTRIES.values())
    print(f"built: {len(papers)} papers · {len(ALL_PARAMS)} ledger rows · "
          f"{len(flagrows)} COMPAS flags ({n_spec} stated) · {n_q} verified quotes · "
          f"{n_num} numeric quantities")


def render(d):
    from template import TEMPLATE
    return TEMPLATE(d)


if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--only', help='comma-separated paper ids to include, e.g. --only vanson23')
    ap.add_argument('--out', default='pop_synth_ledger', help='output filename prefix')
    a = ap.parse_args()
    main(only=a.only, out=a.out)
