# -*- coding: utf-8 -*-
"""TEMPLATE — fill this in, then run: python3 build.py

Rules enforced by the build:
  * A value appears ONLY if the paper states it. Otherwise leave it as NS.
  * Every non-empty quote must appear verbatim in pdf_text, or the build fails.
  * Keep quotes prose-only (no equations, super/subscripts) so Ctrl-F matches them.
"""
NS = "NOT SPECIFIED"

PAPER = dict(
    id='tmpl',
    order=4,
    label='TEMPLATE',                # short name used in column headers and chips
    cite="Author et al. (YEAR)",
    arxiv="arXiv:XXXX.XXXXX",
    code="CODE vX.Y.Z",             # badge text, e.g. "COMPAS v02.38.07"
    code_name="COMPAS",             # code alone, for the Papers sheet
    code_version="vX.Y.Z",          # version alone, for the Papers sheet
    focus="BBH / BNS / ...",
    systems="BBH",                  # what the SIM covers: BBH / BNS / BHNS / BBH + BHNS / ...
    systems_detail="",              # one or two sentences: what is in and out of the sample
    purpose="",                     # why the paper was written, in one sentence
    summary="",                     # what the model actually did, 3-5 sentences
    colour="",                       # blank = auto-assigned a distinct colour
    pdf_text="tmpl.txt",           # pdftotext output; quotes are checked against it
    title="Full paper title",
    extra="",                        # data DOI, repo, software versions
)

# The paper's own sentence explaining why a class of parameters is absent.
# Shown in NOT SPECIFIED cells. Leave "" if the paper has no such statement.
DEFERRAL = ""

ENTRIES = {
  # ── §1  INITIAL STELLAR POPULATION
  'Primary mass function (IMF)': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'Mass ratio distribution': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'Initial orbital separation / period distribution': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'Initial eccentricity distribution': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'Initial stellar rotation': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'Binary fraction': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'Metallicity sampling / grid': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'Solar metallicity reference': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'Chemically homogeneous evolution (CHE / QHE) treatment': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'Sample size': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),

  # ── §2  STELLAR EVOLUTION &amp; WINDS
  'Stellar evolution framework': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'Core overshooting': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'Hot star / OB-type winds': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'Cool star winds / Reimers η': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'Wolf–Rayet / He-star winds': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'LBV / Eddington-limited winds': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'Stellar track mass range': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),

  # ── §3  MASS TRANSFER &amp; ROCHE LOBE OVERFLOW
  'Roche lobe radius': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'Mass transfer stability criterion': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'Accretion efficiency (RLOF)': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'Accretion limit — BH accretor / Eddington multiplier': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'Angular momentum loss (non-conservative MT)': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'Orbit circularisation': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'AIC (accretion-induced collapse)': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'Ultra-stripped SN': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),

  # ── §4  COMMON ENVELOPE (CE) EVOLUTION
  'CE energy formalism': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'CE efficiency (α_CE)': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'Envelope binding energy (λ_CE)': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'HG donor CE survival / merger condition': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'Case BB mass transfer handling': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),

  # ── §5  SUPERNOVAE &amp; COMPACT REMNANTS
  'Remnant mass prescription': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'NS mass distribution': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'Pulsational pair-instability SN (PPISN)': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'ECSN mass thresholds': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'Maximum NS mass': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'Neutrino mass loss correction': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'BH natal kick': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'BH spin / NS radius': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),

  # ── §6  NATAL KICKS
  'Core-collapse SN kick σ': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'Low-kick σ (ECSN / USSN / AIC)': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'Kick mass scaling': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'Kick direction': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),

  # ── §7  TIDES &amp; ORBITAL EVOLUTION
  'Stellar tides': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'GW inspiral': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'Angular momentum loss (γ)': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'Stellar merger outcome': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),

  # ── §8  WHITE DWARF / COMPACT OBJECT PHYSICS
  'WD cooling / accretion &amp; collapse': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'Nova efficiency': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'Magnetic braking': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'Rejuvenation (post-accretion mixing)': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),

  # ── §9  COSMOLOGICAL MODEL &amp; STAR FORMATION RATE
  'Cosmological parameters': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'Metallicity-dependent SFRD': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'Local merger rate density': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),

  # ── §10  KEY ASTROPHYSICAL RESULTS &amp; CHANNELS
  'Formation channel split': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'Headline quantitative result': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'Mass-distribution features': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'Sensitivity of the result': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'Orbital outcome of stable MT': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),
  'Implication flagged by the authors': dict(value=NS, desc="Not stated.", src="—", quote="", num={}),

}

# num: machine-readable numbers, one self-describing key per quantity, unit in
# the key name (IMF_M_min_Msun, zeta_ad_HG, R_z0.2_stable_Gpc3_yr). These feed the
# Numeric column and the tidy "Numeric Values" sheet, so keep them plain numbers.

# COMPAS --flags this paper pins down. Keys must match the reference spreadsheet.
FLAGS = {
  # "initial-mass-function": dict(value="KROUPA", note="Sec. X", quote="..."),
}

SUBMODEL_SUBTITLE = ""
SUBMODELS = [
  # ("GROUP HEADING", [
  #   ("panel", "what changed", "<b>Fid:</b> ...", "<b>Alt:</b> ...", "effect", "Sec. X", "verbatim quote"),
  # ]),
]

# (parameter, value, description, source, verbatim quote) — [] if no cosmology.
COSMIC = [
]
