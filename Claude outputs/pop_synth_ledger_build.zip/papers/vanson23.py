# -*- coding: utf-8 -*-
"""van Son et al. (2023) — arXiv:2209.03385v2

One paper = one file. build.py auto-discovers every papers/*.py, so adding a
paper means copying papers/_TEMPLATE.py and filling it in — nothing else changes.
Every non-empty quote is checked verbatim against pdf_text at build time.
"""
NS = "NOT SPECIFIED"

PAPER = {'id': 'vanson23',
 'order': 2,
 'label': 'van Son 2023',
 'cite': 'van Son et al. (2023)',
 'arxiv': 'arXiv:2209.03385v2',
 'code': 'COMPAS v02.26.03',
 'focus': 'BBH / cosmic S(Z,z)',
 'colour': '#1a4b6e',
 'pdf_text': 'vs.txt',
 'title': 'The locations of features in the mass distribution of merging binary black holes are '
          'robust against uncertainties in the metallicity-dependent cosmic star formation history',
 'extra': 'data 10.5281/zenodo.7612755 · github.com/LiekeVanSon/SFRD_fit',
 'code_name': 'COMPAS',
 'code_version': 'v02.26.03',
 'systems': 'BBH',
 'systems_detail': 'Merging binary black holes only, split into a stable mass transfer channel and a common envelope channel. Rates are quoted at z = 0.2.',
 'purpose': 'Test how much of the predicted binary black hole mass distribution survives the large uncertainty in the metallicity-dependent cosmic star formation history.',
 'summary': 'Supplies a flexible analytic form for the metallicity-dependent cosmic star formation history S(Z,z): a skewed log-normal metallicity distribution whose mean and width evolve with redshift, multiplied by a Madau and Dickinson star formation rate density. Fits it to star-forming gas in IllustrisTNG100, then convolves an existing COMPAS binary population (from van Son et al. 2022b) with seven systematic variations of that history. Concludes that the normalisation of the mass distribution moves by orders of magnitude but the locations of its features do not, so those features can be used as signposts of formation physics.'}

# The paper's own statement explaining why a whole class of parameters is absent.
DEFERRAL = 'we use the simulations behind Figure 1 from van Son et al. (2022b), and we refer the reader to their methods section'
DEFERRAL_SRC = 'Sec. 4 · p. 5 (col. 2)'

# Direct link to this paper.
PAPER_URL = 'https://arxiv.org/abs/2209.03385'

# Works a result taken from this paper rests on: the code, the prescriptions it
# adopts, and the inputs it inherits. Derived from what the paper states, not from
# its whole reference list. (label, url, why it is needed)
CITATIONS = [
  ('van Son et al. (2022b), ApJ 940, 184',
   'https://doi.org/10.3847/1538-4357/ac9b0a',
   'ESSENTIAL — the COMPAS simulation set this paper reuses. All binary physics comes from here, not from this paper.'),
  ('Riley et al. (2022)',
   'https://doi.org/10.3847/1538-4365/ac416c',
   'The COMPAS code itself (v02.26.03).'),
  ('Hurley et al. (2000)',
   'https://doi.org/10.1046/j.1365-8711.2000.03426.x',
   'Single-star evolution algorithms COMPAS follows.'),
  ('Hurley et al. (2002)',
   'https://doi.org/10.1046/j.1365-8711.2002.05038.x',
   'Binary evolution algorithms COMPAS follows.'),
  ('Pols et al. (1998)',
   'https://doi.org/10.1046/j.1365-8711.1998.01658.x',
   'The detailed evolutionary models behind those algorithms.'),
  ('Kroupa (2001)',
   'https://doi.org/10.1046/j.1365-8711.2001.04022.x',
   'The IMF (0.01–200 Msun) setting the star-forming-mass normalisation.'),
  ('Planck Collaboration (2020)',
   'https://doi.org/10.1051/0004-6361/201833910',
   'The flat LCDM cosmology used for the cosmic integration.'),
  ('Madau & Dickinson (2014)',
   'https://doi.org/10.1146/annurev-astro-081811-125615',
   'The analytic SFRD(z) form that is fitted.'),
  ('Langer & Norman (2006)',
   'https://doi.org/10.1086/500363',
   'Redshift evolution of the mean metallicity.'),
  ("O'Hagan & Leonard (1976)",
   'https://doi.org/10.1093/biomet/63.1.201',
   'The skewed log-normal that distinguishes this S(Z,z) from earlier ones.'),
  ('Neijssel et al. (2019)',
   'https://doi.org/10.1093/mnras/stz2840',
   'The cosmic-integration framework, and the earlier model recovered as a special case.'),
  ('Springel et al. (2018)',
   'https://doi.org/10.1093/mnras/stx3304',
   'IllustrisTNG — TNG100 star-forming gas is what the fit is calibrated against.'),
  ('Nelson et al. (2019)',
   'https://doi.org/10.1186/s40668-019-0028-x',
   'The public TNG data release used for that fit.'),
  ('Chruslinska et al. (2021)',
   'https://doi.org/10.1093/mnras/stab2690',
   'Observation-based extremes bounding the adopted S(Z,z) variations.'),
  ('Madau & Fragos (2017)',
   'https://doi.org/10.3847/1538-4357/aa6af9',
   'The lower bound on the overall star-formation rate density.'),
  ('Dominik et al. (2015)',
   'https://doi.org/10.1088/0004-637X/806/2/263',
   'Why metallicity is sampled smoothly rather than on a grid.'),
  ('Abbott et al. (2021), GWTC-3',
   'https://arxiv.org/abs/2111.03634',
   'The observed mass distribution the predictions are compared against.'),
]

ENTRIES = {
  # ── §1  INITIAL STELLAR POPULATION
  'Primary mass function (IMF)': dict(
    value='Kroupa (2001) IMF<br>0.01 – 200 M☉<br>universal (non-evolving)',
    desc='A universal Kroupa (2001) IMF with mass limits 0.01–200 M☉ is adopted throughout the paper. It sets the normalisation converting the COMPAS BBH yield per unit star-forming mass into a cosmic rate.',
    src='Sec. 1 · p. 2 (final para)',
    quote='we adopt a universal Kroupa initial mass function (Kroupa 2001) with the mass limits',
    num={'IMF_M_min_Msun': 0.01, 'IMF_M_max_Msun': 200.0},
  ),
  'Mass ratio distribution': dict(
    value='NOT SPECIFIED<br>(deferred to van Son et al. 2022b)',
    desc='The paper reuses the simulation set behind Fig. 1 of van Son et al. (2022b) and explicitly refers the reader to that methods section for the adopted physics parameters. No mass-ratio distribution is restated here.',
    src='Sec. 4 · p. 5 (col. 2)',
    quote='',
  ),
  'Initial orbital separation / period distribution': dict(
    value='NOT SPECIFIED<br>(deferred to van Son et al. 2022b)',
    desc='Not restated in this paper.',
    src='Sec. 4 · p. 5',
    quote='',
  ),
  'Initial eccentricity distribution': dict(
    value='NOT SPECIFIED<br>(deferred to van Son et al. 2022b)',
    desc='Not restated in this paper.',
    src='Sec. 4 · p. 5',
    quote='',
  ),
  'Initial stellar rotation': dict(
    value='NOT SPECIFIED',
    desc='No initial rotation prescription is stated.',
    src='—',
    quote='',
  ),
  'Binary fraction': dict(
    value='NOT SPECIFIED<br>(deferred to van Son et al. 2022b)',
    desc='Not restated. The IMF limits 0.01–200 M☉ are used for the star-forming-mass normalisation, but no binary fraction is quoted.',
    src='Sec. 1 · p. 2',
    quote='',
  ),
  'Metallicity sampling / grid': dict(
    value='Sampled from a <em>smooth</em> probability<br>distribution (no discrete grid)<br>COMPAS range Z ∈ [10⁻⁴, 0.03]',
    desc='Metallicities of each binary were sampled from a smooth probability distribution to avoid artificial peaks in the BH mass distribution (Dominik et al. 2015; Kummer 2020). The minimum and maximum metallicities that can be simulated with COMPAS are quoted as 10⁻⁴ and 0.03 and are marked on Fig. 5. The fit itself is binned over log₁₀Z = −5 to 0 in 30 bins.',
    src='Sec. 4 · p. 6 · Sec. 3.2 · App. A · Fig. 5',
    quote='Metallicities of each binary system were sampled from a smooth probability distribution to avoid artificial peaks in the BH mass distribution',
    num={'Z_min': 0.0001, 'Z_max': 0.03, 'log10Z_fit_min': -5.0, 'log10Z_fit_max': 0.0, 'n_Z_bins': 30},
  ),
  'Solar metallicity reference': dict(
    value='NOT SPECIFIED<br>(Z⊙ used only as a plot axis unit)',
    desc='Metallicities are plotted as log₁₀(Z/Z⊙) throughout, but no numerical value of Z⊙ is given.',
    src='Figs. 1, 5, 6',
    quote='',
  ),
  'Chemically homogeneous evolution (CHE / QHE) treatment': dict(
    value='NOT SPECIFIED',
    desc='Not stated.',
    src='—',
    quote='',
  ),
  'Sample size': dict(
    value='NOT SPECIFIED<br>(reuses van Son et al. 2022b run)',
    desc='The number of binaries evolved is not restated; the paper reuses the existing COMPAS v02.26.03 simulation set of van Son et al. (2022b), available on Zenodo (10.5281/zenodo.7612755).',
    src='Sec. 4 · p. 5 · fn. 5',
    quote='v02.26.03 of the open source COMPAS suite (Riley et al.',
  ),

  # ── §2  STELLAR EVOLUTION &amp; WINDS
  'Stellar evolution framework': dict(
    value='COMPAS v02.26.03 (Riley et al. 2022)<br>Hurley et al. (2000, 2002) algorithms<br>on Pols et al. (1998) tracks',
    desc='COMPAS models the evolution of massive binaries following Hurley et al. (2000, 2002), using the detailed evolutionary models of Pols et al. (1998). Simulations taken from van Son et al. (2022b).',
    src='Sec. 4 · p. 5',
    quote='COMPAS is based on algorithms that model the evolution of massive binary stars following Hurley et al.',
  ),
  'Core overshooting': dict(
    value='NOT SPECIFIED',
    desc='Not stated.',
    src='—',
    quote='',
  ),
  'Hot star / OB-type winds': dict(
    value='NOT SPECIFIED<br>(deferred to van Son et al. 2022b)',
    desc='No wind prescription is named. The paper notes that TNG100 <em>ignores</em> stellar wind mass loss from massive stars, but that is a property of the cosmological simulation, not of the COMPAS run.',
    src='Sec. 3.1 · p. 4',
    quote='stellar winds mass loss from massive stars, binary interactions and their ionising effects are ignored',
  ),
  'Cool star winds / Reimers η': dict(
    value='NOT SPECIFIED',
    desc='Not stated.',
    src='—',
    quote='',
  ),
  'Wolf–Rayet / He-star winds': dict(
    value='NOT SPECIFIED',
    desc='Not stated.',
    src='—',
    quote='',
  ),
  'LBV / Eddington-limited winds': dict(
    value='NOT SPECIFIED',
    desc='Not stated.',
    src='—',
    quote='',
  ),
  'Stellar track mass range': dict(
    value='NOT SPECIFIED<br>(IMF limits 0.01–200 M☉ quoted<br>for normalisation only)',
    desc='Only the IMF integration limits are given; no statement about the mass range over which stellar tracks are evolved.',
    src='Sec. 1 · p. 2',
    quote='',
  ),

  # ── §3  MASS TRANSFER &amp; ROCHE LOBE OVERFLOW
  'Roche lobe radius': dict(
    value='NOT SPECIFIED',
    desc='Not stated.',
    src='—',
    quote='',
  ),
  'Mass transfer stability criterion': dict(
    value='NOT SPECIFIED<br>(channels are classified, criterion not given)',
    desc='Systems are split into a “stable mass transfer channel” and a “common envelope (CE) channel” based on whether a CE phase occurred, but the underlying stability criterion is not restated.',
    src='Sec. 4.2 · p. 8',
    quote='',
  ),
  'Accretion efficiency (RLOF)': dict(
    value='NOT SPECIFIED',
    desc='Not stated.',
    src='—',
    quote='',
  ),
  'Accretion limit — BH accretor / Eddington multiplier': dict(
    value='NOT SPECIFIED',
    desc='Not stated.',
    src='—',
    quote='',
  ),
  'Angular momentum loss (non-conservative MT)': dict(
    value='NOT SPECIFIED',
    desc='Not stated.',
    src='—',
    quote='',
  ),
  'Orbit circularisation': dict(
    value='NOT SPECIFIED',
    desc='Not stated.',
    src='—',
    quote='',
  ),
  'AIC (accretion-induced collapse)': dict(
    value='NOT SPECIFIED',
    desc='Not stated.',
    src='—',
    quote='',
  ),
  'Ultra-stripped SN': dict(
    value='NOT SPECIFIED',
    desc='Not stated.',
    src='—',
    quote='',
  ),

  # ── §4  COMMON ENVELOPE (CE) EVOLUTION
  'CE energy formalism': dict(
    value='NOT SPECIFIED<br>(CE channel identified, formalism not given)',
    desc='Results are split by whether the binary experienced a CE phase, but no α–λ formalism, efficiency or binding-energy prescription is stated.',
    src='Sec. 4.2 · p. 8 · Fig. 4',
    quote='',
  ),
  'CE efficiency (α_CE)': dict(
    value='NOT SPECIFIED',
    desc='Not stated.',
    src='—',
    quote='',
  ),
  'Envelope binding energy (λ_CE)': dict(
    value='NOT SPECIFIED',
    desc='Not stated.',
    src='—',
    quote='',
  ),
  'HG donor CE survival / merger condition': dict(
    value='NOT SPECIFIED',
    desc='Not stated.',
    src='—',
    quote='',
  ),
  'Case BB mass transfer handling': dict(
    value='NOT SPECIFIED',
    desc='Not stated.',
    src='—',
    quote='',
  ),

  # ── §5  SUPERNOVAE &amp; COMPACT REMNANTS
  'Remnant mass prescription': dict(
    value='NOT SPECIFIED<br>(deferred to van Son et al. 2022b)',
    desc='The BBH primary-mass distribution is a <em>result</em> of the paper (features at ≈ 9, 22, 35, 45 M☉), but the remnant-mass prescription producing it is not restated.',
    src='Sec. 4.2 · Figs. 3, 4',
    quote='',
  ),
  'NS mass distribution': dict(
    value='NOT SPECIFIED',
    desc='Not stated.',
    src='—',
    quote='',
  ),
  'Pulsational pair-instability SN (PPISN)': dict(
    value='NOT SPECIFIED',
    desc='PPISN is mentioned in the introduction as a metallicity-sensitive transient class, but no PPISN prescription or mass limits are given for the COMPAS run.',
    src='Sec. 1 · p. 1',
    quote='',
  ),
  'ECSN mass thresholds': dict(
    value='NOT SPECIFIED',
    desc='Not stated.',
    src='—',
    quote='',
  ),
  'Maximum NS mass': dict(
    value='NOT SPECIFIED',
    desc='Not stated.',
    src='—',
    quote='',
  ),
  'Neutrino mass loss correction': dict(
    value='NOT SPECIFIED',
    desc='Not stated.',
    src='—',
    quote='',
  ),
  'BH natal kick': dict(
    value='NOT SPECIFIED',
    desc='Not stated. Kicks matter for the surviving-binary fraction underlying the quoted rates, but the prescription is deferred to van Son et al. (2022b).',
    src='—',
    quote='',
  ),
  'BH spin / NS radius': dict(
    value='NOT SPECIFIED',
    desc='Not stated.',
    src='—',
    quote='',
  ),

  # ── §6  NATAL KICKS
  'Core-collapse SN kick σ': dict(
    value='NOT SPECIFIED',
    desc='Not stated.',
    src='—',
    quote='',
  ),
  'Low-kick σ (ECSN / USSN / AIC)': dict(
    value='NOT SPECIFIED',
    desc='Not stated.',
    src='—',
    quote='',
  ),
  'Kick mass scaling': dict(
    value='NOT SPECIFIED',
    desc='Not stated.',
    src='—',
    quote='',
  ),
  'Kick direction': dict(
    value='NOT SPECIFIED',
    desc='Not stated.',
    src='—',
    quote='',
  ),

  # ── §7  TIDES &amp; ORBITAL EVOLUTION
  'Stellar tides': dict(
    value='NOT SPECIFIED',
    desc='Not stated.',
    src='—',
    quote='',
  ),
  'GW inspiral': dict(
    value='NOT SPECIFIED',
    desc='Delay times are implicit in the cosmic-integration convolution (rates are reported at z = 0.2), but no GW-inspiral prescription is stated.',
    src='Sec. 4 · p. 6',
    quote='',
  ),
  'Angular momentum loss (γ)': dict(
    value='NOT SPECIFIED',
    desc='Not stated.',
    src='—',
    quote='',
  ),
  'Stellar merger outcome': dict(
    value='NOT SPECIFIED',
    desc='Not stated.',
    src='—',
    quote='',
  ),

  # ── §8  WHITE DWARF / COMPACT OBJECT PHYSICS
  'WD cooling / accretion &amp; collapse': dict(
    value='NOT SPECIFIED',
    desc='Not stated (BBH study).',
    src='—',
    quote='',
  ),
  'Nova efficiency': dict(
    value='NOT SPECIFIED',
    desc='Not stated.',
    src='—',
    quote='',
  ),
  'Magnetic braking': dict(
    value='NOT SPECIFIED',
    desc='Not stated.',
    src='—',
    quote='',
  ),
  'Rejuvenation (post-accretion mixing)': dict(
    value='NOT SPECIFIED',
    desc='Not stated.',
    src='—',
    quote='',
  ),

  # ── §9  COSMOLOGICAL MODEL &amp; STAR FORMATION RATE
  'Cosmological parameters': dict(
    value='Flat ΛCDM (Planck Collab. 2020)<br>Ω_M = 0.31 · Ω_Λ = 0.69<br>H₀ = 67.7 km s⁻¹ Mpc⁻¹',
    desc='Adopted throughout the paper for the cosmic-integration step that converts the COMPAS yield into a merger-rate density.',
    src='Sec. 1 · p. 2 (final para)',
    quote='a flat ΛCDM cosmology with',
    num={'Omega_M': 0.31, 'Omega_Lambda': 0.69, 'H0_km_s_Mpc': 67.7},
  ),
  'Metallicity-dependent SFRD': dict(
    value='𝒮(Z,z) = SFRD(z) × dP/dZ(Z,z)<br><br>dP/dZ: <em>skewed</em>-log-normal<br>μ₀ = 0.025 · μ_z = −0.049<br>α = −1.778 · ω₀ = 1.122 · ω_z = 0.049<br>(α_z = 0, α held constant in z)<br><br>SFRD: Madau &amp; Dickinson (2014) form<br>a = 0.02 · b = 1.48 · c = 4.44 · d = 5.90',
    desc='The paper’s central contribution. dP/dZ is a skewed-log-normal (O’Hagan &amp; Leonard 1976) with location ξ(z), scale ω(z) = ω₀10^(ω_z·z) and shape α; the mean metallicity evolves as ⟨Z⟩ = μ₀10^(μ_z·z) following Langer &amp; Norman (2006) / Neijssel et al. (2019). Best-fit values obtained by fitting to star-forming gas in IllustrisTNG100 with a star-formation-weighted χ cost function minimised via scipy BFGS. Implemented in the COMPAS Cosmic Integration suite.',
    src='Eqs. 1, 11, 12 · Table 1 · p. 7 · Sec. 3',
    quote='To capture this behaviour we adopt a skewed-log-normal distribution instead.',
    num={'mu_0': 0.025, 'mu_z': -0.049, 'alpha': -1.778, 'omega_0': 1.122, 'omega_z': 0.049, 'sfrd_a': 0.02, 'sfrd_b': 1.48, 'sfrd_c': 4.44, 'sfrd_d': 5.9},
  ),
  'Local merger rate density': dict(
    value='Fiducial ℛ₀.₂ (at z = 0.2):<br>17.1 Gpc⁻³ yr⁻¹ — stable-MT channel<br>41.8 Gpc⁻³ yr⁻¹ — CE channel<br><br>Variation range: 6.3 – 205.3 (stable)<br>24.2 – 144.1 (CE)',
    desc='Rates quoted at z = 0.2 because that is where GW observations are best constrained (Abbott et al. 2021b). Across the full set of 𝒮(Z,z) variations the rate changes by at most ~3.7–3.8× at M_BH,1 = 10 M☉ but up to ~200× (stable) and ~150× (CE) at 40 M☉ — the key robustness result of the paper.',
    src='Figs. 3, 4 legends · Sec. 4.2',
    quote='we annotate the total BBH merger rate at redshift 0.2',
    num={'R_z0.2_stable_Gpc3_yr': 17.1, 'R_z0.2_CE_Gpc3_yr': 41.8, 'R_z0.2_stable_min_Gpc3_yr': 6.3, 'R_z0.2_stable_max_Gpc3_yr': 205.3, 'R_z0.2_CE_min_Gpc3_yr': 24.2, 'R_z0.2_CE_max_Gpc3_yr': 144.1, 'redshift': 0.2},
  ),

  # ── §10  KEY ASTROPHYSICAL RESULTS &amp; CHANNELS
  'Formation channel split': dict(
    value='Stable MT channel vs CE channel<br>(split on whether a CE phase occurred)',
    desc='Systems from van Son et al. (2022a) are divided into the stable mass-transfer channel (only stable MT) and the ‘classical’ common-envelope channel (≥ 1 CE event), following van den Heuvel et al. 2017; Inayoshi et al. 2017; Bavera et al. 2021; Marchant et al. 2021; Gallegos-Garcia et al. 2021.',
    src='Sec. 4.2 · p. 8',
    quote='we split the data from van Son et al. (2022a) between the stable mass transfer channel',
  ),
  'Headline quantitative result': dict(
    value='ℛ₀.₂ = 17.1 Gpc⁻³ yr⁻¹ (stable)<br>41.8 Gpc⁻³ yr⁻¹ (CE)<br>feature <em>locations</em> invariant',
    desc='Across every 𝒮(Z,z) variation the locations of features in the primary BH mass distribution do not move — only the normalisation changes. This is the paper’s central claim: feature locations can serve as sign posts of the underlying formation-channel and binary physics.',
    src='Sec. 4.2 · Sec. 5 · Figs. 3, 4',
    quote='The locations of features in the distribution of primary BH masses are robust against variations in',
    num={'R_z0.2_stable_Gpc3_yr': 17.1, 'R_z0.2_CE_Gpc3_yr': 41.8},
  ),
  'Mass-distribution features': dict(
    value='Stable channel: peak ≈ 9 M☉ · bump ≈ 22 M☉<br>knee ≈ 35 M☉ · bump ≈ 45 M☉<br>CE channel: kink ≈ 9 M☉ · peak ≈ 17 M☉',
    desc='Two features are visible in all variations of the stable channel (9 and 22 M☉) and two more in almost all (35 and 45 M☉). The CE channel shows a kink at ≈ 9 M☉ and a global peak at ≈ 17 M☉. Features can be suppressed but never move.',
    src='Sec. 4.2 · p. 8 · Figs. 3, 4',
    quote='For the stable channel, two features are visible in all variations',
    num={'stable_peak_Msun': 9.0, 'stable_bump_Msun': 22.0, 'stable_knee_Msun': 35.0, 'stable_bump2_Msun': 45.0, 'CE_kink_Msun': 9.0, 'CE_peak_Msun': 17.0},
  ),
  'Sensitivity of the result': dict(
    value='At M_BH,1 = 10 M☉ the rate changes by<br>≤ 3.7× (stable) / 3.8× (CE)<br>At 40 M☉ by up to ~200× / ~150×',
    desc='The low-mass end is far more robust than the high-mass end, because the lowest-mass BHs form at all metallicities Z ≳ 10⁻³ where the star-formation rate is observationally well constrained. Widest single lever: ω₀, the width of the metallicity distribution.',
    src='Sec. 4.2 · p. 8–9 · Fig. 6',
    quote='we find that the rate changes by at most a factor of about 3.7 for the stable channel',
    num={'rate_factor_at_10Msun_stable': 3.7, 'rate_factor_at_10Msun_CE': 3.8, 'rate_factor_at_40Msun_stable': 200.0, 'rate_factor_at_40Msun_CE': 150.0},
  ),
  'Orbital outcome of stable MT': dict(
    value='NOT SPECIFIED',
    desc='Post-MT orbital separations are not analysed in this paper.',
    src='—',
    quote='',
  ),
  'Implication flagged by the authors': dict(
    value='The low-mass end (≲ 15 M☉) is the most<br>powerful cosmological constraint on<br>formation physics',
    desc='Because the low-mass end is least affected by 𝒮(Z,z) uncertainty, it is the best place to constrain formation-channel physics irrespective of cosmic star-formation-rate uncertainties — relevant for third-generation detectors.',
    src='Sec. 4.2 · Sec. 5',
    quote='The low-mass end of the mass distribution of merging double compact objects will also provide a particularly powerful cosmological constraint',
  ),

}

# COMPAS command-line flags this paper pins down (full-list tab).
FLAGS = {
  'initial-mass-function': dict(value='KROUPA', note='Universal Kroupa (2001) IMF (Sec. 1, p. 2).', quote='we adopt a universal Kroupa initial mass function (Kroupa 2001) with the mass limits'),
  'initial-mass-function-min': dict(value='0.01', note='Lower IMF mass limit, M☉ (Sec. 1, p. 2).', quote='we adopt a universal Kroupa initial mass function (Kroupa 2001) with the mass limits'),
  'initial-mass-function-max': dict(value='200.0', note='Upper IMF mass limit, M☉ (Sec. 1, p. 2).', quote='we adopt a universal Kroupa initial mass function (Kroupa 2001) with the mass limits'),
  'initial-mass-function-power': dict(value='NOT SPECIFIED', note='Kroupa broken power law implied but slopes not restated.', quote=''),
  'mass-ratio-distribution': dict(value='NOT SPECIFIED', note='Deferred to van Son et al. 2022b.', quote=''),
  'semi-major-axis-distribution': dict(value='NOT SPECIFIED', note='Deferred to van Son et al. 2022b.', quote=''),
  'eccentricity-distribution': dict(value='NOT SPECIFIED', note='Deferred to van Son et al. 2022b.', quote=''),
  'metallicity': dict(value='NOT SPECIFIED', note='No solar-metallicity reference or single Z value stated; Z is sampled, not fixed.', quote=''),
  'metallicity-distribution': dict(value='Smooth probability distribution (not a discrete grid)', note='Metallicities sampled from a smooth distribution to avoid artificial peaks in the BH mass distribution (Sec. 4, p. 6). COMPAS flag name not given.', quote='Metallicities of each binary system were sampled from a smooth probability distribution to avoid artificial peaks in the BH mass distribution'),
  'metallicity-min': dict(value='0.0001 (quoted as a COMPAS limit, not stated as a run setting)', note='The paper marks 10⁻⁴ as the minimum metallicity that *can* be simulated with COMPAS (App. A, Fig. 5); it does not state this as the value it set.', quote='metallicities that can be simulated with COMPAS'),
  'metallicity-max': dict(value='0.03 (quoted as a COMPAS limit, not stated as a run setting)', note='The paper marks 0.03 as the maximum metallicity that *can* be simulated with COMPAS (App. A, Fig. 5); it does not state this as the value it set.', quote='metallicities that can be simulated with COMPAS'),
  'number-of-systems': dict(value='NOT SPECIFIED', note='Reuses the van Son et al. (2022b) simulation set; N not restated.', quote=''),
  'version': dict(value='v02.26.03', note='COMPAS version used for the reused simulations (Sec. 4, p. 5).', quote='v02.26.03 of the open source COMPAS suite (Riley et al.'),
}

# Sub-model / variation cards.
SUBMODEL_SUBTITLE = 'COMPAS — van Son et al. (2023) · 5 dP/dZ variations + 2 SFRD variations (Table 2) · binary physics held fixed throughout'
SUBMODELS = [
  ('FIDUCIAL', [
    ('F (fiducial)', '— (baseline)', '<b>Fid:</b> μ₀ = 0.025, μ_z = −0.049,<br>α = −1.778, ω₀ = 1.122, ω_z = 0.049<br>a = 0.02, b = 1.48, c = 4.44, d = 5.90', '<b>Alt:</b> —', 'Best fit to the star-forming gas of IllustrisTNG100. ℛ₀.₂ = 17.1 Gpc⁻³ yr⁻¹ (stable channel) and 41.8 Gpc⁻³ yr⁻¹ (CE channel). χ²(z) &lt; 2·10⁻⁴ at any redshift.', 'Table 1 · p. 7 · Sec. 3.4'),
  ]),
  ('METALLICITY DENSITY DISTRIBUTION  dP/dZ  (Table 2)', [
    ('μ₀', 'Mean metallicity at z = 0', '<b>Fid:</b> μ₀ = 0.025', '<b>Alt:</b> 0.007  /  0.035', 'Low ⟨Z₀⟩ raises the rate sharply (ℛ₀.₂ = 65.4 stable / 144.1 CE) because merging BBHs form more efficiently at low metallicity; high ⟨Z₀⟩ suppresses it (11.1 / 27.8).', 'Table 2 · Figs. 3, 4'),
    ('μ_z', 'Redshift evolution of the mean', '<b>Fid:</b> μ_z = −0.049', '<b>Alt:</b> 0.0  /  −0.5', 'Steep evolution → 55.4 stable / 74.8 CE; flat → 14.0 / 38.6. Chiefly changes the slope of the high-mass end of the stable channel, via its longer delay times.', 'Table 2 · Figs. 3, 4'),
    ('α', 'Skewness (shape) of dP/dZ', '<b>Fid:</b> α = −1.778 (α_z = 0)', '<b>Alt:</b> −6.0  /  0.0', 'More skew pushes the peak to higher Z and lowers the local rate (12.2 stable) relative to the symmetric log-normal (38.6 stable). Recovers Neijssel et al. (2019) at α = 0.', 'Table 2 · Figs. 3, 4'),
    ('ω₀  ⚠ LARGEST LEVER', 'Scale (width) of dP/dZ at z = 0', '<b>Fid:</b> ω₀ = 1.125 (Table 2)<br>1.122 (Table 1 best fit)', '<b>Alt:</b> 0.7  /  2.0', 'The single most impactful parameter: narrow → ℛ₀.₂ = 6.3, wide → 53.1 (stable); 24.2 → 113.5 (CE). Sets the normalisation of the whole mass distribution.', 'Table 2 · Figs. 3, 4'),
    ('ω_z', 'Redshift evolution of the scale', '<b>Fid:</b> ω_z = 0.048', '<b>Alt:</b> 0.0  /  0.1', 'Flat → 12.4, steep → 24.1 (stable channel). Affects the high-mass slope of the stable channel more than the CE channel, again through delay times.', 'Table 2 · Figs. 3, 4'),
  ]),
  ('OVERALL STAR-FORMATION RATE DENSITY  SFRD(z)  (Table 2)', [
    ('SFRD (a,b,c,d)', 'All four Madau &amp; Dickinson parameters at once', '<b>Fid:</b> (0.02, 1.48, 4.44, 5.90)', '<b>Alt:</b> (0.01, 2.60, 3.20, 6.20)<br>(0.03, 2.60, 3.30, 5.90)', 'Lower bound ≈ Madau &amp; Fragos (2017) → ℛ₀.₂ = 17.3 stable / 37.2 CE. Upper bound ≈ Chruślińska et al. (2021) starbursts (SB: B18/C17) with a non-evolving low-mass GSMF → 55.6 / 114.4. Changes normalisation by ≈ 3× but no feature moves.', 'Table 2 · Fig. 2 · Sec. 4.1'),
  ]),
  ('EXTERNAL COMPARISON MODELS (sanity checks, not run)', [
    ('Chr21_lowZ / Chr21_highZ', 'Observation-based 𝒮(Z,z) extremes', '<b>Fid:</b> —', '<b>Alt:</b> 214-f14SB-BiC_FMR270_FOH_z_dM.dat<br>302-f14SB-Boco_FMR270_FOH_z_dM.dat', 'Chruślińska et al. (2021) low- and high-metallicity extremes, used to confirm that none of the adopted variations exceeds the observationally allowed range.', 'Sec. 4.1 · p. 7–8 · Fig. 6'),
    ('Neijssel19', 'Earlier phenomenological model', '<b>Fid:</b> —', '<b>Alt:</b> μ₀ = 0.035, μ_z = −0.23, ω₀ = 0.39,<br>ω_z = 0, α = 0, a = 0.01, b = 2.77,<br>c = 2.9, d = 4.7', 'Recovered as a special case of the more general form — a symmetric log-normal rather than a skewed one, so it lacks the low-metallicity tail.', 'fn. 4 · p. 5'),
  ]),
]

# Cosmic-integration inputs (not COMPAS --flags). Empty for papers with no cosmology.
COSMIC = [
  ('Omega_M', '0.31', 'Matter density, flat ΛCDM (Planck Collab. 2020)', 'Sec. 1 · p. 2', 'a flat ΛCDM cosmology with'),
  ('Omega_Lambda', '0.69', 'Dark-energy density', 'Sec. 1 · p. 2', 'a flat ΛCDM cosmology with'),
  ('H0', '67.7 km s⁻¹ Mpc⁻¹', 'Hubble constant', 'Sec. 1 · p. 2', 'a flat ΛCDM cosmology with'),
  ('mu_0', '0.025 ± 0.036', 'Mean metallicity at z = 0 (dP/dZ location)', 'Table 1 · p. 7', 'mean metallicity at z = 0'),
  ('mu_z', '−0.049 ± 0.006', 'Redshift dependence of the mean metallicity', 'Table 1 · p. 7', 'z-dependence of the mean'),
  ('alpha', '−1.778 ± 0.002', 'Shape (skewness) of the metallicity distribution; α_z = 0', 'Table 1 · p. 7 · Sec. 2.1', 'shape (skewness)'),
  ('omega_0', '1.122 ± 0.001', 'Scale (width) of the metallicity distribution at z = 0', 'Table 1 · p. 7', 'scale at z = 0'),
  ('omega_z', '0.049 ± 0.009', 'Redshift dependence of the scale', 'Table 1 · p. 7', 'z-dependence of the scale'),
  ('SFRD a', '0.02 ± 0.072', 'Normalisation of the Madau & Dickinson (2014) SFRD, M☉ yr⁻¹ Mpc⁻³', 'Table 1 · p. 7 · Eq. 12', 'Best fitting parameters for our'),
  ('SFRD b', '1.48 ± 0.002', 'Low-z slope of the SFRD', 'Table 1 · p. 7', 'Best fitting parameters for our'),
  ('SFRD c', '4.44 ± 0.001', 'Turnover parameter of the SFRD', 'Table 1 · p. 7', 'Best fitting parameters for our'),
  ('SFRD d', '5.90 ± 0.002', 'High-z decline of the SFRD', 'Table 1 · p. 7', 'Best fitting parameters for our'),
  ('Fit target', 'IllustrisTNG100 star-forming gas', 'log₁₀Z from −5 to 0 in 30 bins; z = 0 to 10 in steps dz = 0.05; star-formation-weighted χ cost function minimised with scipy BFGS', 'Sec. 3.2–3.4', 'We consider metallicities between'),
  ('Reference redshift for rates', 'z = 0.2', 'Rates quoted at z = 0.2, where GW observations are best constrained (Abbott et al. 2021b)', 'Sec. 4.2 · Figs. 3, 4', 'we annotate the total BBH merger rate at redshift 0.2'),
]
