# -*- coding: utf-8 -*-
"""Willcox et al. (2023) — arXiv:2308.06666v1

One paper = one file. build.py auto-discovers every papers/*.py, so adding a
paper means copying papers/_TEMPLATE.py and filling it in — nothing else changes.
Every non-empty quote is checked verbatim against pdf_text at build time.
"""
NS = "NOT SPECIFIED"

PAPER = {'id': 'willcox23',
 'order': 3,
 'label': 'Willcox 2023',
 'cite': 'Willcox et al. (2023)',
 'arxiv': 'arXiv:2308.06666v1',
 'code': 'COMPAS v02.38.07',
 'focus': 'Stable MT / pre-SN',
 'colour': '#6b3a2d',
 'pdf_text': 'wx.txt',
 'title': 'The Impact of Angular Momentum Loss on the Outcomes of Binary Mass Transfer',
 'extra': 'python 3.9, numpy 1.21, matplotlib 3.5',
 'code_name': 'COMPAS',
 'code_version': 'v02.38.07',
 'systems': 'Interacting binaries, pre-supernova',
 'systems_detail': 'All interacting binaries, evolved only until the first supernova, unstable mass transfer, or formation of two white dwarfs. No compact object binaries are formed, so BBH / BNS / BHNS classifications do not apply.',
 'purpose': 'Quantify how much the uncertain angular momentum carried away by non-accreted matter changes which binaries survive mass transfer.',
 'summary': 'Introduces a parametrisation of the specific angular momentum of non-accreted matter as a decoupling radius interpolating between the accretor and the L2 point, controlled by a single parameter f_gamma. Evolves 1e5 binaries per model across a grid of accretion efficiencies, f_gamma values and four donor-stability prescriptions, and measures the fraction of interacting binaries that undergo only stable mass transfer. Finds that fraction swings between a few and about 20 percent from angular momentum uncertainty alone, comparable to the spread from the choice of stability criterion, and warns that prescriptions assuming conservative mass transfer under-predict instability and stellar mergers.'}

# The paper's own statement explaining why a whole class of parameters is absent.
DEFERRAL = 'By restricting our study to pre-SN and pre-Double White Dwarf interactions, and by ignoring post-CEE outcomes, we limit the scope of our parameter space'
DEFERRAL_SRC = 'Sec. 2.2 · p. 5'

# Direct link to this paper.
PAPER_URL = 'https://arxiv.org/abs/2308.06666'

# Works a result taken from this paper rests on: the code, the prescriptions it
# adopts, and the inputs it inherits. Derived from what the paper states, not from
# its whole reference list. (label, url, why it is needed)
CITATIONS = [
  ('COMPAS et al. (2022), JOSS',
   'https://doi.org/10.21105/joss.03838',
   'The COMPAS code itself (v02.38.07) and its fiducial parameter set.'),
  ('Eggleton (1983)',
   'https://doi.org/10.1086/160960',
   'The Roche-lobe radius formula setting the onset of RLOF.'),
  ('Hurley et al. (2000)',
   'https://doi.org/10.1046/j.1365-8711.2000.03426.x',
   'The stellar type convention used throughout.'),
  ('Hurley et al. (2002)',
   'https://doi.org/10.1046/j.1365-8711.2002.05038.x',
   'Part of the lineage behind the C = 10 thermal-limit factor.'),
  ('Soberman et al. (1997)',
   'https://arxiv.org/abs/astro-ph/9703016',
   'The donor response prescription for convective giants, and isotropic re-emission.'),
  ('Ge et al. (2020)',
   'https://doi.org/10.3847/1538-4357/aba7b7',
   'The q_c,Ge20 critical mass ratios, and the source of the adopted zeta_ad constants.'),
  ('Ge et al. (2010)',
   'https://doi.org/10.1088/0004-637X/717/2/724',
   'Delayed dynamical instability in the critical-mass-ratio definition.'),
  ('Ge et al. (2015)',
   'https://doi.org/10.1088/0004-637X/812/1/40',
   'The adiabatic mass-loss models those critical mass ratios build on.'),
  ('Claeys et al. (2014)',
   'https://doi.org/10.1051/0004-6361/201322714',
   'The q_c,Claeys14 stability prescription run as a variation.'),
  ('Kroupa (2001)',
   'https://doi.org/10.1046/j.1365-8711.2001.04022.x',
   'The IMF (slope -2.3, 5–100 Msun).'),
  ('Sana et al. (2012)',
   'https://doi.org/10.1126/science.1223344',
   'The traditional flat-q, log-uniform-separation initial distributions.'),
  ('Moe & Di Stefano (2017)',
   'https://doi.org/10.3847/1538-4365/aa6fb6',
   'The correlated initial-condition sampler tested in Appendix A.'),
  ('MacLeod et al. (2018a)',
   'https://doi.org/10.3847/1538-4357/aae9eb',
   'Hydrodynamic basis for the decoupling radius that f_gamma parametrises.'),
  ('MacLeod et al. (2018b)',
   'https://doi.org/10.3847/1538-4357/aacf08',
   'As above — the range of f_gamma is motivated by these results.'),
  ('MacLeod & Loeb (2020)',
   'https://doi.org/10.3847/1538-4357/ab822e',
   'As above.'),
  ('Paczynski & Sienkiewicz (1972)',
   'https://ui.adsabs.harvard.edu/search/q=Paczynski%20Sienkiewicz%201972%20Acta%20Astronomica%2022%2073',
   'Origin of the accretor-expansion factor C in the thermal limit.'),
  ('Neo et al. (1977)',
   'https://ui.adsabs.harvard.edu/search/q=Neo%20Miyaji%20Nomoto%20Sugimoto%201977%20PASJ%2029%20249',
   'As above.'),
  ('Schneider et al. (2015)',
   'https://doi.org/10.1088/0004-637X/805/1/20',
   'As above — the C = 10 value used here.'),
  ('Belczynski et al. (2008)',
   'https://doi.org/10.1086/521026',
   'The log(Teff/K) = 3.73 convective/radiative envelope threshold.'),
  ('Klencki et al. (2021)',
   'https://doi.org/10.1051/0004-6361/202038707',
   'The alternative log(Teff/K) = 3.65 threshold also tested.'),
  ('Hjellming & Webbink (1987)',
   'https://doi.org/10.1086/165412',
   'Delayed dynamical instability, central to the stability discussion.'),
]

ENTRIES = {
  # ── §1  INITIAL STELLAR POPULATION
  'Primary mass function (IMF)': dict(
    value='Kroupa (2001) IMF<br>p(M₁) ∝ M₁<sup>−2.3</sup><br>5 – 100 M☉',
    desc='Primary mass drawn from the Kroupa IMF with a single power-law slope −2.3 over 5–100 M☉ — the range restricted to NS/BH progenitors. This is the “Traditional Sampler”; an alternative Moe &amp; Di Stefano (2017) correlated sampler is tested in App. A.',
    src='Sec. 2.2 · p. 5 · App. A',
    quote='we draw its mass M1 from the Kroupa initial mass function (IMF)',
    num={'IMF_M_min_Msun': 5.0, 'IMF_M_max_Msun': 100.0, 'IMF_slope': -2.3},
  ),
  'Mass ratio distribution': dict(
    value='Uniform in q ≡ M₂/M₁<br>q ∈ [0.1, 1]<br>no minimum M₂ imposed',
    desc='Flat mass-ratio distribution. The paper states explicitly that <em>no</em> additional constraint is imposed on the minimum secondary mass — unlike many BPS setups which enforce M₂ ≥ 0.1 M☉.',
    src='Sec. 2.2 · p. 5',
    quote='The mass ratio distribution is uniform',
    num={'q_min': 0.1, 'q_max': 1.0},
  ),
  'Initial orbital separation / period distribution': dict(
    value='Log-uniform in separation<br>log₁₀(a/AU) ∈ [−2, 2]<br>(a ≈ 0.01 – 100 AU)',
    desc='Flat-in-log separation sampling. Single stars are folded in implicitly as very wide binaries, so extending the upper limit is equivalent to raising the effective single-star fraction.',
    src='Sec. 2.2 · p. 5',
    quote='and the separation is drawn log',
    num={'log10_a_AU_min': -2.0, 'log10_a_AU_max': 2.0, 'a_min_AU': 0.01, 'a_max_AU': 100.0},
  ),
  'Initial eccentricity distribution': dict(
    value='e = 0 (circular at ZAMS)',
    desc='Initial eccentricity fixed at zero for the fiducial Traditional Sampler. The Moe &amp; Di Stefano (2017) alternative sampler in App. A does include non-zero eccentricities, which is why periapsis rather than semi-major axis is plotted in Fig. 7.',
    src='Sec. 2.2 · p. 5 · App. A · Fig. 7',
    quote='Initial eccentricity is fixed at 0.',
    num={'e_init': 0.0},
  ),
  'Initial stellar rotation': dict(
    value='NOT SPECIFIED',
    desc='No initial rotation distribution is stated. Rotational synchronisation is mentioned only as a caveat affecting γ (Sec. 2.1), not as a sampled initial condition.',
    src='—',
    quote='',
  ),
  'Binary fraction': dict(
    value='Effectively 100 % binaries<br>singles included implicitly as<br>very wide (non-interacting) binaries',
    desc='All single stars are included implicitly as very wide binaries for normalisation. The App. A Moe &amp; Di Stefano (2017) sampler instead yields 15.4 % singles, 34.1 % true binaries and 50.5 % inner binaries of higher-order systems.',
    src='Sec. 2.2 · p. 5 · App. A · Fig. 6',
    quote='All single stars are included implicitly as very wide binaries for normalisation purposes.',
    num={'binary_fraction': 1.0, 'MDS17_singles_frac': 0.154, 'MDS17_true_binaries_frac': 0.341, 'MDS17_inner_binaries_frac': 0.505},
    primary='binary_fraction',
  ),
  'Metallicity sampling / grid': dict(
    value='NOT SPECIFIED',
    desc='No metallicity or metallicity distribution is stated anywhere in the paper — a notable omission given that winds and stellar radii (and therefore MT stability) are metallicity dependent.',
    src='—',
    quote='',
  ),
  'Solar metallicity reference': dict(
    value='NOT SPECIFIED',
    desc='Not stated.',
    src='—',
    quote='',
  ),
  'Chemically homogeneous evolution (CHE / QHE) treatment': dict(
    value='NOT SPECIFIED',
    desc='Not stated. CHE is not among the parameter variations explored.',
    src='—',
    quote='',
  ),
  'Sample size': dict(
    value='10⁵ binaries per model variation',
    desc='Each distinct model in the grid of β, f_γ and ζ/q_c variations is run with 10⁵ ZAMS binaries.',
    src='Sec. 2.2 · p. 5',
    quote='For each distinct model, we evolve',
    num={'n_binaries_per_model': 100000.0},
  ),

  # ── §2  STELLAR EVOLUTION &amp; WINDS
  'Stellar evolution framework': dict(
    value='COMPAS v02.38.07 (COMPAS et al. 2022)<br>Hurley et al. (2000) stellar-type convention',
    desc='Fiducial parameter choices are those listed in COMPAS et al. (2022), “with a few exceptions and recently added prescriptions” detailed in Sec. 2.3. Stellar type convention follows Hurley et al. (2000).',
    src='Sec. 2.2 · p. 5 · Code Availability · p. 12',
    quote='including the fiducial parameter choices listed in COMPAS et al. (2022)',
  ),
  'Core overshooting': dict(
    value='NOT SPECIFIED',
    desc='Not stated.',
    src='—',
    quote='',
  ),
  'Hot star / OB-type winds': dict(
    value='NOT SPECIFIED',
    desc='No wind prescription named. The paper acknowledges that whether a system interacts at all depends “to a lesser extent, on the stellar winds at early phases”, but does not specify which prescription is used.',
    src='Sec. 2.2 · p. 5',
    quote='and, to a lesser extent, on the stellar winds at early phases',
  ),
  'Cool star winds / Reimers η': dict(
    value='NOT SPECIFIED',
    desc='Not stated.',
    src='—',
    quote='',
  ),
  'Wolf–Rayet / He-star winds': dict(
    value='NOT SPECIFIED',
    desc='Not stated.',
    src='—',
    quote='',
  ),
  'LBV / Eddington-limited winds': dict(
    value='NOT SPECIFIED',
    desc='Not stated.',
    src='—',
    quote='',
  ),
  'Stellar track mass range': dict(
    value='Sampled M₁ ∈ [5, 100] M☉<br>ζ_ad grid shown for ZAMS<br>M = 4 – 100 M☉',
    desc='The sampled primary range is 5–100 M☉. Fig. 2 shows the donor radial response ζ_ad for a ZAMS mass grid spanning 4–100 M☉, which brackets the range of interest.',
    src='Sec. 2.2 · p. 5 · Fig. 2 · p. 7',
    quote='The vertical lines represent the stellar radii in our models when the stellar type transitions to the named type.',
    num={'M1_lo_Msun': 5.0, 'M1_hi_Msun': 100.0, 'zeta_grid_lo_Msun': 4.0, 'zeta_grid_hi_Msun': 100.0},
  ),

  # ── §3  MASS TRANSFER &amp; ROCHE LOBE OVERFLOW
  'Roche lobe radius': dict(
    value='Eggleton (1983)<br>R_L = 0.49a / [0.6 + q<sup>2/3</sup> ln(1+q<sup>−1/3</sup>)]<br>with q ≡ M_a/M_d',
    desc='Volume-equivalent Roche-lobe radius of the donor. Note the mass-ratio convention used throughout this paper is q = M_accretor / M_donor, the inverse of some other BPS conventions — MT is unstable when q &lt; q_c.',
    src='Eq. 1 · p. 2 · Sec. 2.1.2',
    quote='The volume-equivalent Roche-lobe radius',
    num={'eggleton_coeff': 0.49},
    primary='eggleton_coeff',
  ),
  'Mass transfer stability criterion': dict(
    value='ζ_Comp (default): unstable if ζ_* &lt; ζ_L<br>ζ_ad,MS = 2 · ζ_ad,HG = 6.5<br>giants → Soberman et al. (1997)<br><br>Alternatives: q_c,Claeys14 ·<br>q_c,Ge20 · q̃_c,Ge20',
    desc='Default: MS and HG stars are treated as radiative over the whole phase with constant ζ_ad = 2 and 6.5 (constant approximations to Ge et al. 2020, per COMPAS et al. 2022); giants are convective and follow Soberman et al. (1997). Three critical-mass-ratio alternatives are run: Claeys et al. (2014) constants, and Ge et al. (2020) q_c interpolated in donor mass and radius, in standard and artificially-isentropic (tilde) variants. All q_c prescriptions implicitly assume β = 1.',
    src='Sec. 2.1.1–2.1.2 · Sec. 2.3.2 · Figs. 2, 5',
    quote='In our default model both MS and HG stars (in the mass range of interest) have radiative envelopes for the entirety of the phase',
    num={'zeta_ad_MS': 2.0, 'zeta_ad_HG': 6.5},
  ),
  'Accretion efficiency (RLOF)': dict(
    value='β_Comp = min[ C·(M_a/τ_KH,a)/(M_d/τ_KH,d), 1 ]<br>with C = 10<br><br>Variations: β = {0.0, 0.5, 1.0}',
    desc='Thermally-limited accretion; the pre-factor C = 10 accounts for the accretor expanding and so accepting mass faster (Paczyński &amp; Sienkiewicz 1972; Neo et al. 1977; Hurley et al. 2002; Schneider et al. 2015). In practice β ≈ 1 for Case A with comparable masses and β → 0 for Case B/C.',
    src='Eq. 8 · p. 6 · Sec. 2.3.1',
    quote='the pre-factor C (10 in this study) is included to account for an increase in the maximum accretion rate',
    num={'C_thermal': 10.0, 'beta_var_1': 0.0, 'beta_var_2': 0.5, 'beta_var_3': 1.0},
  ),
  'Accretion limit — BH accretor / Eddington multiplier': dict(
    value='NOT SPECIFIED',
    desc='Not stated. The study terminates at the first SN, so compact-object accretors do not arise in the modelled phase.',
    src='—',
    quote='',
  ),
  'Angular momentum loss (non-conservative MT)': dict(
    value='a_γ = a_acc + f_γ (a_L2 − a_acc), f_γ ∈ [0,1]<br>γ = (a_γ/a)² (1+q)²/q<br><br>f_γ = 0 → isotropic re-emission <em>(default)</em><br>f_γ = 1 → L2-point mass loss',
    desc='This is the central new parametrisation of the paper: a decoupling radius a_γ interpolating linearly between the accretor and the L2 point, motivated by the hydrodynamic results of MacLeod et al. (2018a,b) and MacLeod &amp; Loeb (2020b). f_γ is scanned over [0, 1] in combination with β. The maximum co-rotating specific AM loss at L2 is a_L2 ≈ 1.25a.',
    src='Eqs. 4, 9 · Sec. 2.1, 2.3.1 · Fig. 1',
    quote='which increases linearly with the decoupling radius between the accretor',
    num={'f_gamma_fiducial': 0.0, 'f_gamma_min': 0.0, 'f_gamma_max': 1.0, 'a_L2_over_a': 1.25},
    primary='f_gamma_fiducial',
  ),
  'Orbit circularisation': dict(
    value='Circularised at periapsis at the onset of MT',
    desc='For eccentric orbits, MT is assumed to drive the binary to circularise at periapsis. The paper flags this as an approximation (cf. Sepinsky et al. 2007, 2009, 2010; Dosopoulou &amp; Kalogera 2018).',
    src='Sec. 2.1 · p. 2 · App. A',
    quote='we assume that MT drives the binary to circularize at periapsis',
  ),
  'AIC (accretion-induced collapse)': dict(
    value='NOT SPECIFIED',
    desc='Not stated; excluded by construction — evolution terminates when either star undergoes a SN or both become white dwarfs.',
    src='Sec. 2.2 · p. 5',
    quote='Both components evolve into white dwarfs.',
  ),
  'Ultra-stripped SN': dict(
    value='NOT SPECIFIED',
    desc='Not stated; outside the pre-SN scope of the study.',
    src='—',
    quote='',
  ),

  # ── §4  COMMON ENVELOPE (CE) EVOLUTION
  'CE energy formalism': dict(
    value='CEE deliberately not modelled',
    desc='Unstable MT is a termination condition. The paper states that because the outcome of CEE is “notoriously uncertain”, common-envelope survivors are <em>not</em> distinguished from stellar mergers, and post-CEE outcomes are ignored to keep conclusions robust.',
    src='Sec. 2.2 · p. 5',
    quote='so for simplicity we do not distinguish common-envelope survival from stellar mergers here',
  ),
  'CE efficiency (α_CE)': dict(
    value='NOT SPECIFIED',
    desc='Not stated — CEE not followed.',
    src='Sec. 2.2 · p. 5',
    quote='',
  ),
  'Envelope binding energy (λ_CE)': dict(
    value='NOT SPECIFIED',
    desc='Not stated — CEE not followed.',
    src='Sec. 2.2 · p. 5',
    quote='',
  ),
  'HG donor CE survival / merger condition': dict(
    value='All unstable MT → terminated;<br>CE survival not distinguished from merger',
    desc='The pessimistic/optimistic HG-donor distinction does not arise because no CE outcome is evaluated at all.',
    src='Sec. 2.2 · p. 5',
    quote='The binary experiences unstable mass transfer,',
  ),
  'Case BB mass transfer handling': dict(
    value='NOT SPECIFIED',
    desc='Not stated; post-SN Case BB MT lies outside the pre-SN scope.',
    src='—',
    quote='',
  ),

  # ── §5  SUPERNOVAE &amp; COMPACT REMNANTS
  'Remnant mass prescription': dict(
    value='NOT SPECIFIED',
    desc='Not stated; evolution terminates at the first SN, so no remnant is formed.',
    src='Sec. 2.2 · p. 5',
    quote='Either star experiences a supernova (SN), or',
  ),
  'NS mass distribution': dict(
    value='NOT SPECIFIED',
    desc='Not stated — pre-SN study.',
    src='—',
    quote='',
  ),
  'Pulsational pair-instability SN (PPISN)': dict(
    value='NOT SPECIFIED',
    desc='Not stated — pre-SN study.',
    src='—',
    quote='',
  ),
  'ECSN mass thresholds': dict(
    value='NOT SPECIFIED',
    desc='Not stated — pre-SN study.',
    src='—',
    quote='',
  ),
  'Maximum NS mass': dict(
    value='NOT SPECIFIED',
    desc='Not stated — pre-SN study.',
    src='—',
    quote='',
  ),
  'Neutrino mass loss correction': dict(
    value='NOT SPECIFIED',
    desc='Not stated — pre-SN study.',
    src='—',
    quote='',
  ),
  'BH natal kick': dict(
    value='NOT SPECIFIED',
    desc='Not stated. The paper deliberately stops before the first SN precisely to avoid convolving its conclusions with SN-phase uncertainties.',
    src='Sec. 2.2 · p. 5 · Sec. 4.3 · p. 12',
    quote='The choice taken in this paper to study the stable mass transfer rate only up to the first supernova reflects this preference',
  ),
  'BH spin / NS radius': dict(
    value='NOT SPECIFIED',
    desc='Not stated.',
    src='—',
    quote='',
  ),

  # ── §6  NATAL KICKS
  'Core-collapse SN kick σ': dict(
    value='NOT SPECIFIED',
    desc='Not stated — the simulation terminates at the first SN, so no kick is ever drawn.',
    src='Sec. 2.2 · p. 5',
    quote='Either star experiences a supernova (SN), or',
  ),
  'Low-kick σ (ECSN / USSN / AIC)': dict(
    value='NOT SPECIFIED',
    desc='Not stated — pre-SN study.',
    src='—',
    quote='',
  ),
  'Kick mass scaling': dict(
    value='NOT SPECIFIED',
    desc='Not stated — pre-SN study.',
    src='—',
    quote='',
  ),
  'Kick direction': dict(
    value='NOT SPECIFIED',
    desc='Not stated — pre-SN study.',
    src='—',
    quote='',
  ),

  # ── §7  TIDES &amp; ORBITAL EVOLUTION
  'Stellar tides': dict(
    value='NOT SPECIFIED',
    desc='No tidal prescription is stated. Rotational synchronisation is raised only as a caveat on the time-dependence of γ.',
    src='Sec. 2.1 · p. 3',
    quote='',
  ),
  'GW inspiral': dict(
    value='NOT SPECIFIED',
    desc='Not applicable — no compact binaries are formed within the modelled phase.',
    src='—',
    quote='',
  ),
  'Angular momentum loss (γ)': dict(
    value='γ = (J̇/(Ṁ_a+Ṁ_d)) / (J/(M_a+M_d))<br>= (a_γ/a)² (1+q)²/q<br>parametrised through f_γ ∈ [0,1]',
    desc='Same parametrisation as the RLOF row in §3, given here in its orbital form. γ = q for a fast isotropic (“Jeans”) wind and γ = 1/q for isotropic re-emission; γ is irrelevant when MT is fully conservative.',
    src='Eqs. 2, 4, 5 · Sec. 2.1',
    quote='Many rapid BPS codes assume the isotropic re-emission model by default.',
    num={'f_gamma_fiducial': 0.0, 'f_gamma_min': 0.0, 'f_gamma_max': 1.0},
    primary='f_gamma_fiducial',
  ),
  'Stellar merger outcome': dict(
    value='Merger = termination outcome;<br>not distinguished from CE survival',
    desc='Because CEE outcomes are not modelled, mergers and CE survivors are lumped together as “unstable MT”. No post-merger stellar type is assigned.',
    src='Sec. 2.2 · p. 5',
    quote='We classify binaries based on whether or not they have experienced only stable MT up to the specified epoch.',
  ),

  # ── §8  WHITE DWARF / COMPACT OBJECT PHYSICS
  'WD cooling / accretion &amp; collapse': dict(
    value='NOT SPECIFIED',
    desc='Not stated; formation of two white dwarfs is a <em>termination condition</em>, so WD physics is never exercised.',
    src='Sec. 2.2 · p. 5',
    quote='',
  ),
  'Nova efficiency': dict(
    value='NOT SPECIFIED',
    desc='Not stated — pre-double-WD scope.',
    src='—',
    quote='',
  ),
  'Magnetic braking': dict(
    value='NOT SPECIFIED',
    desc='Not stated.',
    src='—',
    quote='',
  ),
  'Rejuvenation (post-accretion mixing)': dict(
    value='NOT SPECIFIED',
    desc='No rejuvenation prescription is named, although accretors do gain mass during the modelled stable-MT episodes.',
    src='—',
    quote='',
  ),

  # ── §9  COSMOLOGICAL MODEL &amp; STAR FORMATION RATE
  'Cosmological parameters': dict(
    value='NOT SPECIFIED',
    desc='Not applicable — Willcox et al. is a non-cosmological study of individual binaries; no cosmology, SFRD or rate normalisation appears anywhere in the paper.',
    src='—',
    quote='',
  ),
  'Metallicity-dependent SFRD': dict(
    value='NOT SPECIFIED',
    desc='Not applicable.',
    src='—',
    quote='',
  ),
  'Local merger rate density': dict(
    value='NOT SPECIFIED',
    desc='Not applicable — no rates are computed.',
    src='—',
    quote='',
  ),

  # ── §10  KEY ASTROPHYSICAL RESULTS &amp; CHANNELS
  'Formation channel split': dict(
    value='Stable MT vs unstable MT<br>(CE survival not separated from merger)',
    desc='Binaries are classified only by whether they experienced <em>only</em> stable MT up to the given epoch. Because CEE outcomes are not modelled, the unstable branch lumps CE survivors together with stellar mergers.',
    src='Sec. 2.2 · p. 5',
    quote='We classify binaries based on whether or not they have experienced only stable MT up to the specified epoch.',
  ),
  'Headline quantitative result': dict(
    value='f_SMT = 2 – 68 % after the 1st MT<br>1 – 49 % at the End state<br>“a few to ~20 %” for realistic models',
    desc='The fraction of interacting binaries undergoing only stable MT throughout their lives fluctuates between a few and ~20 % purely because of angular-momentum-loss uncertainty. Across the full model grid f_SMT spans 2–68 % (1st MT) and 1–49 % (End state).',
    src='Abstract · Sec. 3.2–3.4 · Figs. 4, 5',
    quote='fluctuates between a few and',
    num={'f_SMT_1stMT_min': 0.02, 'f_SMT_1stMT_max': 0.68, 'f_SMT_end_min': 0.01, 'f_SMT_end_max': 0.49, 'f_SMT_realistic_max': 0.2},
  ),
  'Mass-distribution features': dict(
    value='NOT SPECIFIED',
    desc='Not applicable — no compact-object masses are produced, since evolution stops at the first supernova.',
    src='—',
    quote='',
  ),
  'Sensitivity of the result': dict(
    value='f_γ is the dominant lever<br>f_SMT → a few % for f_γ ≳ 0.7<br>β–γ variation spans ≈ 50 % in f_SMT',
    desc='Varying β and γ alone changes f_SMT by as much as the choice of donor-stability prescription. If f_γ is universally high, nearly all binaries that survive the first MT still end up in CEE — which would efficiently kill off the stable-MT channel for compact-object binaries.',
    src='Sec. 3.1–3.4 · Sec. 4.1 · Figs. 4, 5',
    quote='nearly all systems experience CEE at some point if f',
    num={'f_gamma_CEE_threshold': 0.7, 'f_SMT_beta_gamma_span': 0.5},
  ),
  'Orbital outcome of stable MT': dict(
    value='Bimodal a_post/a_pre<br>peaks at ≈ 1 and ≈ 5',
    desc='Case A MT in near-equal-mass binaries populates the a_post/a_pre ≈ 1 peak; Case B systems are nearly always non-conservative and populate the ≈ 5 widening peak. The ≈ 5 peak weakens with decreasing f_γ except at f_γ = 0.',
    src='Sec. 3.1 · Fig. 3 · p. 8',
    quote='the separation ratio distribution is bimodal, with peaks at',
    num={'a_post_over_a_pre_peak1': 1.0, 'a_post_over_a_pre_peak2': 5.0},
  ),
  'Implication flagged by the authors': dict(
    value='Prescriptions assuming conservative MT<br>under-predict instability and mergers',
    desc='Stability prescriptions built on the assumption of fully conservative MT under-predict the number of systems experiencing unstable MT and stellar mergers, which may substantially affect predicted rates of luminous red novae, stripped-envelope SNe, X-ray binaries and compact-binary progenitors.',
    src='Abstract · Sec. 4 · p. 11',
    quote='under-predict the number of systems which experience unstable mass transfer and stellar mergers',
  ),

}

# COMPAS command-line flags this paper pins down (full-list tab).
FLAGS = {
  'initial-mass-function': dict(value='KROUPA', note='Kroupa (2001), p(M₁) ∝ M₁^−2.3 (Sec. 2.2, p. 5).', quote='we draw its mass M1 from the Kroupa initial mass function (IMF)'),
  'initial-mass-function-min': dict(value='5.0', note='Lower primary-mass limit, M☉ (Sec. 2.2, p. 5).', quote='between 5 and 100 M'),
  'initial-mass-function-max': dict(value='100.0', note='Upper primary-mass limit, M☉ (Sec. 2.2, p. 5).', quote='between 5 and 100 M'),
  'initial-mass-function-power': dict(value='-2.3', note='Stated explicitly as p(M₁) ∝ M₁^−2.3 (Sec. 2.2, p. 5).', quote='we draw its mass M1 from the Kroupa initial mass function (IMF)'),
  'mass-ratio-distribution': dict(value='FLAT', note='Uniform in q = M₂/M₁ (Sec. 2.2, p. 5).', quote='The mass ratio distribution is uniform'),
  'mass-ratio-min': dict(value='0.1', note='q ∈ [0.1, 1] (Sec. 2.2, p. 5).', quote='The mass ratio distribution is uniform'),
  'mass-ratio-max': dict(value='1.0', note='q ∈ [0.1, 1] (Sec. 2.2, p. 5).', quote='The mass ratio distribution is uniform'),
  'minimum-sampled-secondary-mass': dict(value='No constraint imposed', note='Stated explicitly: “with no additional constraint imposed on the minimum of M₂” (Sec. 2.2, p. 5).', quote='with no additional constraint imposed on the minimum of M2'),
  'semi-major-axis-distribution': dict(value='FLATINLOG', note='“the separation is drawn log-uniformly” (Sec. 2.2, p. 5).', quote='and the separation is drawn log'),
  'semi-major-axis-min': dict(value='0.01 AU', note='log₁₀(a/AU) = −2 (Sec. 2.2, p. 5).', quote='and the separation is drawn log'),
  'semi-major-axis-max': dict(value='100 AU', note='log₁₀(a/AU) = +2 (Sec. 2.2, p. 5).', quote='and the separation is drawn log'),
  'eccentricity-distribution': dict(value='ZERO', note='“Initial eccentricity is fixed at 0” (Sec. 2.2, p. 5). The App. A Moe & Di Stefano sampler does include e > 0.', quote='Initial eccentricity is fixed at 0.'),
  'eccentricity': dict(value='0.0', note='Fixed at zero (Sec. 2.2, p. 5).', quote='Initial eccentricity is fixed at 0.'),
  'metallicity': dict(value='NOT SPECIFIED', note='No metallicity stated anywhere in the paper.', quote=''),
  'circularise-binary-during-mass-transfer': dict(value='true', note='“we assume that MT drives the binary to circularize at periapsis” (Sec. 2.1, p. 2).', quote='we assume that MT drives the binary to circularize at periapsis'),
  'mass-transfer-accretion-efficiency-prescription': dict(value='THERMALLY_LIMITED', note='β_Comp from the ratio of Kelvin–Helmholtz timescales, Eq. 8. Variations use fixed β = {0.0, 0.5, 1.0}.', quote="The rate of accretion onto a non-degenerate companion is often assumed to be restricted by the accretor's thermal timescale"),
  'mass-transfer-thermal-limit-C': dict(value='10.0', note='“the pre-factor C (10 in this study)”, Eq. 8, p. 6.', quote='the pre-factor C (10 in this study) is included to account for an increase in the maximum accretion rate'),
  'mass-transfer-thermal-limit-accretor-multiplier': dict(value='C_FACTOR', note='Implied by the use of the C pre-factor in Eq. 8; flag name not given in the paper.', quote='the pre-factor C (10 in this study) is included to account for an increase in the maximum accretion rate'),
  'mass-transfer-fa': dict(value='Not used in the fiducial model; 0.0 / 0.5 / 1.0 in variations', note='The fiducial run is thermally limited (β_Comp), so this flag is inactive there. Fixed-efficiency variations β = {0.0, 0.5, 1.0} are run alongside it (Sec. 2.3.1).', quote='We also include variations with fixed values of'),
  'mass-transfer-angular-momentum-loss-prescription': dict(value='ISOTROPIC_RE_EMISSION (f_γ = 0, default)', note='New parametrisation a_γ = a_acc + f_γ(a_L2 − a_acc), Eq. 9; f_γ = 0 reproduces isotropic re-emission and f_γ = 1 is L2 mass loss. f_γ is scanned over [0, 1].', quote='Many rapid BPS codes assume the isotropic re-emission model by default.'),
  'mass-transfer-jloss': dict(value='γ = (a_γ/a)²(1+q)²/q', note='Given in closed form by Eq. 4 rather than as a single constant; set through f_γ.', quote='which increases linearly with the decoupling radius between the accretor'),
  'stellar-zeta-prescription': dict(value='SOBERMAN', note='Giants assumed convective and following Soberman et al. (1997) (Sec. 2.3.2).', quote='Giants, by contrast, are assumed to have convective envelopes. By default, we follow the prescription outlined in Soberman et al. (1997).'),
  'zeta-main-sequence': dict(value='2.0', note='ζ_ad,MS = 2 for radiative MS donors (Sec. 2.3.2).', quote='In our default model both MS and HG stars (in the mass range of interest) have radiative envelopes for the entirety of the phase'),
  'zeta-radiative-envelope-giant': dict(value='6.5', note='ζ_ad,HG = 6.5 for radiative HG donors (Sec. 2.3.2).', quote='In our default model both MS and HG stars (in the mass range of interest) have radiative envelopes for the entirety of the phase'),
  'critical-mass-ratio-prescription': dict(value='NONE (default) — CLAEYS / GE20 / GE20 isentropic as variations', note='Default stability is ζ-based (ζ_Comp). Three q_c prescriptions are run as variations: q_c,Claeys14, q_c,Ge20 and q̃_c,Ge20, all assuming β = 1 (Sec. 2.3.2, Fig. 5).', quote='We also include several prescriptions for stability based on critical mass ratios, from Claeys et al. (2014) and Ge et al. (2020).'),
  'convective-envelope-temperature-threshold': dict(value='5370 K (10^3.73) tested; 4467 K (10^3.65) also tested', note='Thresholds from Belczynski et al. (2008) and Klencki et al. (2021); both found to have only marginal impact on MT stability (Sec. 4.2, p. 12).', quote='We considered several values for this threshold temperature'),
  'envelope-state-prescription': dict(value='Temperature-threshold prescription (newly implemented)', note='“We implemented an improved prescription in which a giant’s envelope is radiative if the surface effective temperature is greater than a given threshold temperature” (Sec. 4.2, p. 12). COMPAS flag value not named.', quote="We implemented an improved prescription in which a giant's envelope is radiative if the surface effective temperature is greater than a given threshold temperature"),
  'use-mass-transfer': dict(value='NOT SPECIFIED', note='Not stated, though MT is the subject of the study.', quote=''),
  'number-of-systems': dict(value='100000', note='“For each distinct model, we evolve 10⁵ binaries from ZAMS” (Sec. 2.2, p. 5).', quote='For each distinct model, we evolve'),
  'version': dict(value='v02.38.07', note='COMPAS version stated under Code Availability (p. 12).', quote='Simulations in this paper made use of COMPAS'),
}

# Sub-model / variation cards.
SUBMODEL_SUBTITLE = 'COMPAS — Willcox et al. (2023) · 8 model variations in Fig. 5 + 2 initial-condition / micro-physics variations · cosmology absent'
SUBMODELS = [
  ('FIDUCIAL', [
    ('★ (fiducial)', '— (baseline, COMPAS default)', '<b>Fid:</b> ζ_Comp · β_Comp · f_γ = 0.00', '<b>Alt:</b> —', 'f_SMT ≈ 0.48 after the 1st MT episode and ≈ 0.25 at the End state. This is the model behind the default assumptions in every other figure.', 'Fig. 5 · Sec. 2.3 · Sec. 3.2'),
  ]),
  ('ANGULAR MOMENTUM LOSS &amp; MT EFFICIENCY  (Sec. 2.3.1, Fig. 5)', [
    ('★ f_γ scan', 'Specific AM of non-accreted matter', '<b>Fid:</b> f_γ = 0.00 (isotropic re-emission)', '<b>Alt:</b> f_γ = 1.00 (L2-point mass loss)', 'f_SMT drops from ≈ 0.48 → 0.20 (1st MT) and 0.25 → 0.08 (End state). For the default efficiency, f_SMT varies by ≈ 25 % across the full f_γ range.', 'Fig. 5 · Sec. 3.1'),
    ('β = 0.0, f_γ = 0.00', 'Fully non-conservative + isotropic re-emission', '<b>Fid:</b> β = β_Comp (thermally limited)', '<b>Alt:</b> β = 0.0, f_γ = 0.0', 'f_SMT ≈ 0.52 / 0.27 — the most stable of the non-conservative models.', 'Fig. 5'),
    ('β = 0.0, f_γ = 1.00  ⚠ EXTREME', 'Fully non-conservative + L2 mass loss', '<b>Fid:</b> β = β_Comp, f_γ = 0.0', '<b>Alt:</b> β = 0.0, f_γ = 1.0', 'f_SMT ≈ 0.02 / 0.01 — nearly every interacting binary is driven unstable. The maximal β–γ variation spans ≈ 50 % in f_SMT, comparable to the spread from donor-response prescriptions.', 'Fig. 5 · Sec. 3.2'),
    ('β = 0.5 / β = 1.0 scans', 'Fixed accretion efficiency', '<b>Fid:</b> β = β_Comp', '<b>Alt:</b> β = 0.5  /  β = 1.0', 'Higher β damps sensitivity to f_γ; γ is irrelevant entirely at β = 1. For f_γ ≳ 0.7 nearly all systems reach CEE at some point.', 'Fig. 4 · Sec. 3.4'),
  ]),
  ('DONOR RESPONSE / STABILITY  (Sec. 2.3.2, Fig. 5 — all assume β = 1)', [
    ('ζ_Comp, β = 1.0', 'Fully conservative reference', '<b>Fid:</b> ζ_ad,MS = 2, ζ_ad,HG = 6.5,<br>giants → Soberman et al. (1997)', '<b>Alt:</b> same ζ, β forced to 1', 'f_SMT ≈ 0.41 / 0.20. Conservative baseline against which the q_c prescriptions can be compared fairly.', 'Fig. 5 · Sec. 3.3'),
    ('q_c, Claeys14', 'Critical mass ratio, onset-of-MT definition', '<b>Fid:</b> ζ-based (ζ_Comp)', '<b>Alt:</b> Claeys et al. (2014) constants', 'f_SMT ≈ 0.40 / 0.20. Constant values by donor type and accretor degeneracy; misses delayed dynamical instability entirely.', 'Fig. 5 · Sec. 2.3.2'),
    ('q_c, Ge20  ⚠ LARGEST LEVER', 'Critical mass ratio, adiabatic 1D models', '<b>Fid:</b> ζ-based (ζ_Comp)', '<b>Alt:</b> Ge et al. (2020), standard profiles', 'f_SMT ≈ 0.64 / 0.45 — raises the stable fraction during the 1st MT event from ≈ 40 % to ≈ 70 %, mainly by making convective donors far more stable. Interpolated in both donor mass and radius.', 'Fig. 5 · Sec. 3.3 · Sec. 4.2'),
    ('q̃_c, Ge20', 'Same, artificially isentropic envelopes', '<b>Fid:</b> ζ-based (ζ_Comp)', '<b>Alt:</b> Ge et al. (2020), isentropic variant', 'f_SMT ≈ 0.68 / 0.49 — the most stable model in the entire grid. The isentropic envelope is a workaround for rapid super-adiabatic expansion in their standard models.', 'Fig. 5 · Sec. 2.3.2'),
  ]),
  ('INITIAL CONDITIONS &amp; MICRO-PHYSICS  (App. A, Sec. 4.2)', [
    ('Initial sampler', 'M₁ – q – P sampling distributions', '<b>Fid:</b> Traditional Sampler<br>(Kroupa 5–100 M☉, flat q, log-uniform a, e = 0)', '<b>Alt:</b> Moe &amp; Di Stefano (2017)<br>correlated sampler (15.4 % singles,<br>34.1 % true binaries, 50.5 % inner binaries)', 'Rates of stable MT, unstable MT and stellar mergers show a “surprising insensitivity” to the initial distributions — holding across the β, f_γ and stability variations. Higher-order multiplicity is not modelled in COMPAS.', 'App. A · Figs. 6, 7'),
    ('Convective/radiative boundary', 'Envelope-state threshold temperature', '<b>Fid:</b> log₁₀(T_eff/K) = 3.73<br>(Belczynski et al. 2008)', '<b>Alt:</b> log₁₀(T_eff/K) = 3.65<br>(Klencki et al. 2021)', 'Newly implemented prescription: a giant’s envelope is radiative above the threshold. Both values were tested and had only marginal impact on MT stability, so the variation was not pursued further.', 'Sec. 4.2 · p. 12'),
  ]),
]

# Cosmic-integration inputs (not COMPAS --flags). Empty for papers with no cosmology.
COSMIC = [
]
