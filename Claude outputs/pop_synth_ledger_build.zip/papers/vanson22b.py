# -*- coding: utf-8 -*-
"""van Son et al. (2022b) — ApJ 940, 184 — arXiv:2209.13609

"No Peaks without Valleys: The Stable Mass Transfer Channel for Gravitational-wave
Sources in Light of the Neutron Star-Black Hole Mass Gap"

This is the paper that van Son et al. (2023) defers to for its binary physics, so it
fills in a large part of what that column leaves blank. Note the a/b labels are swapped
between the two papers: what van Son (2023) calls "van Son et al. 2022b" is THIS paper
(ApJ 940, 184), while what THIS paper calls "van Son et al. 2022b" is ApJ 931, 17
(arXiv:2110.01634) — the paper this ledger has not yet ingested, and the one this paper
in turn defers to.

Quotes are verified against vanson22b.txt, which is the project knowledge base's text
extraction of the PDF (the PDF itself is not on disk here). Every quote is prose-only and
avoids en dashes, superscripts and equation fragments so that Ctrl-F matches in a viewer.
"""
NS = "NOT SPECIFIED"

PAPER = dict(
    id='vanson22b',
    order=19,
    label='van Son 2022b',
    cite='van Son et al. (2022b)',
    arxiv='arXiv:2209.13609 · ApJ 940, 184',
    code='COMPAS v02.26.03',
    focus='BBH+BHNS / stable-MT channel',
    colour='#2d6a4f',
    pdf_text='vanson22b.txt',
    title='No Peaks without Valleys: The Stable Mass Transfer Channel for Gravitational-wave Sources in Light of the Neutron Star-Black Hole Mass Gap',
    extra='data 10.5281/zenodo.7080725 & 10.5281/zenodo.7080164 · github.com/LiekeVanSon/LowMBH_and_StableChannel',
    code_name='COMPAS',
    code_version='v02.26.03',
    systems='BBH + BHNS',
    systems_detail='Binary black holes and black hole-neutron star systems, merging, from the stable mass transfer channel only. Chemically homogeneous systems, non-interacting systems and systems with only one mass transfer phase are excluded. NSNS is argued to be inaccessible to this channel.',
    purpose='Explain why the observed binary black hole mass distribution peaks near 9 Msun and thins out between 3 and 5 Msun, without invoking a gap in the supernova remnant mass function.',
    summary='Models the stable mass transfer channel in isolation: two consecutive dynamically stable mass transfer phases, no common envelope at any point. Derives an analytic lower bound on the primary compact-object mass from the requirement that both mass transfer episodes stay stable, then tests it against a grid of 25 COMPAS runs of 1e7 binaries each, varying donor response, accretion efficiency, core mass fraction, the supernova remnant prescription and circumbinary angular momentum loss. Finds a sharp low-mass cutoff between 2.5 and 9 Msun that sets the location of the peak.',
)

# The paper's own statement explaining why a class of parameters is absent.
DEFERRAL = "We refer the reader to the methods section of van Son et al. (2022b) for a more detailed description of the remainder of the adopted physics parameters."
DEFERRAL_SRC = 'Sec. 3 · p. 5'

# Direct link to this paper.
PAPER_URL = 'https://doi.org/10.3847/1538-4357/ac9b0a'

# Works a result taken from this paper rests on: the code, the prescriptions it
# adopts, and the inputs it inherits. Derived from what the paper states, not from
# its whole reference list. (label, url, why it is needed)
CITATIONS = [
  ('Riley et al. (2022)',
   'https://doi.org/10.3847/1538-4365/ac416c',
   'The COMPAS code itself (v02.26.03), used for all 25 simulation sets.'),
  ('Pols et al. (1998)',
   'https://doi.org/10.1046/j.1365-8711.1998.01658.x',
   'Stellar models underlying COMPAS; the paper attributes its core mass fractions directly to them.'),
  ('Hurley et al. (2002)',
   'https://doi.org/10.1046/j.1365-8711.2002.05038.x',
   'Binary evolution algorithms, and part of the thermal-timescale accretion lineage.'),
  ('Fryer et al. (2012)',
   'https://doi.org/10.1088/0004-637X/749/1/91',
   'The "Delayed" remnant-mass prescription and the fallback-scaled BH kicks.'),
  ('Fryer et al. (2022)',
   'https://ui.adsabs.harvard.edu/search/q=Fryer%20Olejak%20Belczynski%202022%20ApJ%20931%2094',
   'The alternative remnant prescription varied over f_mix = 0.5 to 4.0.'),
  ('Soberman et al. (1997)',
   'https://arxiv.org/abs/astro-ph/9703016',
   'Isotropic re-emission, and the Roche-lobe response zeta_RL behind the stability criterion.'),
  ('Ge et al. (2015)',
   'https://doi.org/10.1088/0004-637X/812/1/40',
   'Supports the adopted zeta_eff = 6.0 and zeta_MS = 2.'),
  ('Hjellming & Webbink (1987)',
   'https://doi.org/10.1086/165412',
   'Delayed dynamical instability, the reason zeta_eff is set for Hertzsprung-gap donors.'),
  ('Broekgaarden et al. (2019)',
   'https://ui.adsabs.harvard.edu/search/q=Broekgaarden%20Justham%20de%20Mink%202019%20MNRAS%20490%205228',
   'Adaptive importance sampling — the sampling is not uniform, which matters for any reuse.'),
  ('Tutukov & Yungelson (1979)',
   'https://ui.adsabs.harvard.edu/search/q=Tutukov%20Yungelson%201979%20Acta%20Astronomica%2029%20665',
   'Circumbinary ring at twice the orbital separation, used in the f_disk variation.'),
  ('van Son et al. (2022a), ApJ 931, 17',
   'https://doi.org/10.3847/1538-4357/ac64a3',
   'The metallicity-dependent SFRD the merger rates are integrated over.'),
]

ENTRIES = {
  # ── §1  INITIAL STELLAR POPULATION
  'Primary mass function (IMF)': dict(
    value=NS,
    desc='No IMF is stated. Kroupa (2001) appears only in the introduction as background on why low-mass progenitors are favoured, not as an adopted sampling distribution.',
    src='—',
    quote='',
  ),
  'Mass ratio distribution': dict(
    value=NS + '<br>(q<sub>ZAMS</sub> is the independent variable,<br>not a sampled distribution)',
    desc='The whole analysis is expressed as a function of q<sub>ZAMS</sub> ≡ M<sub>ZAMS,b</sub>/M<sub>ZAMS,a</sub>, and results are binned in q<sub>ZAMS</sub> with width 0.02 — but the distribution the binaries were drawn from is not restated.',
    src='Sec. 2.1 · Sec. 3.1',
    quote='we define masses MZAMS,a and MZAMS,b for the, respectively, more and less massive binary component at the onset of hydrogen burning',
  ),
  'Initial orbital separation / period distribution': dict(
    value=NS, desc='Not restated. Binaries too wide to interact are excluded from the analysis rather than sampled differently.', src='Sec. 3.1', quote='',
  ),
  'Initial eccentricity distribution': dict(value=NS, desc='Not stated.', src='—', quote=''),
  'Initial stellar rotation': dict(value=NS, desc='Not stated.', src='—', quote=''),
  'Binary fraction': dict(value=NS, desc='Not stated.', src='—', quote=''),
  'Metallicity sampling / grid': dict(
    value=NS,
    desc='No metallicity grid or sampling distribution is given. Metallicity enters only through the cosmic integration, which is adopted by reference (see §9).',
    src='Sec. 3.2', quote='',
  ),
  'Solar metallicity reference': dict(value=NS, desc='Not stated.', src='—', quote=''),
  'Chemically homogeneous evolution (CHE / QHE) treatment': dict(
    value='CHE systems excluded from the analysis',
    desc='Chemically homogeneously evolving systems are explicitly removed from the sample, so the stable-channel results are not contaminated by the CHE channel. Whether CHE was enabled in the underlying COMPAS run is not stated.',
    src='Sec. 3.1 · p. 6',
    quote='we do not include chemically homogeneously evolving systems',
  ),
  'Sample size': dict(
    value='10⁷ binaries per simulation set<br>25 variations on the reference model<br>adaptive importance sampling<br>(Broekgaarden et al. 2019)',
    desc='Each of the 25 model variations is a separate 10⁷-binary run with COMPAS v02.26.03. Sampling is not uniform: adaptive importance sampling is used, optimised for BBH and BHNS mergers, to cut sampling noise in the rare low-mass tail that the paper is about.',
    src='Sec. 3 · p. 5',
    quote='In total we ran 25 variations on our reference model.',
    num={'n_binaries_per_set': 10000000.0, 'n_variations': 25},
    primary='n_binaries_per_set',
  ),

  # ── §2  STELLAR EVOLUTION & WINDS
  'Stellar evolution framework': dict(
    value='COMPAS v02.26.03 (Riley et al. 2022)<br>Pols et al. (1998) evolutionary models',
    desc='Same COMPAS version as van Son et al. (2023). The paper attributes its core mass fractions directly to the Pols et al. (1998) models underlying COMPAS.',
    src='Sec. 3 · p. 5 · Software and Data · p. 12',
    quote='Simulations in this paper made use of the COMPAS rapid binary population synthesis code',
  ),
  'Core overshooting': dict(value=NS, desc='Not stated.', src='—', quote=''),
  'Hot star / OB-type winds': dict(value=NS, desc='No wind prescription is named.', src='—', quote=''),
  'Cool star winds / Reimers η': dict(value=NS, desc='Not stated.', src='—', quote=''),
  'Wolf–Rayet / He-star winds': dict(
    value=NS + '<br>(folded into the dM<sub>SN</sub> term)',
    desc='No WR wind prescription is named. The paper states that its dM<sub>SN</sub> parameter is a shorthand for <em>all</em> mass lost between the post-MT core mass and the final remnant mass, explicitly including WR-like winds — so wind mass loss is absorbed into the fitted SN term rather than modelled separately in the analytic treatment.',
    src='App. B · p. 13',
    quote='we use dMSN as a shorthand for all mass lost between the core mass post-mass transfer and the final remnant mass',
  ),
  'LBV / Eddington-limited winds': dict(value=NS, desc='Not stated.', src='—', quote=''),
  'Stellar track mass range': dict(
    value=NS + '<br>(M<sub>ZAMS,a</sub> ≈ 20–40 M☉ quoted as<br>the range of interest, not the track range)',
    desc='The paper quotes 20–40 M☉ as the ZAMS range relevant for producing the lowest-mass BHs, over which COMPAS tracks give core mass fractions of ≈ 0.30–0.34. This is the regime the analytic approximation is calibrated on, not a statement about the sampled or tabulated track range.',
    src='Sec. 2.2 · p. 4',
    quote='stellar evolution tracks in COMPAS lead',
    num={'M_ZAMS_a_lo_Msun': 20.0, 'M_ZAMS_a_hi_Msun': 40.0, 'f_core_lo': 0.3, 'f_core_hi': 0.34},
  ),

  # ── §3  MASS TRANSFER & ROCHE LOBE OVERFLOW
  'Roche lobe radius': dict(
    value=NS + '<br>(only the <em>response</em> ζ<sub>RL</sub> is given)',
    desc='No Roche-lobe radius formula is quoted. The paper works with the logarithmic response of the Roche radius to mass loss, ζ<sub>RL</sub>, following Soberman et al. (1997); the functional form is deferred to the accompanying notebook on GitHub.',
    src='Sec. 2.1 · App. A · fn. 8',
    quote='we approximate the response of the Roche radius to mass lost',
  ),
  'Mass transfer stability criterion': dict(
    value='Stable while ζ<sub>RL</sub> ≤ ζ<sub>*</sub><br>ζ<sub>eff</sub> = 6.0 (HG / radiative donors)<br>ζ<sub>MS</sub> = 2 (main-sequence donors)<br>→ q<sub>crit,1</sub> = 0.25 · q<sub>crit,2</sub> = 4.32<br><br>Variations: ζ<sub>eff</sub> ∈ {3.5, 4.5, 5.5, 6.0, 6.5}',
    desc='ζ<sub>eff</sub> = 6.0 is adopted for Hertzsprung-gap donors with a clear core–envelope structure, deliberately lowered from the 6.5 used in the earlier van Son paper; both are stated to agree with Ge et al. (2015). ζ<sub>MS</sub> = 2 makes Case A mass transfer more prone to instability, which is why the paper finds Case A subdominant in this channel. q<sub>crit,1</sub> and q<sub>crit,2</sub> are evaluated at β<sub>acc</sub> = 0.5 and 0 respectively.',
    src='Sec. 2.1 · Sec. 3 · Sec. 4.5 · Table 1 · App. A',
    quote='as our reference value for Hertzsprung-gap donor stars',
    num={'zeta_eff': 6.0, 'zeta_MS': 2.0, 'q_crit_1': 0.25, 'q_crit_2': 4.32, 'zeta_eff_var_min': 3.5, 'zeta_eff_var_max': 6.5},
    primary='zeta_eff',
  ),
  'Accretion efficiency (RLOF)': dict(
    value='β<sub>acc</sub> = 0.5 (fixed) — reference model<br>β<sub>acc</sub> = 0 during the 2nd MT phase<br><br>Figure 1 model: thermally limited,<br>C = 10 (as van Son et al. 2023)<br><br>Variations: β<sub>acc</sub> ∈ {0, 0.25, 0.5, 0.75, 1.0}',
    desc='Two different efficiencies appear in this paper and must not be conflated. The variation grid in Sec. 3 fixes β<sub>acc</sub> = 0.5 to isolate the effect being studied; the Figure 1 model (the one that matches the GW data) instead uses the thermal-timescale-limited rate with C = 10. The paper flags in its caveats that the thermally-limited version drives β<sub>acc</sub> towards zero at low q<sub>ZAMS</sub>, which would partly fill in the low-mass dearth.',
    src='Sec. 3 · p. 5 · Sec. 4.5 · p. 11 · Table 1',
    quote='we adopt a fixed mass transfer efficiency value of',
    num={'beta_acc': 0.5, 'beta_acc_MT2': 0.0, 'C_thermal': 10.0, 'beta_acc_var_min': 0.0, 'beta_acc_var_max': 1.0},
    primary='beta_acc',
  ),
  'Accretion limit — BH accretor / Eddington multiplier': dict(
    value='Eddington-limited → β<sub>acc</sub> = 0<br>during the second mass transfer phase',
    desc='Accretion onto the first-formed BH is taken to be radiation-pressure limited, which the paper treats as fully non-conservative rather than applying a finite Eddington multiplier.',
    src='Sec. 2.1 · p. 4',
    quote='Typically, accretion on BHs is limited by radiation pressure in the accretion flow, which leads to very low accretion rates',
    num={'beta_acc_MT2': 0.0},
  ),
  'Angular momentum loss (non-conservative MT)': dict(
    value='Isotropic re-emission<br>(specific AM of the accretor)<br>Soberman et al. (1997)<br><br>Variation: fraction f<sub>disk</sub> lost from a<br>circumbinary ring at 2a',
    desc='The fiducial assumption is isotropic re-emission. The paper then varies f<sub>disk</sub> ∈ {0, 0.25, 0.5, 0.75, 1.0}, the fraction of lost mass carrying the specific AM of a circumbinary disk placed at twice the orbital separation. This is the single most destructive variation in the paper: at f<sub>disk</sub> ≥ 0.75 the stable channel is effectively killed by stellar mergers, while f<sub>disk</sub> = 0.25 raises the rate to ≈ 123 Gpc⁻³ yr⁻¹.',
    src='Sec. 2.1 · Sec. 3.3 · Fig. 5 · Table 3',
    quote='We assume that any mass lost from the system during a stable mass transfer event will carry away the specific angular momentum of the accretor',
    num={'f_disk': 0.0, 'f_disk_var_max': 1.0, 'disk_radius_over_a': 2.0},
    primary='f_disk',
  ),
  'Orbit circularisation': dict(value=NS, desc='Not stated.', src='—', quote=''),
  'AIC (accretion-induced collapse)': dict(value=NS, desc='Not stated.', src='—', quote=''),
  'Ultra-stripped SN': dict(value=NS, desc='Not stated.', src='—', quote=''),

  # ── §4  COMMON ENVELOPE (CE) EVOLUTION
  'CE energy formalism': dict(
    value='No CE by construction — the stable<br>channel is <em>defined</em> by its absence',
    desc='This paper studies only systems in which every mass transfer episode is dynamically stable. Binaries that enter a common envelope leave the sample, so no CE formalism, efficiency or binding energy is needed or given.',
    src='Sec. 1.1 · p. 3',
    quote='The characteristic of this channel is that every mass transfer episode throughout the binary evolution is dynamically stable and no CE occurs.',
  ),
  'CE efficiency (α<sub>CE</sub>)': dict(value=NS, desc='Not stated — no CE phase is modelled.', src='Sec. 1.1', quote=''),
  'Envelope binding energy (λ<sub>CE</sub>)': dict(value=NS, desc='Not stated — no CE phase is modelled.', src='Sec. 1.1', quote=''),
  'HG donor CE survival / merger condition': dict(
    value=NS,
    desc='Not applicable. HG donors matter here through their ζ<sub>ad</sub> (see §3), not through a CE survival rule.',
    src='—', quote='',
  ),
  'Case BB mass transfer handling': dict(value=NS, desc='Not stated. The paper discusses Case A and Case B, but not Case BB.', src='—', quote=''),

  # ── §5  SUPERNOVAE & COMPACT REMNANTS
  'Remnant mass prescription': dict(
    value='Fryer et al. (2012) “Delayed”<br><br>dM<sub>SN</sub> linearised as<br>a<sub>SN</sub> = −0.9 · b<sub>SN</sub> = 13.9 M☉<br>M<sub>thresh</sub> = 14.8 M☉ (full fallback above)<br><br>Variation: Fryer et al. (2022),<br>f<sub>mix</sub> ∈ {0.5 … 4.0}, M<sub>crit</sub> = 5.75 M☉',
    desc='The Delayed prescription is the reference. For the analytic derivation the difference between core mass and remnant mass is fitted as a straight line in core mass, with full fallback above 14.8 M☉. The Fryer et al. (2022) variation spans f<sub>mix</sub> = 0.5 (closest to Delayed) to 4.0 (closest to Rapid) and moves the peak of the primary-mass distribution from a shallow rise to a sharp peak at 9.5 M☉.',
    src='Sec. 2.2 · Sec. 3.3 · Table 1 · Fig. 4',
    quote='which is a continuous function that maps CO core masses to final remnant masses',
    num={'a_SN': -0.9, 'b_SN_Msun': 13.9, 'M_thresh_Msun': 14.8, 'f_mix_min': 0.5, 'f_mix_max': 4.0, 'M_crit_Msun': 5.75},
  ),
  'NS mass distribution': dict(
    value=NS,
    desc='No NS mass distribution is given; NSs enter only through the 2.5 M☉ upper boundary and the CO-core threshold for BH formation in the Fryer et al. (2022) variation.',
    src='—', quote='',
  ),
  'Pulsational pair-instability SN (PPISN)': dict(value=NS, desc='Not stated — irrelevant at the low-mass end this paper studies.', src='—', quote=''),
  'ECSN mass thresholds': dict(value=NS, desc='Not stated.', src='—', quote=''),
  'Maximum NS mass': dict(
    value='2.5 M☉',
    desc='Stated as the upper boundary for NS formation adopted in this work — the reference against which the paper judges whether its cutoff mass opens a gap above the most massive NS.',
    src='App. C · p. 13',
    quote='the upper boundary for NS formation',
    num={'M_NS_max_Msun': 2.5},
  ),
  'Neutrino mass loss correction': dict(
    value=NS + '<br>(absorbed into dM<sub>SN</sub>)',
    desc='No separate neutrino-loss term. All mass lost between the post-MT core mass and the final remnant — SN ejecta, neutrinos and winds alike — is lumped into the single fitted quantity dM<sub>SN</sub>.',
    src='App. B · p. 13',
    quote='we use dMSN as a shorthand for all mass lost between the core mass post-mass transfer and the final remnant mass',
  ),
  'BH natal kick': dict(
    value='Fallback-reduced kicks<br>(Fryer et al. 2012)<br>proto-NS masses from the Delayed model',
    desc='BH kicks scale with fallback, so the full-fallback BHs above M<sub>thresh</sub> = 14.8 M☉ receive no kick. The kick magnitude distribution itself is not restated.',
    src='Sec. 3.3 · p. 8',
    quote='We apply BH kicks according to the fallback model from Fryer et al. (2012)',
  ),
  'BH spin / NS radius': dict(value=NS, desc='Not stated.', src='—', quote=''),

  # ── §6  NATAL KICKS
  'Core-collapse SN kick σ': dict(
    value=NS,
    desc='No Maxwellian σ is given. Only the fallback scaling for BHs is stated (see §5).',
    src='—', quote='',
  ),
  'Low-kick σ (ECSN / USSN / AIC)': dict(value=NS, desc='Not stated.', src='—', quote=''),
  'Kick mass scaling': dict(
    value='Fallback-scaled for BHs<br>(Fryer et al. 2012)',
    desc='Kicks are reduced in proportion to fallback, with proto-NS masses taken from the Delayed model. This matters for the channel: the low-mass BHs at the centre of this paper are the ones that receive the largest kicks and are most easily unbound.',
    src='Sec. 3.3 · p. 8',
    quote='We apply BH kicks according to the fallback model from Fryer et al. (2012)',
  ),
  'Kick direction': dict(value=NS, desc='Not stated.', src='—', quote=''),

  # ── §7  TIDES & ORBITAL EVOLUTION
  'Stellar tides': dict(value=NS, desc='Not stated.', src='—', quote=''),
  'GW inspiral': dict(
    value=NS,
    desc='No inspiral prescription is named, though a Hubble-time merger condition is implicit in selecting merging systems.',
    src='—', quote='',
  ),
  'Angular momentum loss (γ)': dict(
    value='MT mass loss → AM of the accretor<br>(isotropic re-emission)<br>SN / wind mass loss → AM of the donor<br>(“Jeans mode”)<br>Variation: circumbinary ring at 2a',
    desc='Two distinct modes are stated for two distinct kinds of mass loss, which is more specific than either of the other papers here. The Jeans-mode assumption for SN and wind mass loss is what makes the orbital response to dM<sub>SN</sub> tractable in the analytic derivation.',
    src='Sec. 2.1 · p. 4 · Sec. 3.3',
    quote='we assume mass lost from the system carries away the specific angular momentum of the donor',
    num={'f_disk': 0.0, 'disk_radius_over_a': 2.0},
    primary='f_disk',
  ),
  'Stellar merger outcome': dict(
    value='Merger = exit from the channel<br>(no post-merger prescription stated)',
    desc='Stellar mergers are tracked as a loss channel rather than continued. They are the stated mechanism by which high f<sub>disk</sub> destroys the stable channel: more angular momentum removed per unit mass means more binaries merge instead of surviving to form a compact binary.',
    src='Sec. 3.3 · p. 9',
    quote='We find this is mainly due to an increased number of stellar mergers.',
  ),

  # ── §8  WHITE DWARF / COMPACT OBJECT PHYSICS
  'WD cooling / accretion & collapse': dict(
    value=NS + '<br>(explicitly out of scope)',
    desc='The paper notes that the same stability argument could in principle be applied to double white dwarfs, but that its assumptions — the SN mass loss term and the constant core mass fraction — do not carry over to WD progenitors.',
    src='Sec. 4.2 · p. 10',
    quote='cannot simply be directly adopted for WD progenitors',
  ),
  'Nova efficiency': dict(value=NS, desc='Not stated.', src='—', quote=''),
  'Magnetic braking': dict(value=NS, desc='Not stated.', src='—', quote=''),
  'Rejuvenation (post-accretion mixing)': dict(
    value=NS,
    desc='No rejuvenation prescription is named, although the accretor gains up to half the transferred mass in the fiducial model.',
    src='—', quote='',
  ),

  # ── §9  COSMOLOGICAL MODEL & STAR FORMATION RATE
  'Cosmological parameters': dict(value=NS, desc='No cosmology is stated; it is inherited with the adopted star formation history.', src='—', quote=''),
  'Metallicity-dependent SFRD': dict(
    value=NS + '<br>(adopted by reference from the<br>earlier van Son papers)',
    desc='The variation grid is integrated over a metallicity-dependent SFRD taken from the two earlier van Son papers, which in turn build on Dominik et al., Neijssel et al. and Broekgaarden et al. No functional form or fit parameters are given here — those are what van Son et al. (2023) supplies.',
    src='Sec. 3.2 · p. 6',
    quote='over the metallicity-dependent star formation rate density as described in van Son et al.',
  ),
  'Local merger rate density': dict(
    value='Reference model, z = 0.2:<br>ℛ₀.₂ = 31.7 Gpc⁻³ yr⁻¹ (BBH + BHNS)<br>= 25.3 BBH + 6.5 BHNS<br><br>Figure 1 model (BBH only): ≈ 20<br>Across all variations: 0.3 – 122.9',
    desc='Rates are tabulated for every variation at z = 0.2. The spread is enormous — three orders of magnitude — driven mainly by ζ<sub>eff</sub> (0.9 at 3.5) and f<sub>disk</sub> (122.9 at 0.25, 0.3 at 1.0). Note the f<sub>core</sub> column of Table 2 lists 33.2 rather than 31.7 for the same reference model, presumably a separate simulation set.',
    src='Sec. 5 · Tables 2, 3 · p. 15',
    quote='we naturally match the local rate',
    num={'R_z0.2_total_Gpc3_yr': 31.7, 'R_z0.2_BBH_Gpc3_yr': 25.3, 'R_z0.2_BHNS_Gpc3_yr': 6.5, 'R_z0.2_fig1_BBH_Gpc3_yr': 20.0, 'R_z0.2_min_Gpc3_yr': 0.3, 'R_z0.2_max_Gpc3_yr': 122.9, 'redshift': 0.2},
    primary='R_z0.2_total_Gpc3_yr',
  ),

  # ── §10  KEY ASTROPHYSICAL RESULTS & CHANNELS
  'Formation channel split': dict(
    value='Stable channel only<br>(every MT episode dynamically stable,<br>no CE at any point)',
    desc='Unlike van Son et al. (2023), which splits a population into stable and CE channels, this paper models the stable channel in isolation and derives its properties analytically. Systems that never interact, or interact only once, are excluded as well.',
    src='Sec. 1.1 · Sec. 3.1',
    quote='The characteristic of this channel is that every mass transfer episode throughout the binary evolution is dynamically stable and no CE occurs.',
  ),
  'Headline quantitative result': dict(
    value='Sharp low-mass cutoff in M<sub>primary</sub><br>between 2.5 and 9 M☉<br>depending on the adopted physics',
    desc='The central claim: the stable channel cannot produce GW sources below a cutoff primary mass, because both mass transfer phases must be stable and the final BH masses do not scale simply with the initial masses. An analytic expression for the cutoff is derived and shown to match the numerical grid at almost every q<sub>ZAMS</sub>.',
    src='Sec. 4 · Sec. 5 · Fig. 3',
    quote='leads to a low-mass cutoff in the primary masses between 2.5 and 9',
    num={'M_cutoff_min_Msun': 2.5, 'M_cutoff_max_Msun': 9.0},
  ),
  'Mass-distribution features': dict(
    value='Dearth of M<sub>primary</sub> ≈ 2.5 – 6 M☉<br>Peak at ≈ 8 – 10 M☉<br>All models: rate below 4 M☉ &lt; 10⁻⁵ Gpc⁻³ yr⁻¹',
    desc='The fiducial model reproduces both features seen in GWTC-3 without being tuned to them. The peak location is set by the cutoff mass rather than by the remnant mass function, which is the paper’s alternative explanation for the purported NS–BH mass gap.',
    src='Sec. 1.1 · Sec. 3.3 · Sec. 5',
    quote='This model reproduces both (a) the dearth of merging primary BH masses between 2.5 and 6',
    num={'dearth_lo_Msun': 2.5, 'dearth_hi_Msun': 6.0, 'peak_lo_Msun': 8.0, 'peak_hi_Msun': 10.0, 'rate_below_4Msun_Gpc3_yr': 1e-05},
  ),
  'Sensitivity of the result': dict(
    value='ℛ₀.₂ spans 0.3 – 122.9 Gpc⁻³ yr⁻¹<br>across 25 variations<br><br>Most destructive: f<sub>disk</sub> ≥ 0.75<br>Most restrictive: ζ<sub>eff</sub> = 3.5 (ℛ = 0.9)',
    desc='Lower ζ<sub>eff</sub> and higher β<sub>acc</sub> both raise the cutoff mass and shrink the window for stable mass transfer. Raising the core mass fraction by 20 % pushes the channel down to the NS limit and up to ≈ 103 Gpc⁻³ yr⁻¹; lowering it by 20 % drops the rate to ≈ 4.',
    src='Sec. 3.2 · Sec. 3.3 · Tables 2, 3',
    quote='the stable mass transfer channel is effectively killed',
    num={'R_z0.2_min_Gpc3_yr': 0.3, 'R_z0.2_max_Gpc3_yr': 122.9, 'f_disk_kill_threshold': 0.75, 'zeta_eff_min': 3.5},
  ),
  'Orbital outcome of stable MT': dict(
    value='Orbit shrinks via mass loss carrying the<br>specific AM of the lower-mass companion',
    desc='This is the physical mechanism of the channel: with no CE to harden the orbit, tightening comes entirely from non-conservative mass loss near the accretor. It is why the channel is so sensitive to where the non-accreted matter leaves from — the same lever Willcox et al. (2023) parametrise as f<sub>γ</sub>.',
    src='Sec. 1.1 · p. 3',
    quote='The main reason for the orbit to shrink in this channel is loss of mass with high specific angular momentum from the vicinity of the lower-mass companion.',
  ),
  'Implication flagged by the authors': dict(
    value='The NS–BH mass gap may be a selection<br>effect of the formation channel, not a<br>feature of the remnant mass function',
    desc='If the dearth of low-mass BHs persists in GW observations while low-mass BHs keep turning up in X-ray binaries and astrometric surveys, that would be the smoking gun for this channel dominating the low-mass end.',
    src='Sec. 4.1 · Sec. 5 · p. 12',
    quote='the binary physics involved in the stable channel alone can provide an explanation for the purported',
  ),

}

# COMPAS --flags this paper pins down. Keys must match the reference spreadsheet.
FLAGS = {
  'version': dict(value='v02.26.03', note='Stated under Software and Data (p. 12) and in Sec. 3.',
    quote='Simulations in this paper made use of the COMPAS rapid binary population synthesis code'),
  'number-of-systems': dict(value='10000000 per simulation set', note='10⁷ binaries in each of 25 variation sets (Sec. 3, p. 5).',
    quote='In total we ran 25 variations on our reference model.'),
  'remnant-mass-prescription': dict(value='FRYER2012', note='Reference model; Fryer et al. (2022) run as a variation (Sec. 2.2, Sec. 3.3).',
    quote='which is a continuous function that maps CO core masses to final remnant masses'),
  'fryer-supernova-engine': dict(value='DELAYED', note='“Delayed” model of Fryer et al. (2012) (Sec. 2.2, p. 4).',
    quote='which is a continuous function that maps CO core masses to final remnant masses'),
  'fryer-22-fmix': dict(value='0.5 – 4.0 (variation)', note='f_mix = 0.5 is closest to Delayed, 4.0 closest to Rapid (Sec. 3.3, p. 8).',
    quote='which describes the mixing growth time'),
  'fryer-22-mcrit': dict(value='5.75', note='CO core mass below which a NS forms, in the Fryer et al. (2022) variation (Sec. 3.3, p. 8).',
    quote='the lower boundary on the CO core mass for BH formation'),
  'maximum-neutron-star-mass': dict(value='2.5', note='Upper boundary for NS formation adopted in this work (App. C, p. 13).',
    quote='the upper boundary for NS formation'),
  'black-hole-kicks-mode': dict(value='FALLBACK', note='Fryer et al. (2012) fallback model, proto-NS masses from Delayed (Sec. 3.3, p. 8).',
    quote='We apply BH kicks according to the fallback model from Fryer et al. (2012)'),
  'mass-transfer-accretion-efficiency-prescription': dict(
    value='FIXED_FRACTION (variation grid)<br>THERMALLY_LIMITED (Figure 1 model)',
    note='The Sec. 3 grid fixes beta_acc = 0.5; the Figure 1 model that matches the GW data is thermal-timescale limited (Sec. 4.5, p. 11).',
    quote='we adopt a fixed mass transfer efficiency value of'),
  'mass-transfer-fa': dict(value='0.5', note='Reference value; varied over 0.0, 0.25, 0.5, 0.75, 1.0 (Table 1).',
    quote='we adopt a fixed mass transfer efficiency value of'),
  'mass-transfer-thermal-limit-C': dict(value='10.0', note='Applies to the Figure 1 model only (Sec. 4.5, p. 11).',
    quote='is a constant factor assumed to take into account the expansion of the accreting star due to mass transfer'),
  'mass-transfer-angular-momentum-loss-prescription': dict(value='ISOTROPIC_RE_EMISSION',
    note='Fiducial; a circumbinary-disk variation at twice the orbital separation is run via f_disk (Sec. 3.3).',
    quote='We assume that any mass lost from the system during a stable mass transfer event will carry away the specific angular momentum of the accretor'),
  'stellar-zeta-prescription': dict(value='SOBERMAN', note='zeta_RL follows Soberman et al. (1997) (Sec. 2.1, App. A fn. 8).',
    quote='we approximate the response of the Roche radius to mass lost'),
  'zeta-main-sequence': dict(value='2.0', note='Adopted for main-sequence donors; makes Case A more prone to instability (Sec. 4.5, App. A).',
    quote='to determine the stability of mass transfer for donor stars on the main sequence'),
  'zeta-radiative-envelope-giant': dict(value='6.0', note='Reference for Hertzsprung-gap / radiative-envelope donors; 6.5 in the earlier van Son paper (Sec. 2.1, Sec. 3).',
    quote='as our reference value for Hertzsprung-gap donor stars'),
  'chemically-homogeneous-evolution-mode': dict(value='CHE systems excluded from the analysis',
    note='A post-hoc sample cut, not necessarily a runtime flag setting (Sec. 3.1, p. 6).',
    quote='we do not include chemically homogeneously evolving systems'),
}

SUBMODEL_SUBTITLE = 'COMPAS — van Son et al. (2022b) · 25 variations on the reference model (Table 1) · 10⁷ binaries per set · cosmology adopted by reference'
SUBMODELS = [
  ('FIDUCIAL', [
    ('Reference model', '— (baseline)',
     '<b>Fid:</b> β<sub>acc</sub> = 0.5 · ζ<sub>eff</sub> = 6.0<br>f<sub>core</sub> = 0.34 · Fryer12 Delayed<br>(q<sub>crit,1</sub>, q<sub>crit,2</sub>) = (0.25, 4.32)',
     '<b>Alt:</b> —',
     'ℛ₀.₂ = 31.7 Gpc⁻³ yr⁻¹ (25.3 BBH + 6.5 BHNS). Deliberately <em>not</em> the same as the Figure 1 model, which uses thermally-limited accretion and ζ<sub>eff</sub> = 6.5; the fixed β<sub>acc</sub> here is chosen to isolate the cutoff effect.',
     'Table 1 · Table 2 · Sec. 3',
     'we adopt a fixed mass transfer efficiency value of'),
  ]),
  ('MASS TRANSFER STABILITY  (ζ<sub>eff</sub>, Table 1)', [
    ('ζ<sub>eff</sub>  ⚠ LARGEST LEVER', 'Donor response to mass loss',
     '<b>Fid:</b> ζ<sub>eff</sub> = 6.0 → q<sub>crit,2</sub> = 4.32',
     '<b>Alt:</b> 3.5, 4.5, 5.5, 6.5',
     'ℛ₀.₂ falls from 48.9 (ζ = 6.5) to 0.9 (ζ = 3.5) — a factor of ~54. Lower ζ<sub>eff</sub> shrinks the stable window, raises the cutoff mass and pushes the peak to higher masses; at 3.5 the channel makes nothing below ≈ 9 M☉.',
     'Table 1 · Table 2 · Fig. 3',
     'Lower values of zetaeff, and equivalently lower values of qcrit,2, leave less room for stable mass transfer'),
    ('ζ<sub>MS</sub>', 'Main-sequence donor response (Case A)',
     '<b>Fid:</b> ζ<sub>MS</sub> = 2 (Ge et al. 2015)',
     '<b>Alt:</b> — (not varied)',
     'Makes Case A mass transfer comparatively unstable, which is the stated reason Case A is subdominant in this channel. Flagged as a caveat, since real Case A donors are thought to be more conservative.',
     'Sec. 4.5 · App. A',
     'to determine the stability of mass transfer for donor stars on the main sequence'),
  ]),
  ('MASS TRANSFER EFFICIENCY  (β<sub>acc</sub>, Table 1)', [
    ('β<sub>acc</sub>', 'Fraction of donated mass accreted',
     '<b>Fid:</b> β<sub>acc</sub> = 0.5',
     '<b>Alt:</b> 0.0, 0.25, 0.75, 1.0',
     'ℛ₀.₂ rises monotonically 14.0 → 39.6, but the BHNS contribution collapses to zero at β<sub>acc</sub> ≥ 0.75. At β<sub>acc</sub> = 1 the distribution drops off steeply below 8 M☉; at β<sub>acc</sub> = 0 no real gap is left.',
     'Table 1 · Table 2 · Fig. 3',
     'Higher values of betaacc significantly raise the minimum value of Mprimary at constant'),
    ('Thermally-limited accretion', 'β<sub>acc</sub> from accretor thermal timescale',
     '<b>Fid:</b> fixed β<sub>acc</sub> = 0.5 in the grid',
     '<b>Alt:</b> thermal-timescale limited, C = 10<br>(the Figure 1 model)',
     'Flagged as the main caveat of the paper: a thermally-limited rate drives β<sub>acc</sub> towards zero at low q<sub>ZAMS</sub>, and those systems would pollute the 2.5–6 M☉ dearth that the paper predicts.',
     'Sec. 4.5 · p. 11',
     'is a constant factor assumed to take into account the expansion of the accreting star due to mass transfer'),
  ]),
  ('CORE MASS FRACTION  (f<sub>core</sub>, Table 1)', [
    ('f<sub>core</sub>', 'Fraction of ZAMS mass in the He core',
     '<b>Fid:</b> f<sub>core</sub> = 0.34',
     '<b>Alt:</b> 0.28, 0.31, 0.38, 0.41',
     'ℛ₀.₂ spans 4.2 → 102.8. A 20 % higher core mass fraction lets the channel reach down to the 2.5 M☉ NS limit; 20 % lower confines it to above ≈ 7 M☉. Fitted to the reference simulation rather than set as a COMPAS flag.',
     'Table 1 · Table 2 · Fig. 3',
     'Increasing the core mass fraction makes the second mass transfer phase more stable for constant values of qZAMS.'),
  ]),
  ('SUPERNOVA REMNANT MASS FUNCTION  (Sec. 3.3)', [
    ('f<sub>mix</sub>', 'Fryer et al. (2022) mixing growth time',
     '<b>Fid:</b> Fryer et al. (2012) Delayed<br>a<sub>SN</sub> = −0.9, b<sub>SN</sub> = 13.9, M<sub>thresh</sub> = 14.8',
     '<b>Alt:</b> f<sub>mix</sub> = 0.5 … 4.0<br>M<sub>crit</sub> = 5.75 M☉',
     'Only a factor ≈ 2 in rate (4.8 → 10.8), but a large change in shape: low f<sub>mix</sub> gives a shallow rise with no clear peak, f<sub>mix</sub> = 4.0 a sharp peak at 9.5 M☉. Every variation keeps the rate below 4 M☉ under 10⁻⁵ Gpc⁻³ yr⁻¹.',
     'Sec. 3.3 · Fig. 4 · Table 3',
     'higher fmix corresponds to a more rapid growth of the convection'),
  ]),
  ('ORBITAL ANGULAR MOMENTUM LOSS  (f<sub>disk</sub>, Sec. 3.3)', [
    ('f<sub>disk</sub>  ⚠ KILLS THE CHANNEL', 'Fraction of lost mass leaving via a circumbinary disk',
     '<b>Fid:</b> f<sub>disk</sub> = 0 (isotropic re-emission)',
     '<b>Alt:</b> 0.25, 0.5, 0.75, 1.0<br>ring at twice the orbital separation',
     'Non-monotonic and violent: ℛ₀.₂ = 33.1 → 122.9 (f = 0.25) → 13.1 (0.5) → 0.5 (0.75) → 0.3 (1.0). Beyond f<sub>disk</sub> ≈ 0.5 the extra angular momentum loss turns surviving binaries into stellar mergers. Directly comparable to Willcox et al.’s f<sub>γ</sub>.',
     'Sec. 3.3 · Fig. 5 · Table 3',
     'We assume the circumbinary ring to be located at twice the orbital separation'),
  ]),
]

# (parameter, value, description, source, verbatim quote) — [] if no cosmology.
COSMIC = [
]
