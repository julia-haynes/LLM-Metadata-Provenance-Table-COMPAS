# -*- coding: utf-8 -*-
"""Mandel, Müller, Riley, de Mink, Vigna-Gómez & Chattopadhyay (2021)
MNRAS 500, 1380 — arXiv:2007.03890v2

"Binary population synthesis with probabilistic remnant mass and kick prescriptions"

This is the paper that introduced the Mandel & Müller (2020) stochastic remnant-mass
and kick recipes into population synthesis — the recipes that COMPAS made its
DEFAULT by v03.22.01 (see the methods paper II column) and that van Son 2024 runs as
a variation. So it sits at the centre of the ledger's supernova rows even though it
is a short six-page paper.

⚠ It states NO COMPAS version number. That is not an oversight in this ledger: the
paper cites the code only as "the COMPAS suite (Stevenson et al. 2017; Vigna-Gómez
et al. 2018)" and gives no release string, which is why the Google Doc leaves that
cell blank. The version row is therefore honestly NOT SPECIFIED.

⚠ It also covers TWO metallicities only, solar and a tenth of solar, which is why it
reports yields per unit star formation rather than a cosmic merger rate.

NOTE ON THE GOOGLE DOC: this paper appears TWICE on the Doc list — once as "Binary
population synthesis with probabilistic remnant mass and kick prescriptions" (zenodo
5154162) and once as "Mandel & Müller 2022 stochastic remnant mass and spin
prescriptions". Both cite 2021MNRAS.500.1380M. It is one paper, one column. The two
PDFs in the folder, "Mandel 2020.pdf" and "2007.03890v2.pdf", are byte-identical.

Quotes verified against mandelmuller21.txt (real pdftotext output). Prose-only, and
stopping short of the several places where the solar-mass symbol vanishes in
extraction ("0.1 Z is specified"), where a hyphen is swallowed ("main-sequence" ->
"mainsequence", "flat-in-log" -> "flat-inlog", "Vigna-Gómez" -> "VignaGómez"), and
where a page break or running header interrupts a sentence.
"""
NS = "NOT SPECIFIED"

PAPER = dict(
    id='mandelmuller21',
    order=14,
    label='Mandel & Müller 2021',
    cite='Mandel et al. (2021)',
    arxiv='arXiv:2007.03890v2 · MNRAS 500, 1380',
    code='COMPAS (version NOT SPECIFIED)',
    focus='BNS + BHNS + BBH · stochastic remnants & kicks',
    colour='#7d5ba6',
    pdf_text='mandelmuller21.txt',
    title='Binary population synthesis with probabilistic remnant mass and kick prescriptions',
    extra='data zenodo 5154162 (per the Google Doc; not stated in the paper text) · appears twice on the Doc list — one paper',
    code_name='COMPAS',
    code_version=NS,
    systems='BNS + BHNS + BBH',
    systems_detail='All three double compact object classes, plus black hole X-ray binary progenitors — systems where a star collapses to a black hole while the companion is still non-degenerate. Low-mass ("mass-gap") black holes are conservatively defined as 2 to 4 solar masses and tracked as a separate category throughout. A merging system is one that coalesces within 14 Gyr. Only two metallicities are simulated: solar and a tenth of solar.',
    purpose='Test what the Mandel & Müller (2020) probabilistic remnant-mass and kick prescriptions do to a binary population — specifically whether they can populate the neutron-star / black-hole mass gap while staying consistent with the observed scarcity of low-mass black holes in X-ray binaries.',
    summary='Evolves one million binaries at each of two metallicities with the stochastic Mandel & Müller (2020) recipes, in which the carbon-oxygen core mass of the exploding star sets the outcome probabilistically: neutron stars guaranteed at the lowest core masses, complete fallback to a black hole at the highest, and a probabilistic regime in between. Kicks are coupled self-consistently to remnant mass, scaling as the ejected carbon-oxygen core mass over the remnant mass. Four findings. The mass gap is populated with low-mass black holes, and about a fifth of black holes born with a non-degenerate companion are low-mass — but because low-mass black holes get the largest kicks, only about a third of those binaries survive the first supernova, leaving roughly 8 per cent of surviving X-ray binary progenitors with a low-mass black hole, which matches the observed dearth. Galactic double neutron star masses are over-predicted: the first-born neutron star comes from an electron-capture supernova in over half of merging systems, giving a sharp 1.26 solar mass peak not seen in observations. GW190425-like heavy binary neutron stars are produced generically. And the revised kicks do not reproduce the observed bimodal Galactic double neutron star eccentricity distribution, because the stochastic model does not treat ultra-stripped supernovae separately and gives them mean kicks near 200 km/s rather than the 30 km/s assumed previously.',
)

DEFERRAL = "We follow the default prescriptions from these papers, with the addition of (pulsational) pair-instability supernovae following the recipes of"
DEFERRAL_SRC = 'Sec. 1 · p. 1'

PAPER_URL = 'https://doi.org/10.1093/mnras/staa3087'

CITATIONS = [
  ('Mandel & Müller (2020)',
   'https://doi.org/10.1093/mnras/staa3043',
   'THE prescription this paper tests: probabilistic remnant masses and self-consistently coupled kicks, with the default parameters from its Table 1. Now the COMPAS default.'),
  ('Stevenson et al. (2017)',
   'https://doi.org/10.1038/ncomms14906',
   'Cited as the COMPAS reference, and one of the two papers whose default prescriptions are followed. No version string is given.'),
  ('Vigna-Gómez et al. (2018)',
   'https://doi.org/10.1093/mnras/sty2463',
   'The other source of the default prescriptions followed here, and the study whose 30 km/s ultra-stripped kicks this paper departs from.'),
  ('Stevenson et al. (2019)',
   'https://doi.org/10.1038/s41550-019-0872-2',
   'The (pulsational) pair-instability supernova recipes added on top of the defaults.'),
  ('Riley et al. (2021)',
   'https://doi.org/10.1093/mnras/stab1291',
   'The chemically homogeneous evolution recipes added on top of the defaults (cited in the paper as Riley et al. 2020). This is the other paper starred in the Google Doc.'),
  ('Belczynski et al. (2008)',
   'https://doi.org/10.1086/521026',
   'The "Pessimistic" common envelope model adopted: Hertzsprung-gap donors do not survive.'),
  ('Vigna-Gómez et al. (2020)',
   'https://doi.org/10.1017/pasa.2020.31',
   'A correction to the COMPAS common envelope treatment, which the paper says accounts for its reduced binary neutron star yield relative to Neijssel et al. (2019) — not the new remnant physics.'),
  ('Kroupa (2001)',
   'https://doi.org/10.1046/j.1365-8711.2001.04022.x',
   'The initial mass function.'),
  ('Öpik (1924)',
   'https://ui.adsabs.harvard.edu/search/q=Opik%201924%20Tartu%20Obs%20Publ%2025%206',
   'The flat-in-log separation distribution.'),
  ('Sana et al. (2012)',
   'https://doi.org/10.1126/science.1223344',
   'Cited with Kroupa and Öpik for the initial distributions.'),
  ('Asplund et al. (2009)',
   'https://doi.org/10.1146/annurev.astro.46.060407.145222',
   'Solar metallicity Z = 0.014, which sets what "0.1 Z_sun" means here.'),
  ('Fryer et al. (2012)',
   'https://doi.org/10.1088/0004-637X/749/1/91',
   'The "Delayed" and "Rapid" prescriptions this work is compared against; the Rapid model is the one that enforces a mass gap.'),
  ('Hobbs et al. (2005)',
   'https://doi.org/10.1111/j.1365-2966.2005.09087.x',
   'The observed pulsar speed estimate (mean about 400 km/s) that the stochastic model comes in below.'),
  ('Neijssel et al. (2019)',
   'https://doi.org/10.1093/mnras/stz2840',
   'The previous COMPAS study the yields are compared with.'),
  ('Farr et al. (2011)',
   'https://doi.org/10.1088/0004-637X/741/2/103',
   'The sample of 20 black hole X-ray binaries with well-measured masses used for the 8 per cent test.'),
  ('Abbott et al. (2020) — GW190814',
   'https://doi.org/10.3847/2041-8213/ab960f',
   'The extreme mass ratio event this paper can only reproduce by allowing Hertzsprung-gap donors to survive a common envelope.'),
  ('Zevin et al. (2020)',
   'https://doi.org/10.3847/2041-8213/abb8c3',
   'The GW190814 formation channels, including the Channel B analogue found here.'),
  ('Ge et al. (2020)',
   'https://doi.org/10.3847/1538-4357/aba7b7',
   'Updated radial response of Hertzsprung-gap donors, which the authors note might make the GW190814 mass transfer stable rather than a common envelope.'),
  ('Tauris et al. (2015)',
   'https://doi.org/10.1088/2041-8205/846/2/L24',
   'Ultra-stripped supernovae with limited mass loss and reduced kicks — the picture the stochastic model does not reproduce.'),
  ('Andrews & Mandel (2019)',
   'https://doi.org/10.3847/2041-8213/ab5b9a',
   'The argument that default binary evolution struggles to reproduce the bimodal Galactic DNS eccentricity distribution.'),
  ('Chattopadhyay et al. (2020)',
   'https://doi.org/10.1093/mnras/staa756',
   'Galactic double neutron star selection effects, and the eccentricity comparison.'),
  ('Farrow et al. (2019)',
   'https://doi.org/10.3847/1538-4357/ab12e3',
   'The compilation of nine Galactic double neutron stars with precisely measured masses used for the chirp mass test.'),
  ('Hurley et al. (2000)',
   'https://doi.org/10.1046/j.1365-8711.2000.03426.x',
   'The stellar model underlying the core masses in the GW190814-like example.'),
]

ENTRIES = {
  # ── §1  INITIAL STELLAR POPULATION
  'Primary mass function (IMF)': dict(
    value='Kroupa (2001)<br>M₁ sampled over 5 – 150 M☉',
    desc='Same IMF and same sampled range as van Son 2024, reaching low enough to produce neutron star progenitors.',
    src='Sec. 1 · p. 1',
    quote='Primary masses are sampled from a Kroupa initial mass function with secondary masses following a flat distribution in the mass ratio',
    num={'M1_min_Msun': 5.0, 'M1_max_Msun': 150.0},
    primary='M1_min_Msun',
  ),
  'Mass ratio distribution': dict(
    value='Flat in mass ratio<br>(no bounds stated)',
    desc='The distribution is named but its limits are not given, unlike van Son 2022a and 2024 which both state 0.01 to 1.0.',
    src='Sec. 1 · p. 1',
    quote='with secondary masses following a flat distribution in the mass ratio',
  ),
  'Initial orbital separation / period distribution': dict(
    value='Flat in log a, 0.01 – 1000 au<br>orbits initially circular',
    desc='Stated together with circularity, which makes this one of the few columns that pins both down in a single sentence.',
    src='Sec. 1 · p. 1',
    quote='while separations of initially circular binaries follow a flat',
    num={'a_min_AU': 0.01, 'a_max_AU': 1000.0},
    primary='a_min_AU',
  ),
  'Initial eccentricity distribution': dict(
    value='Circular at birth (e = 0)',
    desc='Stated explicitly in the same sentence as the separation distribution.',
    src='Sec. 1 · p. 1',
    quote='while separations of initially circular binaries follow a flat',
    num={'e_init': 0.0},
    primary='e_init',
  ),
  'Initial stellar rotation': dict(value=NS, desc='Not stated. Rotation enters only implicitly through the added chemically homogeneous evolution recipes.', src='—', quote=''),
  'Binary fraction': dict(
    value=NS + '<br>(but the yield normalisation is stated:<br>1e6 binaries ≈ 90 million M☉ of star formation)',
    desc='No binary fraction is given. What is stated is the conversion that matters for reading Table 1: the simulated million binaries represent about 90 million solar masses of total star formation at each metallicity, and all yields are quoted per million solar masses.',
    src='Sec. 1 · p. 1',
    quote='million solar masses of total star formation',
    num={'total_star_formation_Msun': 90000000.0},
  ),
  'Metallicity sampling / grid': dict(
    value='<b>Two metallicities only:</b><br>Z = 0.014 (solar) and Z = 0.1 Z☉<br><br>1e6 binaries at each',
    desc='The narrowest metallicity coverage of any column in the ledger, and the reason this paper reports yields per unit star formation rather than a cosmic rate. The Google Doc notes this too ("only 2 metallicities"). Comparisons of metallicity trends against van Son 2024, which uses 12 values, should be made with that in mind.',
    src='Sec. 1 · p. 1',
    quote='We consider solar metallicity (Z = 0.014, Asplund',
    num={'n_metallicities': 2.0, 'Z_solar': 0.014, 'Z_low_in_Zsun': 0.1},
    primary='n_metallicities',
  ),
  'Solar metallicity reference': dict(
    value='Z☉ = 0.014 (Asplund et al. 2009)',
    desc='Same value as van Son 2022a and 2024 — consistent across the van Son / COMPAS lineage.',
    src='Sec. 1 · p. 1',
    quote='We consider solar metallicity (Z = 0.014, Asplund',
    num={'Z_sun': 0.014},
    primary='Z_sun',
  ),
  'Chemically homogeneous evolution (CHE / QHE) treatment': dict(
    value='CHE included, following Riley et al. (2021)<br>(cited as Riley et al. 2020)',
    desc='Added on top of the default prescriptions rather than inherited. Notable for this ledger because the recipe cited is the Chemically Homogeneous Evolution paper starred in the Google Doc and still missing from the table.',
    src='Sec. 1 · p. 1',
    quote='chemically homogeneous evolution following the recipes of',
  ),
  'Sample size': dict(
    value='1 × 10⁶ binaries per metallicity<br>(2 metallicities)<br><br>≈ 90 million M☉ of star formation each',
    desc='A relatively small run by the standards of this ledger — an order of magnitude below van Son 2022a — which is consistent with the paper being a focused test of one prescription rather than a rate calculation.',
    src='Sec. 1 · p. 1',
    quote='A total of 1 million binaries are evolved with zero-age',
    num={'n_binaries_per_Z': 1000000.0, 'n_metallicities': 2.0,
         'total_star_formation_Msun': 90000000.0},
    primary='n_binaries_per_Z',
  ),

  # ── §2  STELLAR EVOLUTION & WINDS
  'Stellar evolution framework': dict(
    value='COMPAS — <b>version NOT SPECIFIED</b><br>(Stevenson et al. 2017;<br>Vigna-Gómez et al. 2018)<br><br>Default prescriptions from those papers,<br>plus PPISN (Stevenson et al. 2019)<br>plus CHE (Riley et al. 2021)',
    desc='The only column in the ledger with no COMPAS release string at all — the code is cited by paper, not by version. That is a real gap for reproducibility, and it is why this row cannot be compared cleanly against the two code columns. The physics is specified as "the defaults of those two papers plus two named additions", which is at least an unambiguous recipe even without a version.',
    src='Sec. 1 · p. 1',
    quote='We follow the default prescriptions from these papers, with the addition of (pulsational) pair-instability supernovae following the recipes of',
  ),
  'Core overshooting': dict(value=NS, desc='Not stated; inherited with the default prescriptions.', src='Sec. 1 · p. 1', quote=''),
  'Hot star / OB-type winds': dict(value=NS, desc='Not stated; inherited with the default prescriptions.', src='Sec. 1 · p. 1', quote=''),
  'Cool star winds / Reimers η': dict(value=NS, desc='Not stated; inherited with the default prescriptions.', src='Sec. 1 · p. 1', quote=''),
  'Wolf–Rayet / He-star winds': dict(
    value=NS + '<br>(but winds are named as the dominant<br>metallicity effect on BBH progenitors)',
    desc='No prescription is named. The paper does attribute its order-of-magnitude drop in merging BBH yield at solar metallicity to strong winds reducing the binary mass and widening the orbit past the point where it can merge, compounded by a reduced window for radial growth during core helium burning.',
    src='Sec. 4 · p. 4',
    quote='metallicity has a very large impact on the progenitors of binary black holes which suffer from strong winds at high metallicity',
  ),
  'LBV / Eddington-limited winds': dict(value=NS, desc='Not stated; inherited with the default prescriptions.', src='Sec. 1 · p. 1', quote=''),
  'Stellar track mass range': dict(
    value=NS + '<br>(sampled 5 – 150 M☉)',
    desc='No track range stated. The authors do flag a related limitation: population synthesis models may under-predict the masses of stripped donors that transferred mass on the main sequence.',
    src='Sec. 4 · p. 5',
    quote='population synthesis models may under-predict the masses of stripped donor',
    num={'M1_min_Msun': 5.0, 'M1_max_Msun': 150.0},
  ),

  # ── §3  MASS TRANSFER & ROCHE LOBE OVERFLOW
  'Roche lobe radius': dict(value=NS, desc='Not stated; inherited with the default prescriptions.', src='Sec. 1 · p. 1', quote=''),
  'Mass transfer stability criterion': dict(
    value=NS + '<br>(inherited)<br><br>Authors note the GW190814-like case might<br>be <em>stable</em> under the updated Hertzsprung-gap<br>radial response of Ge et al. (2020)',
    desc='Not specified, but the paper raises the criterion as an open question in exactly the place it matters: the mass transfer it has to treat as a surviving common envelope to make GW190814 might be dynamically stable under newer donor-response models.',
    src='Sec. 4 · p. 5',
    quote='this mass transfer could, in fact, be dynamically stable based on updated models of the radial response of Hertzsprung-gap donors to mass loss',
  ),
  'Accretion efficiency (RLOF)': dict(value=NS, desc='Not stated; inherited with the default prescriptions.', src='Sec. 1 · p. 1', quote=''),
  'Accretion limit — BH accretor / Eddington multiplier': dict(
    value='Eddington limited<br>(explicitly: accretion onto a NS raises its<br>mass by no more than 0.001 M☉)',
    desc='Quantified, which is unusual and consequential here. Because Eddington-limited accretion adds almost nothing to the first-born neutron star, its electron-capture birth mass of 1.26 M☉ survives to become a sharp peak in the predicted double neutron star mass distribution that observations do not show. The paper names super-Eddington accretion as one possible fix.',
    src='Sec. 3 · p. 3 · Sec. 4 · p. 5',
    quote='Subsequent Eddington-limited accretion raises its mass by no more than 0.001',
    num={'max_NS_accretion_Msun': 0.001},
    primary='max_NS_accretion_Msun',
  ),
  'Angular momentum loss (non-conservative MT)': dict(
    value=NS + '<br>(noted that Eddington-limited mass transfer<br>onto a BH is "almost completely<br>non-conservative")',
    desc='No prescription named. The statement appears in the GW190814 discussion, where near-total non-conservation is what allows stable mass transfer to harden the binary enough.',
    src='Sec. 4 · p. 5',
    quote='is expected to be almost completely non-conservative',
  ),
  'Orbit circularisation': dict(
    value='Orbits circular at birth; eccentricity then set<br>by natal kicks and decayed by GW emission',
    desc='No circularisation-at-RLOF rule. Eccentricity is instead an output: the paper follows the period–eccentricity distribution of double neutron stars at formation and again after 100 Myr of gravitational-wave orbital decay.',
    src='Sec. 1 · p. 1 · Sec. 3 · Fig. 3',
    quote='while separations of initially circular binaries follow a flat',
  ),
  'AIC (accretion-induced collapse)': dict(value=NS, desc='Not stated.', src='—', quote=''),
  'Ultra-stripped SN': dict(
    value='<b>NOT treated separately</b> by the stochastic model<br>→ mean ultra-stripped kicks ≈ 200 km s⁻¹<br><br>vs 30 km s⁻¹ assumed in Vigna-Gómez et al. (2018)<br><br>This is the paper’s main negative result',
    desc='The most important row in this column. Earlier COMPAS work assigned ultra-stripped supernovae a small dedicated kick; the Mandel & Müller recipe has no separate ultra-stripped category and instead derives the kick from ejected core mass over remnant mass, which still yields a mean near 200 km/s. The consequence is that the low-eccentricity population of Galactic double neutron stars is depleted relative to earlier models, and the observed bimodal eccentricity distribution is not reproduced. The paper concludes there is missing physics if all observed field DNS formed through isolated binary evolution.',
    src='Sec. 3 · pp. 3–4',
    quote='does not treat ultra-stripped supernovae separately from other supernova types',
    num={'mean_kick_USSN_km_s': 200.0, 'mean_kick_USSN_previous_km_s': 30.0},
    primary='mean_kick_USSN_km_s',
  ),

  # ── §4  COMMON ENVELOPE (CE) EVOLUTION
  'CE energy formalism': dict(
    value=NS + '<br>(inherited; but a COMPAS CE <em>correction</em><br>from Vigna-Gómez et al. 2020 is credited with<br>the reduced BNS yield)',
    desc='No formalism restated. The paper is careful about attribution in a way that matters for this ledger: its lower binary neutron star yield relative to Neijssel et al. (2019) is credited to a code correction in the common envelope treatment, explicitly NOT to the new remnant and kick physics.',
    src='Sec. 4 · p. 4',
    quote='this is largely a consequence of a correction to the treatment of the common envelope phase in COMPAS',
  ),
  'CE efficiency (α<sub>CE</sub>)': dict(value=NS, desc='Not stated; inherited with the default prescriptions.', src='Sec. 1 · p. 1', quote=''),
  'Envelope binding energy (λ<sub>CE</sub>)': dict(value=NS, desc='Not stated; inherited with the default prescriptions.', src='Sec. 1 · p. 1', quote=''),
  'HG donor CE survival / merger condition': dict(
    value='<b>Pessimistic (Belczynski et al. 2008):</b><br>Hertzsprung-gap donors do not survive a CE<br><br>Post-CE RLOF → merge during the phase<br><br>⚠ Relaxed as a variation: GW190814-like systems<br>form <em>only</em> if HG donors are allowed to survive',
    desc='Two conditions stated precisely, and then one of them deliberately broken. Under the standard pessimistic model the paper cannot make GW190814; allowing Hertzsprung-gap donors to survive a common envelope produces about 3e-8 such systems per solar mass of star formation at a tenth of solar metallicity. The authors say plainly that this is inconsistent with their default model — a well-flagged assumption rather than a quiet one.',
    src='Sec. 1 · p. 1 · Sec. 4 · p. 5',
    quote='We do not allow donors that are crossing the Hertzsprung gap to survive a common-envelope phase',
    num={'GW190814_like_yield_per_Msun': 3e-08},
  ),
  'Case BB mass transfer handling': dict(
    value=NS + '<br>(discussed as a possible fix: super-Eddington<br>accretion during case BB mass transfer onto<br>the neutron star primary)',
    desc='No treatment specified. Case BB appears in the discussion of why the predicted double neutron star masses are too low at the peak — the paper suggests significant super-Eddington accretion during case BB transfer as one way to broaden the distribution.',
    src='Sec. 3 · p. 3',
    quote='transfer from a post-He-main-sequence secondary onto the',
  ),

  # ── §5  SUPERNOVAE & COMPACT REMNANTS
  'Remnant mass prescription': dict(
    value='<b>Mandel &amp; Müller (2020) — probabilistic</b><br>default parameters from its Table 1<br><br>Driven by the carbon-oxygen core mass:<br>• low M<sub>CO</sub> → NS guaranteed<br>• high M<sub>CO</sub> → BH with complete fallback<br>• between → probabilistic, incl. BH with<br>&nbsp;&nbsp;significant SN mass loss<br><br>Stochastic scatter on top',
    desc='The prescription the whole column exists to test, and the one that became the COMPAS default by v03.22.01. Its defining feature is that identical progenitors do not give identical remnants — the outcome is drawn, not computed. Compare the deterministic Fryer et al. (2012) mapping used by every other result column in this ledger.',
    src='Sec. 1 · pp. 1–2',
    quote='recipes for compact remnant masses and kicks, with the default parameters from Table 1 in that paper',
  ),
  'NS mass distribution': dict(
    value='Output, not input.<br><br>First-born NS from an electron-capture SN in<br>&gt; half of merging DNS → birth mass 1.26 M☉<br>→ a sharp peak <em>not</em> seen in observations<br><br>Chirp masses over-predicted: a third exceed<br>PSR J1913+1102 (probability 3 %)',
    desc='One of the paper’s two honest failures, reported as such. Because more than half of first-born neutron stars in merging systems come from electron-capture supernovae at a fixed 1.26 M☉, and Eddington-limited accretion adds at most 0.001 M☉, the model produces a spike the observations do not have. The authors suggest either a broader range of electron-capture birth masses or significant super-Eddington accretion, and note that binary-stripped cores could reduce remnant masses by a few hundredths of a solar mass relative to the single-star calibration.',
    src='Sec. 3 · pp. 3–4',
    quote='The first-born neutron star is formed in an electron-capture supernova in more than half of merging double neutron stars',
    num={'NS_ECSN_birth_mass_Msun': 1.26, 'frac_exceeding_J1913_chance_percent': 3.0},
    primary='NS_ECSN_birth_mass_Msun',
  ),
  'Pulsational pair-instability SN (PPISN)': dict(
    value='Included, following Stevenson et al. (2019)',
    desc='Added explicitly on top of the default prescriptions, alongside the CHE recipes. No thresholds are quoted.',
    src='Sec. 1 · p. 1',
    quote='pair-instability supernovae following the recipes of',
  ),
  'ECSN mass thresholds': dict(
    value=NS + '<br>(thresholds not given, but ECSN dominate:<br>&gt; half of first-born NS in merging DNS,<br>at a birth mass of 1.26 M☉<br>mean ECSN kick ≈ 40 km s⁻¹)',
    desc='The boundaries are inherited, but their consequences are quantified in detail — the electron-capture channel is the single largest contributor to first-born neutron stars in merging systems, and its mean kick is the smallest of the three supernova classes reported.',
    src='Sec. 3 · pp. 3–4',
    quote='mean natal kicks for electron capture supernovae are only',
    num={'NS_ECSN_birth_mass_Msun': 1.26, 'mean_kick_ECSN_km_s': 40.0},
    primary='mean_kick_ECSN_km_s',
  ),
  'Maximum NS mass': dict(
    value='Model threshold used for comparison: 2.0 M☉<br><br>Observational context quoted: Galactic NS<br>suggest a likely maximum of ≈ 2.1 M☉',
    desc='Two different numbers doing two different jobs. The 2.0 M☉ figure is the neutron star / black hole boundary used when comparing yields against the Fryer "Delayed" prescription; the 2.1 M☉ figure is an observational statement about Galactic neutron stars, not a model setting. Keeping them apart matters because the mass gap this paper populates sits immediately above them.',
    src='Sec. 2 · p. 2 · Sec. 4 · p. 4',
    quote='when using the same mass threshold of 2.0',
    num={'M_NS_BH_threshold_Msun': 2.0, 'M_NS_max_observed_Msun': 2.1},
    primary='M_NS_BH_threshold_Msun',
  ),
  'Neutrino mass loss correction': dict(value=NS, desc='Not stated separately; mass loss at collapse is folded into the probabilistic remnant prescription.', src='—', quote=''),
  'BH natal kick': dict(
    value='<b>Coupled to remnant mass</b>, not fallback-scaled:<br>kick ∝ (ejected M<sub>CO</sub>) / (remnant mass)<br>with stochastic scatter<br><br>→ low-mass BHs get the <em>largest</em> kicks<br>→ only ~1/3 of their binaries survive SN1<br>&nbsp;&nbsp;&nbsp;vs ≈ 97 % for BHs above 5 M☉',
    desc='The mechanism that resolves the paper’s central tension. Low-mass black hole birth involves the most mass loss and therefore the biggest kick, so those binaries are preferentially disrupted — which is why a population in which a fifth of black holes are low-mass yields only about 8 per cent of surviving X-ray binary progenitors with a low-mass black hole. Note this is a different scaling from the Fryer fallback reduction used elsewhere in the ledger.',
    src='Sec. 1 · p. 2 · Sec. 2 · p. 2',
    quote='binaries with low-mass black holes are the most likely to be disrupted by supernovae',
    num={'frac_survive_SN1_highmass_BH_percent': 97.0,
         'frac_lowmass_BH_XRB_progenitors_percent': 8.0},
    primary='frac_lowmass_BH_XRB_progenitors_percent',
  ),
  'BH spin / NS radius': dict(value=NS, desc='Not stated. Despite the Google Doc title mentioning spin prescriptions, this paper is about masses and kicks only.', src='—', quote=''),

  # ── §6  NATAL KICKS
  'Core-collapse SN kick σ': dict(
    value='No Maxwellian σ — kicks are <em>derived</em><br>from remnant mass, with stochastic scatter<br><br>Resulting means:<br>regular core collapse ≈ 300 km s⁻¹<br>ultra-stripped ≈ 200 km s⁻¹<br>electron capture ≈ 40 km s⁻¹<br><br>vs Hobbs et al. (2005) observed mean ≈ 400',
    desc='A structurally different answer from every other column: there is no input dispersion to quote, because the kick follows from the remnant. The three resulting means are stated, which makes this column directly comparable to the Maxwellian columns despite the different formalism. The authors note their core-collapse mean sits below the observed pulsar speed mean and point to evolutionary and selection effects.',
    src='Sec. 3 · p. 4',
    quote='those associated with neutron star birth through regular core collapse supernovae are',
    num={'mean_kick_CCSN_km_s': 300.0, 'mean_kick_USSN_km_s': 200.0,
         'mean_kick_ECSN_km_s': 40.0, 'Hobbs_observed_mean_km_s': 400.0},
    primary='mean_kick_CCSN_km_s',
  ),
  'Low-kick σ (ECSN / USSN / AIC)': dict(
    value='<b>No separate low-kick class</b><br>ECSN mean ≈ 40 km s⁻¹ emerges from the model<br>USSN mean ≈ 200 km s⁻¹ — much larger than the<br>30 km s⁻¹ used in earlier COMPAS work',
    desc='The absence of a dedicated ultra-stripped kick is the deliberate design choice whose consequences this paper measures. It reduces ultra-stripped kicks relative to typical core collapse, bringing them in line with low-mass iron core collapse, but nowhere near the 30 km/s of earlier studies.',
    src='Sec. 3 · pp. 3–4',
    quote='does not treat ultra-stripped supernovae separately from other supernova types',
    num={'mean_kick_ECSN_km_s': 40.0, 'mean_kick_USSN_km_s': 200.0,
         'mean_kick_USSN_previous_km_s': 30.0},
    primary='mean_kick_USSN_km_s',
  ),
  'Kick mass scaling': dict(
    value='Momentum-preserving:<br>kick ∝ ejected carbon-oxygen core mass,<br>inversely ∝ remnant mass<br>+ stochastic scatter',
    desc='Stated as a physical argument rather than a fitting formula — the ejected core mass is a proxy for the asymmetric part of the ejecta, so the ratio characterises the asymmetric linear momentum per unit remnant mass. This is the scaling COMPAS adopted as its default by v03.22.01.',
    src='Sec. 1 · p. 2 · Sec. 3 · p. 4',
    quote='which characterises the asymmetric ejection of linear momentum, and inversely proportional to the remnant mass',
  ),
  'Kick direction': dict(value=NS, desc='Not stated.', src='—', quote=''),

  # ── §7  TIDES & ORBITAL EVOLUTION
  'Stellar tides': dict(value=NS, desc='Not stated; inherited with the default prescriptions.', src='Sec. 1 · p. 1', quote=''),
  'GW inspiral': dict(
    value='Merger criterion: coalescence within 14 Gyr<br>("the approximate current age of the Universe")<br><br>Orbital decay also followed over 100 Myr for the<br>double neutron star eccentricity comparison',
    desc='The same 14 Gyr threshold van Son 2024 uses, stated here with its justification. The 100 Myr decay step is specific to the eccentricity test and is chosen as a typical spin-down age for the mildly recycled pulsars in the observed sample.',
    src='Sec. 1 · p. 1 · Sec. 3 · Fig. 3',
    quote='we select only those that will merge within the approximate current age of the Universe, 14',
    num={'coalescence_time_max_Gyr': 14.0, 'orbital_decay_check_Myr': 100.0},
    primary='coalescence_time_max_Gyr',
  ),
  'Angular momentum loss (γ)': dict(value=NS, desc='Not stated; inherited with the default prescriptions.', src='Sec. 1 · p. 1', quote=''),
  'Stellar merger outcome': dict(
    value='Merger on post-CE Roche lobe overflow:<br>binaries in RLOF immediately after ejecting the<br>envelope are assumed to fail and merge',
    desc='An explicit and often-unstated rule, given here as a deliberate modelling assumption. COMPAS methods paper II later makes this a switchable option, off by default — so this column matches the code default on that row.',
    src='Sec. 1 · p. 1',
    quote='We assume that any binaries that would experience Roche-lobe overflow immediately after ejecting the common envelope would, in fact, fail to survive the ejection of the envelope and merge during this phase.',
  ),

  # ── §8  WHITE DWARF / COMPACT OBJECT PHYSICS
  'WD cooling / accretion & collapse': dict(value=NS, desc='Not stated. No white dwarf physics; the paper is about neutron stars and black holes.', src='—', quote=''),
  'Nova efficiency': dict(value=NS, desc='Not stated.', src='—', quote=''),
  'Magnetic braking': dict(value=NS, desc='Not stated.', src='—', quote=''),
  'Rejuvenation (post-accretion mixing)': dict(
    value=NS + '<br>(but mass ratio reversal through conservative<br>main-sequence mass transfer is central to the<br>GW190814-like channel)',
    desc='No rejuvenation prescription. The GW190814-like example turns on conservative mass transfer while both stars are on the main sequence, with mass ratio reversal — exactly the regime where rejuvenation and main-sequence core-mass tracking matter, and where COMPAS methods paper II later changed the default.',
    src='Sec. 4 · p. 5',
    quote='mass transfer while both stars are still on the main sequence',
  ),

  # ── §9  COSMOLOGICAL MODEL & STAR FORMATION RATE
  'Cosmological parameters': dict(
    value=NS + '<br>(no cosmic integration — yields are given per<br>million M☉ of star formation, not as rates)',
    desc='Deliberately not a rate paper. With only two metallicities there is no basis for a cosmic integration, so results are reported as formation yields.',
    src='Sec. 4 · p. 4',
    quote='Table 1 summarises the predicted yields per million solar masses of star formation at two metallicities',
  ),
  'Metallicity-dependent SFRD': dict(value=NS, desc='Not applied. Only two discrete metallicities are simulated.', src='—', quote=''),
  'Local merger rate density': dict(
    value='No rate. <b>Yields per 10⁶ M☉ (×10⁻⁶ M☉⁻¹):</b><br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Z☉&nbsp;&nbsp;&nbsp;&nbsp;0.1 Z☉<br>BNS&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;4.6&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2.0<br>BHNS (all)&nbsp;&nbsp;16&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;9.0<br>— low-mass BH&nbsp;4.7&nbsp;&nbsp;1.7<br>BBH (all)&nbsp;&nbsp;&nbsp;&nbsp;11&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;67<br>— low-mass BH&nbsp;6.2&nbsp;&nbsp;4.2',
    desc='Yields rather than rates, but directly comparable in structure to the other columns and unusually complete — split by class and by whether a low-mass black hole is involved. Two results stand out: merging BBH yield rises by a factor of six from solar to a tenth solar, while binaries involving neutron stars <em>fall</em> at lower metallicity, which the paper notes is unlike Neijssel et al. (2019). And the low-mass-BH BBH yield actually decreases at low metallicity under the default settings.',
    src='Sec. 4 · Table 1 · p. 5',
    quote='Table 1 summarises the predicted yields per million solar masses of star formation at two metallicities',
    num={'yield_BNS_Zsun': 4.6, 'yield_BNS_01Zsun': 2.0,
         'yield_BHNS_Zsun': 16.0, 'yield_BHNS_01Zsun': 9.0,
         'yield_BHNS_lowmassBH_Zsun': 4.7, 'yield_BHNS_lowmassBH_01Zsun': 1.7,
         'yield_BBH_Zsun': 11.0, 'yield_BBH_01Zsun': 67.0,
         'yield_BBH_lowmassBH_Zsun': 6.2, 'yield_BBH_lowmassBH_01Zsun': 4.2},
    primary='yield_BBH_Zsun',
  ),

  # ── §10  KEY ASTROPHYSICAL RESULTS & CHANNELS
  'Formation channel split': dict(
    value='No channel classification.<br><br>Populations split instead by <em>outcome</em>:<br>BNS · BHNS · BBH · BH X-ray binary progenitors<br>and by whether a low-mass (2 – 4 M☉) BH<br>is involved',
    desc='This paper cuts the population by remnant type rather than by evolutionary pathway, which is the natural split for a question about remnant masses. The one pathway statement it does make is negative: the GW190814-like systems it can only form by relaxing the CE assumption resemble Channel B of Zevin et al. (2020).',
    src='Sec. 2 · p. 2 · Sec. 4 · p. 5',
    quote='We identify any binaries in which one star collapses into a black hole while the companion is non-degenerate as potential',
    num={'lowmass_BH_min_Msun': 2.0, 'lowmass_BH_max_Msun': 4.0},
  ),
  'Headline quantitative result': dict(
    value='<b>The mass gap is populated — and that is still<br>consistent with X-ray binary observations.</b><br><br>≈ 1/5 of BHs born with a non-degenerate<br>companion are low-mass (2 – 4 M☉)<br><br>but only ≈ 1/3 of those binaries survive SN1<br>(vs ≈ 97 % for BHs above 5 M☉)<br><br>→ only ≈ 8 % of surviving BH X-ray binary<br>progenitors host a low-mass BH<br>→ 1 or 2 of the 20 well-measured systems',
    desc='A clean resolution of an apparent contradiction, and the reason this prescription was adopted. A remnant model that fills the mass gap looks immediately incompatible with the observed scarcity of low-mass black holes in X-ray binaries — until you notice that the same physics giving low-mass black holes also gives them the biggest kicks. The paper even computes the chance of seeing none in a sample of 20: about 19 per cent.',
    src='Abstract · Sec. 2 · pp. 2–3',
    quote='this prescription populates the putative mass gap between neutron stars and black',
    num={'frac_lowmass_BH_at_birth_percent': 20.0,
         'frac_survive_SN1_highmass_BH_percent': 97.0,
         'frac_lowmass_BH_XRB_progenitors_percent': 8.0,
         'n_XRB_sample': 20.0, 'prob_none_observed_percent': 19.0},
    primary='frac_lowmass_BH_XRB_progenitors_percent',
  ),
  'Mass-distribution features': dict(
    value='<b>Mass gap filled</b> with low-mass BHs<br>(2 – 4 M☉)<br><br>DNS chirp masses over-predicted:<br>a third exceed PSR J1913+1102<br><br>GW190425 (M<sub>c</sub> = 1.44 ± 0.02 M☉) reproduced:<br>3 % of merging BNS exceed 1.42 M☉ at Z☉,<br>8 % at 0.1 Z☉ → 4 % / 12 % after GW selection<br><br>BBH mass ratios: median 0.6 · q &lt; 0.3 in 15 %<br>q &lt; 0.2 in only 2 % · none as extreme as GW190814',
    desc='The clearest set of testable numbers in this column. Note the direction of the two DNS results: heavy binary neutron stars like GW190425 come out generically, so no exotic model is needed — but the whole Galactic double neutron star mass distribution is shifted too high, which is a problem rather than a success. The mass ratio numbers set a hard limit on forming GW190814 in the default model.',
    src='Abstract · Sec. 3 · pp. 3–4 · Sec. 4 · p. 5',
    quote='could be generically produced through binary population synthesis',
    num={'GW190425_chirp_mass_Msun': 1.44, 'frac_exceed_142_Zsun_percent': 3.0,
         'frac_exceed_142_01Zsun_percent': 8.0, 'median_BBH_q': 0.6,
         'frac_q_below_03_percent': 15.0, 'frac_q_below_02_percent': 2.0},
    primary='median_BBH_q',
  ),
  'Sensitivity of the result': dict(
    value='No systematic variation grid.<br><br>One assumption deliberately relaxed:<br>allowing HG donors to survive a CE →<br>GW190814-like systems appear (≈ 3e−8 per M☉)<br><br>Compared against Fryer et al. (2012) “Delayed”:<br>BBH yields <em>increase</em> at both metallicities',
    desc='Not a variation study, but the two comparisons it does make are the useful ones. Relaxing the pessimistic CE assumption is the only way it can produce GW190814. And against the Fryer "Delayed" prescription at a matched 2.0 M☉ neutron-star/black-hole threshold, the stochastic recipe raises BBH yields at both metallicities — a like-for-like statement of what swapping the prescription does.',
    src='Sec. 4 · pp. 4–5',
    quote='if we allow Hertzsprung-gap donors to survive common-envelope evolution',
    num={'GW190814_like_yield_per_Msun': 3e-08, 'M_NS_BH_threshold_Msun': 2.0},
  ),
  'Orbital outcome of stable MT': dict(
    value='In the GW190814-like channel: conservative<br>MS mass transfer with mass ratio reversal,<br>then stable MT from the HG primary <em>widens</em><br>the orbit; the CE later hardens it<br><br>At high Z, winds widen BBHs past merging',
    desc='Two opposite outcomes described in the same paper. In the GW190814 channel stable mass transfer widens the orbit and it takes a common envelope to harden it. Separately, the metallicity trend is attributed partly to winds reducing the binary mass and widening the orbit so much that it can no longer merge — the mechanism van Son 2024 later looks for and fails to find.',
    src='Sec. 4 · pp. 4–5',
    quote='reducing the binary mass and widening the binary so much that it can no longer merge',
  ),
  'Implication flagged by the authors': dict(
    value='The revised kicks do <em>not</em> explain the observed<br>Galactic DNS period–eccentricity distribution<br><br>→ "missing physics in the model if, in fact, all<br>observed field double neutron stars are formed<br>through the isolated binary evolution channel"',
    desc='An unusually direct negative conclusion, and the reason this column is valuable in the ledger: the prescription that COMPAS went on to adopt as its default was published with an explicit statement of what it fails to reproduce. The predicted eccentricity distribution is broad and flat rather than showing the observed clusters near 0.1 and 0.6, and the low-eccentricity population is actively depleted relative to Vigna-Gómez et al. (2018) by the larger ultra-stripped kicks.',
    src='Abstract · Sec. 3 · p. 4',
    quote='there is missing physics in the model if, in fact, all observed field',
  ),

}

FLAGS = {
  'version': dict(value=NS,
    note='No COMPAS release string anywhere in the paper — the code is cited only as Stevenson et al. (2017) and Vigna-Gómez et al. (2018). This is why the Google Doc leaves the version cell blank.',
    quote='We follow the default prescriptions from these papers, with the addition of (pulsational) pair-instability supernovae following the recipes of'),
  'number-of-systems': dict(value='1000000 per metallicity (2 metallicities)',
    note='About 90 million solar masses of star formation at each (Sec. 1, p. 1).',
    quote='A total of 1 million binaries are evolved with zero-age'),
  'initial-mass-function': dict(value='KROUPA', note='Kroupa (2001) (Sec. 1, p. 1).',
    quote='Primary masses are sampled from a Kroupa initial mass function with secondary masses following a flat distribution in the mass ratio'),
  'initial-mass-function-min': dict(value='5', note='Sec. 1, p. 1.', quote='A total of 1 million binaries are evolved with zero-age'),
  'initial-mass-function-max': dict(value='150', note='Sec. 1, p. 1.', quote='A total of 1 million binaries are evolved with zero-age'),
  'mass-ratio-distribution': dict(value='FLAT', note='Bounds not stated (Sec. 1, p. 1).',
    quote='with secondary masses following a flat distribution in the mass ratio'),
  'semi-major-axis-distribution': dict(value='FLATINLOG', note='Öpik (1924) (Sec. 1, p. 1).',
    quote='while separations of initially circular binaries follow a flat'),
  'semi-major-axis-min': dict(value='0.01 AU', note='Sec. 1, p. 1.', quote='while separations of initially circular binaries follow a flat'),
  'semi-major-axis-max': dict(value='1000 AU', note='Sec. 1, p. 1.', quote='while separations of initially circular binaries follow a flat'),
  'eccentricity-distribution': dict(value='ZERO', note='Binaries initially circular (Sec. 1, p. 1).',
    quote='while separations of initially circular binaries follow a flat'),
  'metallicity-distribution': dict(value='Two discrete values: 0.014 and 0.0014',
    note='Solar (Asplund et al. 2009) and a tenth of solar (Sec. 1, p. 1).',
    quote='We consider solar metallicity (Z = 0.014, Asplund'),
  'chemically-homogeneous-evolution-mode': dict(value='Included, per Riley et al. (2021)',
    note='Added on top of the default prescriptions; cited in the paper as Riley et al. (2020) (Sec. 1, p. 1).',
    quote='chemically homogeneous evolution following the recipes of'),
  'remnant-mass-prescription': dict(value='MULLERMANDEL (probabilistic)',
    note='Mandel & Müller (2020), default parameters from its Table 1. Outcome set by the carbon-oxygen core mass, probabilistically (Sec. 1, pp. 1-2).',
    quote='recipes for compact remnant masses and kicks, with the default parameters from Table 1 in that paper'),
  'pulsational-pair-instability': dict(value='TRUE', note='Following Stevenson et al. (2019) (Sec. 1, p. 1).',
    quote='pair-instability supernovae following the recipes of'),
  'pulsational-pair-instability-prescription': dict(value='STEVENSON2019',
    note='Added on top of the default prescriptions (Sec. 1, p. 1).',
    quote='pair-instability supernovae following the recipes of'),
  'maximum-neutron-star-mass': dict(value='2.0 (threshold used for the Fryer comparison)',
    note='The paper separately quotes an observational likely maximum of about 2.1 Msun for Galactic neutron stars, which is not a model setting (Sec. 2, p. 2; Sec. 4, p. 4).',
    quote='when using the same mass threshold of 2.0'),
  'common-envelope-allow-radiative-envelope-survive': dict(value='FALSE (Pessimistic) — relaxed in one variation',
    note='Belczynski et al. (2008) Pessimistic model. Relaxing it is the only way the paper forms GW190814-like systems (Sec. 1, p. 1; Sec. 4, p. 5).',
    quote='We do not allow donors that are crossing the Hertzsprung gap to survive a common-envelope phase'),
  'common-envelope-allow-immediate-RLOF-post-CE-survive': dict(value='FALSE',
    note='Binaries in Roche lobe overflow immediately after envelope ejection are assumed to merge (Sec. 1, p. 1).',
    quote='We assume that any binaries that would experience Roche-lobe overflow immediately after ejecting the common envelope would, in fact, fail to survive the ejection of the envelope and merge during this phase.'),
  'USSN-kicks-override-mandel-muller': dict(value='FALSE — no separate ultra-stripped treatment',
    note='The stochastic model derives ultra-stripped kicks from the same relation as other SNe, giving means near 200 km/s rather than the 30 km/s of earlier work (Sec. 3, pp. 3-4).',
    quote='does not treat ultra-stripped supernovae separately from other supernova types'),
  'eddington-accretion-factor': dict(value='Eddington limited',
    note='Accretion onto the first-born neutron star raises its mass by no more than 0.001 Msun (Sec. 3, p. 3).',
    quote='Subsequent Eddington-limited accretion raises its mass by no more than 0.001'),
}

SUBMODEL_SUBTITLE = 'COMPAS (version not stated) — Mandel et al. (2021) · 1e6 binaries at each of two metallicities (solar and 0.1 solar) · no systematic variation grid; the entries below are the paper’s own comparisons and its one relaxed assumption'
SUBMODELS = [
  ('FIDUCIAL', [
    ('Reference model', 'Defaults + stochastic remnants and kicks',
     '<b>Fid:</b> Mandel &amp; Müller (2020) probabilistic<br>remnants and kicks (Table 1 defaults)<br>+ PPISN (Stevenson+19) + CHE (Riley+21)<br>pessimistic CE · post-CE RLOF merges',
     '<b>Alt:</b> — (fiducial)',
     'Yields per 1e6 M☉: BNS 4.6 / 2.0, BHNS 16 / 9.0, BBH 11 / 67 at Z☉ / 0.1 Z☉. No COMPAS version is stated anywhere, which limits reproducibility.',
     'Sec. 1 · Sec. 4 · Table 1',
     'recipes for compact remnant masses and kicks, with the default parameters from Table 1 in that paper'),
  ]),
  ('REMNANT PRESCRIPTION COMPARISON', [
    ('Stochastic vs Fryer “Delayed”', 'Like-for-like at a 2.0 M☉ threshold',
     '<b>Fid:</b> Mandel &amp; Müller (2020) stochastic',
     '<b>Compared to:</b> Fryer et al. (2012) Delayed',
     'BBH yields <em>increase</em> at both metallicities under the stochastic recipe when the neutron-star/black-hole boundary is matched at 2.0 M☉. This is the cleanest available statement of what swapping to the now-default prescription does to a population.',
     'Sec. 4 · p. 4',
     'when using the same mass threshold of 2.0'),
  ]),
  ('COMMON ENVELOPE ASSUMPTION  ⚠ RELAXED ON PURPOSE', [
    ('HG donor CE survival', 'The only way to make GW190814',
     '<b>Fid:</b> pessimistic — HG donors merge<br>(Belczynski et al. 2008)',
     '<b>Alt:</b> HG donors allowed to survive<br>→ ≈ 3e−8 GW190814-like systems per M☉<br>at 0.1 Z☉',
     'The authors state plainly that this is inconsistent with their default model, and note the mass transfer in question might actually be dynamically <em>stable</em> under the updated Hertzsprung-gap donor response of Ge et al. (2020) — in which case no CE survival assumption would be needed.',
     'Sec. 4 · p. 5',
     'if we allow Hertzsprung-gap donors to survive common-envelope evolution'),
  ]),
  ('KICKS  ⚠ THE NEGATIVE RESULT', [
    ('Ultra-stripped SN kicks', 'No separate class in the stochastic model',
     '<b>Fid:</b> kick ∝ ejected M<sub>CO</sub> / remnant mass<br>→ USSN mean ≈ 200 km s⁻¹',
     '<b>Earlier COMPAS work:</b> 30 km s⁻¹<br>(Vigna-Gómez et al. 2018)',
     'Depletes the low-eccentricity Galactic DNS population and fails to reproduce the observed clusters near e ≈ 0.1 and 0.6. The paper concludes there is missing physics if all observed field DNS formed through isolated binary evolution — a failure reported by the authors of the prescription itself.',
     'Sec. 3 · pp. 3–4 · Fig. 3',
     'does not treat ultra-stripped supernovae separately from other supernova types'),
    ('Resulting kick means', 'Derived, not assumed',
     '<b>Fid:</b> no input σ',
     '<b>Outputs:</b> core collapse ≈ 300 km s⁻¹<br>ultra-stripped ≈ 200 · electron capture ≈ 40<br>(Hobbs et al. 2005 observed mean ≈ 400)',
     'Because the kick follows from the remnant, there is no dispersion parameter to report — which is what makes this column structurally different from every Maxwellian column in the ledger.',
     'Sec. 3 · p. 4',
     'those associated with neutron star birth through regular core collapse supernovae are'),
  ]),
]

COSMIC = [
]
