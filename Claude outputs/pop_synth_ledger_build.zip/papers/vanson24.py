# -*- coding: utf-8 -*-
"""van Son et al. (2024) — arXiv:2411.02484v2 — COMPAS v03.01.02

"Not just winds: why models find binary black hole formation is metallicity
dependent, while binary neutron star formation is not"

The METALLICITY PAPER from the Google Doc. Structurally unlike every other result
column here: instead of one population, it evolves ONE fixed set of 5e6 binaries at
12 metallicities using the same random seeds, so that metallicity is the only thing
that changes. That design is what lets it attribute the metallicity dependence to a
specific cause per channel rather than to winds in general.

It is also the bridge between the result columns and the code columns. Its fiducial
model deliberately uses the OLD defaults (Fryer 2012 'delayed', Maxwellian 265 km/s
fallback-reduced) even though it runs on v03.01.02, where the defaults had already
moved to the Mandel & Müller (2020) stochastic recipes — and it runs the new
defaults as an explicit variation. So this is the one paper in the ledger that
states both sides of that default change.

Quotes verified against vanson24.txt (real pdftotext output). Prose-only, avoiding
solar-mass and sigma symbols, superscripts, and the several places where pdftotext
swallows a hyphen ("carbon-oxygen" extracts as "carbonoxygen", "flat-in-log" as
"flatin-log", "Wolf-Rayet" as "WolfRayet", "mass-dependent" as "massdependent") so
Ctrl-F still matches in a viewer.

NOTE ON THE DATASET DOI: the paper's Software and Data statement gives
10.5281/zenodo.13999532. The Google Doc lists zenodo 14508864 (simulations.tar.gz).
Both are recorded below; they are probably separate records for code and data, but
that is NOT verified here — treat the Doc's number as needing confirmation.
"""
NS = "NOT SPECIFIED"

PAPER = dict(
    id='vanson24',
    order=23,
    label='van Son 2024',
    cite='van Son et al. (2024)',
    arxiv='arXiv:2411.02484v2',
    code='COMPAS v03.01.02',
    focus='BHBH + BHNS + NSNS · Z dependence of formation efficiency',
    colour='#b5651d',
    pdf_text='vanson24.txt',
    title='Not just winds: why models find binary black hole formation is metallicity dependent, while binary neutron star formation is not',
    extra='code github.com/LiekeVanSon/ZdependentFormEff · data 10.5281/zenodo.13999532 (Doc also lists zenodo 14508864 — unverified)',
    code_name='COMPAS',
    code_version='v03.01.02',
    systems='BHBH + BHNS + NSNS',
    systems_detail='All three double compact object classes, which makes this the broadest column in the ledger. A "merging" DCO is defined by a coalescence time under 14 Gyr. The paper tracks "potential DCOs" — systems that form a merging DCO at ANY of the 12 metallicities — so a single system can appear as a BHBH at one metallicity and a BHNS, a stellar merger or an unbound binary at another. Counts given: 17839 potential merging BHBH, 2358 potential merging BHNS.',
    purpose='Identify the dominant physical cause of the metallicity dependence of double compact object formation efficiency, and test how robust that dependence is — because the BHBH result underpins using BHBH mergers as tracers of low-metallicity star formation and as spectral sirens.',
    summary='Evolves one fixed set of 5e6 binaries at 12 metallicities from 1e-4 to 0.03, reusing the same seeds at every metallicity so that metallicity is the only variable. First derives a Drake-like analytic ceiling on formation efficiency from the initial conditions alone, finding the low-metallicity BHBH plateau sits surprisingly close to it: about one in eight interacting binaries with enough mass to form black holes ends up a merging BHBH. Then decomposes the loss of progenitors at high metallicity by channel and finds different causes for each: the stable mass transfer and chemically homogeneous channels shrink because stellar radii change, pushing mass transfer earlier into case A, while the common envelope channel is hit by stellar winds combined with mass-scaled natal kicks. NSNS formation stays metallicity independent because it comes exclusively from the common envelope channel with kicks assumed uncorrelated with mass. The sting is in the winds: replacing the outdated Nieuwenhuijzen & de Jager red supergiant rates with the ALMA-recalibrated Decin et al. (2024) rates removes the wind-stripping that drove much of the effect, so BHBH formation may be far less metallicity dependent than the literature assumes.',
)

DEFERRAL = "Our fiducial model follows the settings as described in (Riley et al. 2022), with the exception of updated prescriptions for the wind mass loss"
DEFERRAL_SRC = 'Sec. 3 · p. 6'

PAPER_URL = 'https://arxiv.org/abs/2411.02484'

CITATIONS = [
  ('Team COMPAS: Riley et al. (2022)',
   'https://doi.org/10.3847/1538-4365/ac416c',
   'The COMPAS methods paper. This paper’s fiducial model is explicitly "the settings as described in Riley et al. (2022)" apart from the winds, so that paper is required to read this column.'),
  ('Stevenson et al. (2017)',
   'https://doi.org/10.1038/ncomms14906',
   'Cited as a COMPAS reference for v03.01.02.'),
  ('Vigna-Gómez et al. (2018)',
   'https://doi.org/10.1093/mnras/sty2463',
   'Cited as a COMPAS reference for v03.01.02.'),
  ('Kroupa (2001)',
   'https://doi.org/10.1046/j.1365-8711.2001.04022.x',
   'The IMF, used both for the sampled population (5-150 Msun) and the analytic ceiling (0.01-300 Msun).'),
  ('Hurley et al. (2000)',
   'https://doi.org/10.1046/j.1365-8711.2000.03426.x',
   'The single-star tracks COMPAS is built on — and the reason the 12 metallicities were chosen, since they include the values the fitting formulae were derived at.'),
  ('Fryer et al. (2012)',
   'https://doi.org/10.1088/0004-637X/749/1/91',
   'The "delayed" remnant-mass model adopted in the fiducial run, and the fallback reduction of BH kicks.'),
  ('Hobbs et al. (2005)',
   'https://doi.org/10.1111/j.1365-2966.2005.09087.x',
   'The Maxwellian natal kick distribution, sigma = 265 km/s in the fiducial model.'),
  ('Mandel & Müller (2020)',
   'https://doi.org/10.1093/mnras/staa3043',
   'The stochastic remnant masses and momentum-preserving kicks that are the v03.01.02 DEFAULT — run here as a variation, not as the fiducial.'),
  ('Vink & Sander (2021)',
   'https://doi.org/10.1093/mnras/stab902',
   'The OB main-sequence wind prescription, with a shallower metallicity scaling than Vink et al. (2001).'),
  ('Vink et al. (2001)',
   'https://doi.org/10.1051/0004-6361:20010127',
   'The steeper metallicity scaling this paper moves away from.'),
  ('Sabhahit et al. (2023)',
   'https://doi.org/10.1093/mnras/stad1888',
   'Eq. 22, adopted for stars above 100 Msun with optically thick winds.'),
  ('Vink (2017)',
   'https://doi.org/10.1098/rsta.2016.0269',
   'Wind prescription for low-luminosity stripped helium stars.'),
  ('Sander & Vink (2020)',
   'https://doi.org/10.1093/mnras/staa2712',
   'Wind prescription for high-luminosity Wolf-Rayet-like stars.'),
  ('Sander et al. (2023)',
   'https://doi.org/10.1051/0004-6361/202245110',
   'The temperature correction applied to the Sander & Vink rates.'),
  ('Decin et al. (2024)',
   'https://doi.org/10.1051/0004-6361/202244635',
   'The ALMA-recalibrated red supergiant mass-loss rates — the single most consequential input in this paper.'),
  ('Beasor et al. (2020)',
   'https://doi.org/10.1093/mnras/staa255',
   'The rates Decin et al. recalibrated.'),
  ('Nieuwenhuijzen & de Jager (1990)',
   'https://ui.adsabs.harvard.edu/search/q=Nieuwenhuijzen%20de%20Jager%201990%20A%26A%20231%20134',
   'The cool-star rates used by most earlier studies, which this paper argues were never intended for red supergiants.'),
  ('de Jager et al. (1988)',
   'https://ui.adsabs.harvard.edu/search/q=de%20Jager%20Nieuwenhuijzen%20van%20der%20Hucht%201988',
   'The other cool-star prescription in common use, criticised on the same grounds.'),
  ('Sana et al. (2012)',
   'https://doi.org/10.1126/science.1223344',
   'The flat mass ratio distribution and the interacting-binary fraction argument.'),
  ('Kobulnicky et al. (2014)',
   'https://doi.org/10.1088/0067-0049/213/2/34',
   'Also cited for the flat mass ratio distribution.'),
  ('Offner et al. (2023)',
   'https://doi.org/10.48550/arXiv.2203.10066',
   'The mass-dependent binary fraction behind the mean star-forming mass per system of about 0.51 Msun.'),
  ('Doran et al. (2013)',
   'https://doi.org/10.1051/0004-6361/201321824',
   'The 0.01-300 Msun range used for the analytic IMF ceiling.'),
  ('Moe & Di Stefano (2017)',
   'https://doi.org/10.3847/1538-4365/aa6fb6',
   'Cited with Sana for the mass ratio distribution in the analytic estimate.'),
  ('Dominik et al. (2012)',
   'https://doi.org/10.1088/0004-637X/759/1/52',
   'The pessimistic common envelope assumption: a CE from a Hertzsprung-gap donor leads to a stellar merger.'),
  ('Peters (1964)',
   'https://doi.org/10.1103/PhysRev.136.B1224',
   'Coalescence time, behind the 14 Gyr merger criterion and explanation 1C.'),
  ('Broekgaarden et al. (2022)',
   'https://doi.org/10.1093/mnras/stac1677',
   'One of the six literature model sets compiled in Figure 1, and a source of several of the explanations tested.'),
  ('Neijssel et al. (2019)',
   'https://doi.org/10.1093/mnras/stz2840',
   'Another of the Figure 1 model sets, and the source of explanation 1A.'),
  ('Klencki et al. (2018)',
   'https://doi.org/10.1051/0004-6361/201833025',
   'Source of several proposed explanations tested here (1A, 3, 4, 5).'),
  ('Giacobbo & Mapelli (2018)',
   'https://doi.org/10.1093/mnras/sty1999',
   'MOBSE results in the Figure 1 compilation.'),
  ('Santoliquido et al. (2021)',
   'https://doi.org/10.1093/mnras/stab280',
   'Another Figure 1 model set.'),
  ('Iorio et al. (2023)',
   'https://doi.org/10.1093/mnras/stad1630',
   'SEVN results in Figure 1, and the source of explanations 1C and 1D.'),
  ('Chruślińska (2024)',
   'https://doi.org/10.48550/arXiv.2402.02465',
   'The metallicity-dependent cosmic star formation history, and the tracer argument this paper’s result bears on.'),
  ('Mandel & Broekgaarden (2022)',
   'https://doi.org/10.1007/s41114-021-00034-3',
   'The Drake-like formation-efficiency framing used for the analytic ceiling.'),
  ('Mandel & Farmer (2022)',
   'https://doi.org/10.1016/j.physrep.2022.01.003',
   'Also cited for the Drake-like equation.'),
]

ENTRIES = {
  # ── §1  INITIAL STELLAR POPULATION
  'Primary mass function (IMF)': dict(
    value='Kroupa (2001)<br>M₁ sampled over 5 – 150 M☉<br><br>Analytic ceiling (§2) instead uses<br>Kroupa over 0.01 – 300 M☉<br>with a minimum ZAMS mass of 20 M☉<br>for BH formation',
    desc='Two different IMF ranges do different jobs and must not be conflated: 5 – 150 M☉ is what was actually simulated, while 0.01 – 300 M☉ is the range used for the Drake-like ceiling in §2. The sampled lower bound of 5 M☉ is lower than van Son 2022a’s 10 M☉, which is what lets this paper reach neutron star progenitors and cover NSNS.',
    src='Sec. 3 · p. 6 · Sec. 2 · p. 4',
    quote='from a Kroupa (2001) initial',
    num={'M1_min_Msun': 5.0, 'M1_max_Msun': 150.0, 'IMF_analytic_min_Msun': 0.01,
         'IMF_analytic_max_Msun': 300.0, 'M_ZAMS_min_for_BH_Msun': 20.0},
    primary='M1_min_Msun',
  ),
  'Mass ratio distribution': dict(
    value='Flat in q = M₂/M₁ over [0.01, 1.0]<br>(Sana et al. 2012; Kobulnicky et al. 2014)',
    desc='Same flat distribution as van Son 2022a, stated with its bounds.',
    src='Sec. 3 · p. 6',
    quote='mass ratios from a flat distribution for',
    num={'q_min': 0.01, 'q_max': 1.0},
    primary='q_min',
  ),
  'Initial orbital separation / period distribution': dict(
    value='Flat in log a, 0.01 – 1000 AU<br><br>Analytic ceiling assumes the interacting<br>window is ≈ 0.1 – 14 AU → f<sub>init,sep</sub> ≈ 0.43',
    desc='The sampled range matches van Son 2022a. The interesting addition is the analytic estimate of how much of that range actually produces an interacting binary that does not merge at ZAMS — about 43 %, which is one of the three factors setting the theoretical ceiling.',
    src='Sec. 3 · p. 6 · Sec. 2 · p. 5',
    quote='and initial semi-major axes from flat',
    num={'a_min_AU': 0.01, 'a_max_AU': 1000.0, 'a_interact_min_AU': 0.1,
         'a_interact_max_AU': 14.0, 'f_init_sep': 0.43},
    primary='f_init_sep',
  ),
  'Initial eccentricity distribution': dict(value=NS, desc='Not stated in this paper; inherited with the Riley et al. (2022) settings.', src='Sec. 3 · p. 6', quote=''),
  'Initial stellar rotation': dict(
    value=NS + '<br>(but CHE is one of the three channels<br>the paper analyses)',
    desc='No rotation distribution is stated. Chemically homogeneous evolution is nevertheless treated as a distinct formation channel whose metallicity behaviour is diagnosed separately, so rotation is active in the model even though its distribution is inherited rather than restated.',
    src='Abstract · Sec. 5',
    quote='The stable mass transfer and chemically homogeneous evolution channels mainly diminish at high metallicities due to changes in stellar radii',
  ),
  'Binary fraction': dict(
    value='Mass-dependent, following Offner et al. (2023)<br>→ ⟨M<sub>SF</sub>⟩ ≈ 0.51 M☉ per system<br><br>(used for the analytic ceiling)',
    desc='Not a flat fraction like van Son 2022a’s f_bin = 0.7 — a mass-dependent one, which together with the Kroupa IMF over 0.01 – 300 M☉ gives a mean star-forming mass per system of about 0.51 M☉. That number is the denominator of the whole formation-efficiency ceiling.',
    src='Sec. 2 · p. 4 · App. A',
    quote='binary fraction following Offner et al. (2023)',
    num={'mean_M_SF_per_system_Msun': 0.51},
    primary='mean_M_SF_per_system_Msun',
  ),
  'Metallicity sampling / grid': dict(
    value='<b>12 discrete metallicities, same seeds at each</b><br>1e-4 · 1.7321e-4 · 3e-4 · 5.4772e-4<br>1e-3 · 2e-3 · 4e-3 · 6.32456e-3<br>1e-2 · 1.414214e-2 · 2e-2 · 3e-2<br><br>Chosen to include the metallicities used to<br>derive the Hurley et al. (2000) fitting formulae',
    desc='The methodological heart of the paper, and the opposite choice to van Son 2022a’s smooth flat-in-log sampling. One fixed set of 5e6 binaries — primary mass, mass ratio, period, kick magnitude and orientation all drawn once — is re-evolved at each of the 12 metallicities using the same seeds, so any difference in outcome is attributable to metallicity alone. The grid is deliberately aligned with the metallicities underlying the COMPAS stellar tracks, which avoids interpolation error in the tracks themselves.',
    src='Sec. 3 · p. 6 · fn. 4',
    quote='we evolve this exact same set of binaries at 12 different metallicities',
    num={'n_metallicities': 12.0, 'Z_min': 0.0001, 'Z_max': 0.03},
    primary='n_metallicities',
  ),
  'Solar metallicity reference': dict(
    value='Z☉ = 0.014<br>(all figures use log₁₀(Z/0.014))',
    desc='Used consistently as the scale for every relative-metallicity statement, including the key threshold that BHBH formation efficiency drops above about 0.2 Z☉ ≈ 0.003.',
    src='Sec. 1 · p. 3 · Figs. 1, 3',
    quote='plateaus at low metallicity (Z) and drops drastically at higher metallicity',
    num={'Z_sun': 0.014, 'Z_BHBH_dropoff': 0.003, 'Z_BHBH_dropoff_in_Zsun': 0.2},
    primary='Z_sun',
  ),
  'Chemically homogeneous evolution (CHE / QHE) treatment': dict(
    value='CHE modelled and analysed as one of<br>three formation channels<br><br>Diminishes at high Z through<br><em>stellar radius</em> changes, not winds',
    desc='Unlike the earlier van Son papers, which exclude CHE systems from the sample, this paper keeps CHE as a channel and diagnoses it. Its finding is specific: CHE (like stable mass transfer) loses progenitors at high metallicity because radii change, which is a different mechanism from the wind-plus-kick effect that hits the common envelope channel.',
    src='Abstract · Sec. 5',
    quote='The stable mass transfer and chemically homogeneous evolution channels mainly diminish at high metallicities due to changes in stellar radii',
  ),
  'Sample size': dict(
    value='5 × 10⁶ binaries per metallicity<br>× 12 metallicities (same seeds)<br><br>Convergence checked at 1 × 10⁶<br>Uncertainty checked by bootstrapping',
    desc='The seeds are reused across metallicities, so this is one population evaluated 12 times rather than 12 independent populations — that is what makes the comparison clean. Two separate checks are reported: a reduced-resolution 1e6 rerun with no significant differences, and bootstrapping of the main figure.',
    src='Sec. 3 · p. 6',
    quote='we have repeated our analyses with a reduced resolution of',
    num={'n_binaries_per_Z': 5000000.0, 'n_metallicities': 12.0,
         'n_binaries_convergence_check': 1000000.0,
         'n_potential_BHBH': 17839.0, 'n_potential_BHNS': 2358.0},
    primary='n_binaries_per_Z',
  ),

  # ── §2  STELLAR EVOLUTION & WINDS
  'Stellar evolution framework': dict(
    value='COMPAS v03.01.02<br>(Stevenson et al. 2017; Vigna-Gómez et al. 2018;<br>Riley et al. 2022)<br><br>Fiducial = Riley et al. (2022) settings<br><em>except</em> the winds (Merritt et al., in prep.)',
    desc='An important version to have in the ledger: v03.01.02 sits between Willcox’s v02.38.07 and the v03.22.01 of methods paper II. The fiducial physics is explicitly the methods-paper-I configuration with one exception, which makes this column unusually easy to place against the two code columns.',
    src='Sec. 3 · p. 6',
    quote='We use the rapid population synthesis code from the COMPAS suite',
  ),
  'Core overshooting': dict(value=NS, desc='Not stated; inherited with the Riley et al. (2022) settings.', src='Sec. 3 · p. 6', quote=''),
  'Hot star / OB-type winds': dict(
    value='Vink &amp; Sander (2021)<br>Ṁ ∝ Z<sup>0.42</sup> above the bi-stability jump<br><br>vs Ṁ ∝ Z<sup>0.85</sup> adopted elsewhere',
    desc='A shallower metallicity scaling than the Vink et al. (2001) lineage every earlier column in this ledger uses — and the exponent is given explicitly, which is rare. A shallower wind-metallicity scaling directly weakens the mechanism the paper is testing.',
    src='Sec. 3 · p. 6',
    quote='for OB stars, we use main-sequence wind-loss prescriptions from Vink & Sander (2021)',
    num={'Z_exponent_this_work': 0.42, 'Z_exponent_elsewhere': 0.85},
    primary='Z_exponent_this_work',
  ),
  'Cool star winds / Reimers η': dict(
    value='<b>Red supergiant winds: Decin et al. (2024)</b><br>ALMA recalibration of Beasor et al. (2020)<br><br>→ rates <em>orders of magnitude lower</em> than<br>Nieuwenhuijzen &amp; de Jager (1990)<br>→ RSGs no longer wind-strip their envelopes<br><br>Reimers η: NOT SPECIFIED',
    desc='The most consequential single input in the paper. Most earlier work — including every other result column here — applies de Jager et al. (1988) or Nieuwenhuijzen &amp; de Jager (1990) to all cool stars, which this paper argues were never intended for red supergiants since the calibrating data span the whole HR diagram and contain only a handful of RSGs. Switching to the recalibrated rates removes RSG wind-stripping, and that is what leads to the headline conclusion that BHBH formation may be much less metallicity dependent than assumed.',
    src='Sec. 3 · pp. 6–7',
    quote='These new prescriptions result in mass-loss rates that are orders of magnitude lower than those of Nieuwenhuijzen & de Jager (1990), preventing RSGs from wind-stripping their envelopes.',
  ),
  'Wolf–Rayet / He-star winds': dict(
    value='Vink (2017) — low-luminosity stripped stars<br>Sander &amp; Vink (2020) — high-luminosity WR<br>with the Sander et al. (2023) temperature correction',
    desc='A two-regime treatment split by luminosity, replacing the single Belczynski et al. (2010) prescription used in the earlier columns. This is the same lineage that became the SANDERVINK2023 default in COMPAS v03.22.01.',
    src='Sec. 3 · p. 6',
    quote='we apply the prescription from Vink (2017) for low-luminosity stripped stars',
  ),
  'LBV / Eddington-limited winds': dict(
    value=NS + '<br>(very massive stars above 100 M☉ instead use<br>Sabhahit et al. 2023 eq. 22 for optically<br>thick winds)',
    desc='No LBV prescription is named. The high-mass regime is handled by an optically-thick-wind prescription rather than by an eruptive LBV treatment, which is a different approach from the Humphreys–Davidson trigger used in van Son 2022a.',
    src='Sec. 3 · p. 6',
    quote='we adopt eq. 22 from Sabhahit et al. (2023), which is more appropriate for the expected optically thick winds',
    num={'M_VMS_threshold_Msun': 100.0},
  ),
  'Stellar track mass range': dict(
    value=NS + '<br>(sampled 5 – 150 M☉; the 12-metallicity grid<br>is chosen to match the metallicities behind<br>the Hurley et al. 2000 fitting formulae)',
    desc='No track mass range is stated, but the paper is explicit about aligning its metallicity grid with the values the COMPAS single-star fitting formulae were derived at — a track-fidelity consideration the other columns do not mention.',
    src='Sec. 3 · p. 6',
    quote='These metallicities are chosen to include the metallicities that were used to derive the fitting formulae in Hurley et al.',
    num={'M1_min_Msun': 5.0, 'M1_max_Msun': 150.0},
  ),

  # ── §3  MASS TRANSFER & ROCHE LOBE OVERFLOW
  'Roche lobe radius': dict(value=NS, desc='Not stated; inherited with the Riley et al. (2022) settings.', src='Sec. 3 · p. 6', quote=''),
  'Mass transfer stability criterion': dict(
    value=NS + '<br>(inherited from Riley et al. 2022)<br><br>But the paper reports the <em>consequence</em>:<br>at high Z, stellar expansion moves mass transfer<br>earlier → more case A, less stable early case B',
    desc='The criterion itself is inherited, but the paper’s central diagnostic for the stable channel is a mass-transfer-timing effect: as radii grow with metallicity, donors fill their Roche lobes earlier, shifting the population from stable early case B into case A and shrinking the stable mass transfer channel. That is a statement about outcomes rather than about the stability rule.',
    src='Sec. 5 · Fig. 2',
    quote='The stable mass transfer channel loses BHBH and BHNS progenitors at higher metallicity because stellar expansion, and hence mass transfer, happen earlier in the donor',
  ),
  'Accretion efficiency (RLOF)': dict(value=NS, desc='Not stated; inherited with the Riley et al. (2022) settings.', src='Sec. 3 · p. 6', quote=''),
  'Accretion limit — BH accretor / Eddington multiplier': dict(value=NS, desc='Not stated; inherited with the Riley et al. (2022) settings.', src='Sec. 3 · p. 6', quote=''),
  'Angular momentum loss (non-conservative MT)': dict(value=NS, desc='Not stated; inherited with the Riley et al. (2022) settings.', src='Sec. 3 · p. 6', quote=''),
  'Orbit circularisation': dict(value=NS, desc='Not stated.', src='—', quote=''),
  'AIC (accretion-induced collapse)': dict(value=NS, desc='Not stated.', src='—', quote=''),
  'Ultra-stripped SN': dict(
    value='Treated as a low-kick class:<br>σ<sub>kick</sub> = 30 km s⁻¹<br>(with electron-capture SNe)',
    desc='Ultra-stripped and electron-capture supernovae share a reduced kick dispersion, justified by the expectation that these explosions impart smaller kicks than standard core collapse. This matters for the NSNS result: it is the assumption that NS kicks are uncorrelated with mass that keeps NSNS formation metallicity independent.',
    src='Sec. 3 · p. 6',
    quote='are expected to have smaller kicks than core-collapse SNe',
    num={'sigma_kick_ECSN_USSN_km_s': 30.0},
    primary='sigma_kick_ECSN_USSN_km_s',
  ),

  # ── §4  COMMON ENVELOPE (CE) EVOLUTION
  'CE energy formalism': dict(
    value=NS + '<br>(inherited from Riley et al. 2022)<br><br>The CE <em>channel</em> is central to the result:<br>it is the channel hit by winds + mass-scaled kicks,<br>and the only channel forming NSNS',
    desc='No formalism is restated, but the common envelope channel carries the paper’s main conclusion. It is the one channel whose metallicity dependence comes from winds rather than radii, and NSNS systems form exclusively through it.',
    src='Abstract · Sec. 5',
    quote='while the common envelope channel is primarily impacted by the combined effects of stellar winds and mass-scaled natal kicks',
  ),
  'CE efficiency (α<sub>CE</sub>)': dict(value=NS, desc='Not stated; inherited with the Riley et al. (2022) settings.', src='Sec. 3 · p. 6', quote=''),
  'Envelope binding energy (λ<sub>CE</sub>)': dict(
    value=NS + '<br>(noted as a lever in other work:<br>Iorio et al. 2023 models LX, LC, LK)',
    desc='Not specified for this run. The paper does flag that varying the envelope binding energy is what produces the one qualitatively different result in the literature compilation — Iorio et al. (2023) see BHNS formation efficiency <em>increase</em> with metallicity in their lambda variations.',
    src='Sec. 1 · p. 3',
    quote='models that vary the envelope binding energy',
  ),
  'HG donor CE survival / merger condition': dict(
    value='<b>Pessimistic (default):</b> all common envelopes<br>from donors with presumably radiative<br>envelopes lead to stellar mergers<br><br>Named as the reason BHBH progenitors are<br>lost to stellar mergers at high Z',
    desc='Explicitly stated as the paper’s default, and load-bearing for the result: as radii grow with metallicity, common envelopes that were case C become early case B, and under the pessimistic assumption those all become stellar mergers. The paper says outright that the optimistic assumption would change this, which makes the choice a named sensitivity rather than a buried default.',
    src='Sec. 5',
    quote='all common envelopes from donors with presumably radiative envelopes lead to stellar mergers',
  ),
  'Case BB mass transfer handling': dict(value=NS, desc='Not stated; inherited with the Riley et al. (2022) settings.', src='Sec. 3 · p. 6', quote=''),

  # ── §5  SUPERNOVAE & COMPACT REMNANTS
  'Remnant mass prescription': dict(
    value='<b>Fiducial: Fryer et al. (2012) “delayed”</b><br>— deliberately NOT the v03.01.02 default<br><br><b>Variation:</b> Mandel &amp; Müller (2020)<br>stochastic remnant masses',
    desc='This is the ledger’s bridge between the result columns and the code columns. The paper runs on v03.01.02, where the default had already changed to the stochastic recipes, but chooses the older deterministic Fryer prescription as fiducial so its results are comparable to the earlier literature — and then runs the new default as an explicit variation to test the impact. It is the only column here that states both sides of that change.',
    src='Sec. 3 · p. 6',
    quote='remnant-mass model from Fryer et al. (2012), and a Maxwellian kick distribution with',
  ),
  'NS mass distribution': dict(value=NS, desc='Not stated; inherited with the Riley et al. (2022) settings.', src='Sec. 3 · p. 6', quote=''),
  'Pulsational pair-instability SN (PPISN)': dict(
    value='Active, but negligible here:<br>massless remnants from pair-instability SNe<br>are &lt; 1 % of potential merging BHBH<br>at the lowest metallicities',
    desc='Quantified rather than just named. Pair-instability supernovae only touch the high-mass tail of BH progenitors, so they account for under one per cent of the population this paper studies — which is why they are invisible in its outcome figures.',
    src='Sec. 4.1 · p. 7',
    quote='Massless remnants result from pair-instability supernovae, which only occur in the high-mass tail of BH progenitors.',
    num={'massless_remnant_fraction_percent': 1.0},
  ),
  'ECSN mass thresholds': dict(
    value=NS + '<br>(thresholds not given, but ECSN are assigned<br>the reduced σ<sub>kick</sub> = 30 km s⁻¹)',
    desc='The core-mass boundaries are inherited. What is stated is the kick treatment for these events.',
    src='Sec. 3 · p. 6',
    quote='are expected to have smaller kicks than core-collapse SNe',
    num={'sigma_kick_ECSN_USSN_km_s': 30.0},
  ),
  'Maximum NS mass': dict(value=NS, desc='Not stated; inherited with the Riley et al. (2022) settings.', src='Sec. 3 · p. 6', quote=''),
  'Neutrino mass loss correction': dict(value=NS, desc='Not stated; inherited with the Riley et al. (2022) settings.', src='Sec. 3 · p. 6', quote=''),
  'BH natal kick': dict(
    value='Maxwellian σ<sub>kick</sub> = 265 km s⁻¹<br>(Hobbs et al. 2005), reduced by the fallback<br>fraction for BHs (Fryer et al. 2012)<br><br>Variation: Mandel &amp; Müller (2020)<br>momentum-preserving stochastic kicks',
    desc='Note the value: 265 km/s is the figure COMPAS methods paper II later corrects to 217 km/s after a missing Jacobian was found in the Hobbs et al. (2005) fit. This column therefore records the pre-correction value, which is worth knowing when comparing it against the code columns. Because BH kicks scale with fallback, and fallback depends on core mass, they are effectively mass-scaled — which is precisely the mechanism the paper identifies as hitting the CE channel at high metallicity.',
    src='Sec. 3 · p. 6',
    quote='that is reduced by a fallback fraction for BH natal kicks',
    num={'sigma_kick_CCSN_km_s': 265.0},
    primary='sigma_kick_CCSN_km_s',
  ),
  'BH spin / NS radius': dict(value=NS, desc='Not stated.', src='—', quote=''),

  # ── §6  NATAL KICKS
  'Core-collapse SN kick σ': dict(
    value='σ<sub>kick</sub> = 265 km s⁻¹ (Maxwellian,<br>Hobbs et al. 2005)<br><br>This is the value later corrected to 217<br>in COMPAS methods paper II',
    desc='Stated numerically, which most columns in this ledger do not do. The kick treatment is the crux of the NSNS result: NS kicks are assumed uncorrelated with progenitor mass, so unlike fallback-scaled BH kicks they do not strengthen as winds strip more mass at high metallicity — and that is why NSNS formation efficiency stays flat.',
    src='Sec. 3 · p. 6 · Sec. 5',
    quote='and a Maxwellian kick distribution with',
    num={'sigma_kick_CCSN_km_s': 265.0},
    primary='sigma_kick_CCSN_km_s',
  ),
  'Low-kick σ (ECSN / USSN / AIC)': dict(
    value='σ<sub>kick</sub> = 30 km s⁻¹<br>for electron-capture and ultra-stripped SNe',
    desc='An explicit second kick dispersion — one of only two columns in the ledger to give one.',
    src='Sec. 3 · p. 6',
    quote='are expected to have smaller kicks than core-collapse SNe',
    num={'sigma_kick_ECSN_USSN_km_s': 30.0},
    primary='sigma_kick_ECSN_USSN_km_s',
  ),
  'Kick mass scaling': dict(
    value='BH kicks: reduced by the fallback fraction<br>(Fryer et al. 2012) → effectively mass-scaled<br><br>NS kicks: <em>not</em> proportional to progenitor mass',
    desc='The asymmetry between the two is the paper’s explanation for why BHBH and NSNS behave differently with metallicity. Fallback-scaled BH kicks grow as winds shrink the core, unbinding more systems at high Z; NS kicks are assumed independent of mass, so NSNS progenitors are not lost the same way.',
    src='Sec. 3 · p. 6 · Sec. 5',
    quote='For potential NSNS stars this effect does not exist because NSs are assumed to receive a natal kick that is not proportional to their progenitor mass.',
  ),
  'Kick direction': dict(
    value='Orientation drawn per system and reused<br>across all 12 metallicities',
    desc='No distribution is named, but the paper states that kick magnitude and orientation are part of the fixed per-system seed set, which is what makes the cross-metallicity comparison controlled.',
    src='Sec. 3 · p. 6',
    quote='the supernova kick magnitude and orientation for both binary',
  ),

  # ── §7  TIDES & ORBITAL EVOLUTION
  'Stellar tides': dict(value=NS, desc='Not stated; inherited with the Riley et al. (2022) settings.', src='Sec. 3 · p. 6', quote=''),
  'GW inspiral': dict(
    value='Merger criterion: coalescence time &lt; 14 Gyr<br>(Peters 1964)',
    desc='An explicit and slightly unusual threshold — 14 Gyr rather than a Hubble time — applied uniformly to define a "merging" DCO. Worth noting when comparing merger counts across columns.',
    src='Sec. 4 · p. 7',
    quote='DCO is defined as having a coalescence time less than 14 Gyr',
    num={'coalescence_time_max_Gyr': 14.0},
    primary='coalescence_time_max_Gyr',
  ),
  'Angular momentum loss (γ)': dict(value=NS, desc='Not stated; inherited with the Riley et al. (2022) settings.', src='Sec. 3 · p. 6', quote=''),
  'Stellar merger outcome': dict(
    value='One of five tracked end states<br>(merger · unbound · DCO · WD · massless remnant)<br><br>Stellar mergers are the dominant loss channel<br>for BHBH progenitors at high Z',
    desc='Mergers are not just a discard here — they are a measured outcome class. The paper attributes the loss of potential BHBH mergers at high metallicity mainly to an increase in stellar mergers and unbound systems, and traces the merger increase specifically to radius growth pushing common envelopes into the pessimistic HG-donor regime.',
    src='Sec. 4.1 · p. 7',
    quote='mainly due to an increase in stellar mergers and unbound systems',
  ),

  # ── §8  WHITE DWARF / COMPACT OBJECT PHYSICS
  'WD cooling / accretion & collapse': dict(
    value=NS + '<br>(WD formation <em>is</em> tracked as one of the<br>five end states for potential DCO progenitors)',
    desc='No white dwarf physics is described, but "one component becomes a white dwarf" is one of the five outcome classes counted, so WDs appear as a loss channel rather than as modelled objects.',
    src='Sec. 4.1 · p. 7',
    quote='One component becomes a white dwarf',
  ),
  'Nova efficiency': dict(value=NS, desc='Not stated.', src='—', quote=''),
  'Magnetic braking': dict(value=NS, desc='Not stated.', src='—', quote=''),
  'Rejuvenation (post-accretion mixing)': dict(value=NS, desc='Not stated.', src='—', quote=''),

  # ── §9  COSMOLOGICAL MODEL & STAR FORMATION RATE
  'Cosmological parameters': dict(
    value=NS + '<br>(no cosmic integration — the paper works in<br>formation efficiency per unit star formation,<br>not in rates)',
    desc='Deliberately not a rate paper. Formation efficiency is defined as the number of merging DCOs per unit star-forming mass, which factors the cosmology out of the quantity being studied. That is why this column is blank on all three §9 rows while still bearing directly on rate predictions.',
    src='Sec. 1 · p. 2',
    quote='We define formation efficiency as',
  ),
  'Metallicity-dependent SFRD': dict(
    value=NS + '<br>(not applied, but the paper’s motivation)<br><br>States that most models agree less than 30 %<br>of stellar mass formed at Z &lt; Z☉/10<br>over the past ~11.5 Gyr (z &lt; 3)',
    desc='No SFRD is convolved. The relevance is the other way round: because the great majority of cosmic star formation happens at relatively high metallicity, even a small shift in where the BHBH efficiency drop occurs can move predicted merger rates by orders of magnitude. That is the stated reason the paper matters for rate calculations.',
    src='Sec. 1 · p. 3',
    quote='most models agree that less than 30% of stellar mass is formed',
    num={'frac_lowZ_star_formation_percent': 30.0, 'lookback_Gyr': 11.5, 'redshift_max': 3.0},
  ),
  'Local merger rate density': dict(value=NS, desc='No rates are computed; the paper deliberately works in formation efficiency per unit star formation instead.', src='Sec. 1 · p. 2', quote=''),

  # ── §10  KEY ASTROPHYSICAL RESULTS & CHANNELS
  'Formation channel split': dict(
    value='<b>Three channels, diagnosed separately:</b><br>common envelope · stable mass transfer ·<br>chemically homogeneous evolution<br><br>NSNS form <em>exclusively</em> through CE<br><br>Outcomes classed into five end states',
    desc='The most granular channel treatment in the ledger: three channels rather than the two-way CE / stable-RLOF split of van Son 2022a, plus five outcome classes for progenitors that fail. The finding that NSNS come only from the CE channel is what ties the NSNS metallicity independence to the mass-independence of NS kicks.',
    src='Abstract · Sec. 4.1 · Sec. 5',
    quote='NSNS formation efficiency remains metallicity independent as they form exclusively through the common envelope channel',
  ),
  'Headline quantitative result': dict(
    value='The low-Z BHBH plateau is set by <em>initial</em><br><em>conditions</em>, not binary physics:<br><br><b>≈ 1 in 8 interacting binaries with enough<br>mass to form BHs becomes a merging BHBH</b><br><br>Analytic ceiling factors:<br>f<sub>primary</sub>×f<sub>secondary</sub> ≈ 5.05e−4 · f<sub>init,sep</sub> ≈ 0.43<br>⟨M<sub>SF</sub>⟩ ≈ 0.51 M☉',
    desc='A genuinely surprising result, and the reason the analytic ceiling in §2 is worth the effort: the simulated low-metallicity plateau sits close to the ceiling you get from the initial condition distributions alone, ignoring binary interaction entirely. That reframes the plateau height as a statement about the IMF, mass ratio and separation distributions rather than about mass transfer physics.',
    src='Abstract · Sec. 2 · pp. 4–5',
    quote='about one in eight interacting binary systems with sufficient mass to form black holes will lead to a merging BHBH',
    num={'f_primary_x_secondary': 0.000505, 'f_init_sep': 0.43,
         'mean_M_SF_per_system_Msun': 0.51, 'f_primary_analytic': 0.0004,
         'f_primary_COMPAS': 0.001},
    primary='f_primary_x_secondary',
  ),
  'Mass-distribution features': dict(
    value=NS + '<br>(the paper studies formation <em>efficiency</em><br>vs metallicity, not the mass distribution)<br><br>BHBH efficiency drops above Z ≈ 0.2 Z☉ ≈ 0.003<br>BHNS similar but weaker · NSNS flat',
    desc='Not a mass-distribution paper. The shape it characterises is efficiency against metallicity: a flat low-Z plateau for BHBH falling by orders of magnitude above roughly a fifth of solar, the same pattern more weakly for BHNS, and essentially no trend for NSNS.',
    src='Sec. 1 · p. 3 · Fig. 1',
    quote='plateaus at low metallicity (Z) and drops drastically at higher metallicity',
    num={'Z_BHBH_dropoff': 0.003, 'Z_BHBH_dropoff_in_Zsun': 0.2},
  ),
  'Sensitivity of the result': dict(
    value='<b>The headline sensitivity is the RSG winds.</b><br>Replacing Nieuwenhuijzen &amp; de Jager (1990)<br>with Decin et al. (2024) removes RSG<br>wind-stripping → much weaker Z dependence<br><br>Also varied: Mandel &amp; Müller (2020) stochastic<br>remnants and kicks (the v03.01.02 default)<br>Also flagged: optimistic vs pessimistic CE',
    desc='Three named sensitivities, and the first is the paper’s conclusion rather than a caveat: the metallicity dependence that the whole literature agrees on is partly an artefact of applying cool-star wind rates to red supergiants they were never calibrated for. The CE assumption is flagged honestly too — the optimistic choice would let the extra early case B systems survive rather than merge.',
    src='Abstract · Sec. 3 · Sec. 5',
    quote='Outdated giant wind prescriptions exacerbate the latter effect, suggesting BHBH formation may be much less metallicity dependent than previously assumed.',
  ),
  'Orbital outcome of stable MT': dict(
    value='At high Z, expansion moves mass transfer earlier:<br>more case A, fewer stable early case B<br>→ the stable channel shrinks<br><br>Explicitly <em>rejects</em> the "wider orbits at high Z"<br>explanation: no large population of wide BHBHs',
    desc='A negative result worth having in the table. One of the standard explanations for the metallicity trend is that stronger winds widen orbits at DCO formation and so lengthen coalescence times past a Hubble time. The paper looks for those systems and does not find them, so it rules that mechanism out for its models.',
    src='Sec. 4.1 · p. 7 · Sec. 5',
    quote='The lack of a large number of wide BHBHs challenges 1C from Section 1',
  ),
  'Implication flagged by the authors': dict(
    value='BHBH formation may be <em>much less</em><br>metallicity dependent than assumed<br><br>→ weakens BHBHs as tracers of low-Z<br>star formation<br>→ strengthens NSNS as spectral sirens<br>→ forthcoming GW observations will constrain this',
    desc='The consequences are concrete and cut against the literature the paper reviews. If the metallicity dependence is weaker than believed, the inference that heavy BHBH mergers must come from the early low-metallicity Universe is weaker too. Meanwhile NSNS, being metallicity independent with shorter delay times and a narrower mass range, should vary little with redshift — which is what makes them candidate spectral sirens for inferring cosmological parameters.',
    src='Abstract · Sec. 1 · pp. 3–4',
    quote='suggests that the NSNS mass distribution will vary',
  ),

}

FLAGS = {
  'version': dict(value='v03.01.02', note='Stated in Sec. 3 and again in the Software and Data statement.',
    quote='We use the rapid population synthesis code from the COMPAS suite'),
  'number-of-systems': dict(value='5000000 per metallicity (x12, same seeds)',
    note='Convergence checked against a 1e6 rerun (Sec. 3, p. 6).',
    quote='we have repeated our analyses with a reduced resolution of'),
  'initial-mass-function': dict(value='KROUPA', note='Kroupa (2001), applied to the primary (Sec. 3, p. 6).',
    quote='from a Kroupa (2001) initial'),
  'initial-mass-function-min': dict(value='5', note='Lower bound of the sampled primary mass — lower than van Son 2022a, which is why NSNS are reachable (Sec. 3, p. 6).',
    quote='from a Kroupa (2001) initial'),
  'initial-mass-function-max': dict(value='150', note='Upper bound of the sampled primary mass (Sec. 3, p. 6).',
    quote='from a Kroupa (2001) initial'),
  'mass-ratio-distribution': dict(value='FLAT', note='Flat in q = M2/M1 (Sec. 3, p. 6).',
    quote='mass ratios from a flat distribution for'),
  'mass-ratio-min': dict(value='0.01', note='Sec. 3, p. 6.', quote='mass ratios from a flat distribution for'),
  'mass-ratio-max': dict(value='1.0', note='Sec. 3, p. 6.', quote='mass ratios from a flat distribution for'),
  'semi-major-axis-distribution': dict(value='FLATINLOG', note='Flat in log a (Sec. 3, p. 6).',
    quote='and initial semi-major axes from flat'),
  'semi-major-axis-min': dict(value='0.01 AU', note='Sec. 3, p. 6.', quote='and initial semi-major axes from flat'),
  'semi-major-axis-max': dict(value='1000 AU', note='Sec. 3, p. 6.', quote='and initial semi-major axes from flat'),
  'metallicity-distribution': dict(value='12 discrete values, 1e-4 to 0.03',
    note='Chosen to include the metallicities behind the Hurley et al. (2000) fitting formulae; the same seed set is re-evolved at each (Sec. 3, p. 6, fn. 4).',
    quote='we evolve this exact same set of binaries at 12 different metallicities'),
  'metallicity-min': dict(value='0.0001', note='Sec. 3, fn. 4.', quote='we evolve this exact same set of binaries at 12 different metallicities'),
  'metallicity-max': dict(value='0.03', note='Sec. 3, fn. 4.', quote='we evolve this exact same set of binaries at 12 different metallicities'),
  'OB-mass-loss-prescription': dict(value='VINK2021 (Vink & Sander 2021)',
    note='Shallower Z scaling than Vink et al. (2001): Mdot ~ Z^0.42 vs Z^0.85 (Sec. 3, p. 6).',
    quote='for OB stars, we use main-sequence wind-loss prescriptions from Vink & Sander (2021)'),
  'VMS-mass-loss-prescription': dict(value='SABHAHIT2023 (eq. 22)',
    note='For stars above 100 Msun, appropriate for optically thick winds (Sec. 3, p. 6).',
    quote='we adopt eq. 22 from Sabhahit et al. (2023), which is more appropriate for the expected optically thick winds'),
  'WR-mass-loss-prescription': dict(value='Vink (2017) low-L + Sander & Vink (2020) high-L, with the Sander et al. (2023) temperature correction',
    note='Split by luminosity rather than a single prescription (Sec. 3, p. 6).',
    quote='we apply the prescription from Vink (2017) for low-luminosity stripped stars'),
  'RSG-mass-loss-prescription': dict(value='DECIN2023 (Decin et al. 2024)',
    note='ALMA recalibration of Beasor et al. (2020); orders of magnitude below NJ90, which prevents RSG wind-stripping. This is the paper’s key input (Sec. 3, pp. 6-7).',
    quote='These new prescriptions result in mass-loss rates that are orders of magnitude lower than those of Nieuwenhuijzen & de Jager (1990), preventing RSGs from wind-stripping their envelopes.'),
  'remnant-mass-prescription': dict(value='FRYER2012 (fiducial) · MULLERMANDEL run as a variation',
    note='Deliberately not the v03.01.02 default, so results stay comparable to earlier literature (Sec. 3, p. 6).',
    quote='remnant-mass model from Fryer et al. (2012), and a Maxwellian kick distribution with'),
  'fryer-supernova-engine': dict(value='DELAYED', note='The "delayed" model of Fryer et al. (2012) (Sec. 3, p. 6).',
    quote='remnant-mass model from Fryer et al. (2012), and a Maxwellian kick distribution with'),
  'kick-magnitude-distribution': dict(value='MAXWELLIAN', note='Hobbs et al. (2005) (Sec. 3, p. 6).',
    quote='and a Maxwellian kick distribution with'),
  'kick-magnitude-sigma-CCSN-NS': dict(value='265 km/s',
    note='The value COMPAS methods paper II later corrects to 217 km/s (Sec. 3, p. 6).',
    quote='and a Maxwellian kick distribution with'),
  'kick-magnitude-sigma-ECSN': dict(value='30 km/s', note='Shared with ultra-stripped SNe (Sec. 3, p. 6).',
    quote='are expected to have smaller kicks than core-collapse SNe'),
  'kick-magnitude-sigma-USSN': dict(value='30 km/s', note='Shared with electron-capture SNe (Sec. 3, p. 6).',
    quote='are expected to have smaller kicks than core-collapse SNe'),
  'black-hole-kicks-mode': dict(value='FALLBACK',
    note='BH kicks reduced by the fallback fraction, which makes them effectively mass-scaled — the mechanism behind the CE-channel metallicity dependence (Sec. 3, p. 6).',
    quote='that is reduced by a fallback fraction for BH natal kicks'),
  'common-envelope-allow-radiative-envelope-survive': dict(value='FALSE (pessimistic)',
    note='All CEs from presumably radiative-envelope donors lead to stellar mergers; the paper names this its default and flags the optimistic alternative (Sec. 5).',
    quote='all common envelopes from donors with presumably radiative envelopes lead to stellar mergers'),
}

SUBMODEL_SUBTITLE = 'COMPAS v03.01.02 — van Son et al. (2024) · 5e6 binaries re-evolved at 12 metallicities with identical seeds · fiducial = Riley et al. (2022) settings except winds · the variations below are the paper’s own robustness tests'
SUBMODELS = [
  ('FIDUCIAL', [
    ('Reference model', 'Riley et al. (2022) settings, new winds',
     '<b>Fid:</b> Fryer12 Delayed · Maxwellian 265 km s⁻¹<br>fallback-reduced BH kicks · 30 km s⁻¹ for<br>ECSN/USSN · pessimistic CE<br>new OB / VMS / WR / RSG winds',
     '<b>Alt:</b> — (fiducial)',
     'Deliberately uses the OLD remnant and kick defaults even though v03.01.02 had already switched to the stochastic recipes, so the results stay comparable to the earlier literature compiled in Figure 1.',
     'Sec. 3 · p. 6',
     'Our fiducial model follows the settings as described in (Riley et al. 2022), with the exception of updated prescriptions for the wind mass loss'),
  ]),
  ('RED SUPERGIANT WINDS  ⚠ THE HEADLINE LEVER', [
    ('RSG mass-loss rates', 'Whether red supergiants wind-strip',
     '<b>Fid:</b> Decin et al. (2024), ALMA-recalibrated<br>from Beasor et al. (2020)',
     '<b>Literature standard:</b> de Jager et al. (1988) /<br>Nieuwenhuijzen &amp; de Jager (1990)<br>applied to all cool stars',
     'The new rates are orders of magnitude lower and prevent RSGs from stripping their own envelopes. The paper argues NJ90 was never intended for RSGs — the calibrating data span the whole HR diagram and contain only a handful of them. This is what drives the conclusion that BHBH formation may be much less metallicity dependent than assumed.',
     'Sec. 3 · pp. 6–7',
     'These new prescriptions result in mass-loss rates that are orders of magnitude lower than those of Nieuwenhuijzen & de Jager (1990), preventing RSGs from wind-stripping their envelopes.'),
  ]),
  ('REMNANT MASSES &amp; KICKS  (bridges to the code columns)', [
    ('Stochastic remnants and kicks', 'The v03.01.02 default, run as a variation',
     '<b>Fid:</b> Fryer12 Delayed + Maxwellian 265,<br>fallback-reduced for BHs',
     '<b>Alt:</b> Mandel &amp; Müller (2020) stochastic<br>remnant masses + momentum-preserving kicks',
     'The only column in this ledger that states both sides of the default change documented in COMPAS methods paper II. Because fallback-scaled BH kicks are effectively mass-scaled, and the stochastic recipe is not, this variation tests the paper’s central mechanism directly.',
     'Sec. 3 · p. 6',
     'the default settings have changed to use the stochastic remnant masses and corresponding momentum-preserving kicks from Mandel'),
  ]),
  ('COMMON ENVELOPE ASSUMPTION', [
    ('Pessimistic vs optimistic CE', 'Whether HG-donor CEs survive',
     '<b>Fid:</b> pessimistic — radiative-envelope<br>donors always merge',
     '<b>Alt:</b> optimistic (discussed, not adopted)',
     'As radii grow with metallicity, common envelopes that were case C become early case B. Under the pessimistic default those all become stellar mergers, which is a large part of why BHBH progenitors are lost at high Z. The paper states plainly that the optimistic assumption would let those systems survive instead.',
     'Sec. 5',
     'all common envelopes from donors with presumably radiative envelopes lead to stellar mergers'),
  ]),
  ('METALLICITY GRID  (the experimental design)', [
    ('12 metallicities, identical seeds', 'Metallicity as the only variable',
     '<b>Fid:</b> one set of 5e6 binaries<br>(mass, q, period, kick magnitude and<br>orientation drawn once)',
     '<b>Alt:</b> re-evolved at Z = 1e-4 … 0.03<br>aligned with the Hurley et al. (2000)<br>fitting-formula metallicities',
     'This is what separates the paper from every other column: a system can be a merging BHBH at one metallicity and a stellar merger at another, and the paper follows those same systems across the grid rather than comparing independent populations.',
     'Sec. 3 · p. 6 · fn. 4',
     'we evolve this exact same set of binaries at 12 different metallicities'),
  ]),
]

COSMIC = [
]
