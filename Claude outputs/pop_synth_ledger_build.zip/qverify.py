# -*- coding: utf-8 -*-
"""Normalise PDF text and verify that every quote in the ledger is literally present."""
import re, unicodedata

def norm(s):
    s = unicodedata.normalize('NFKC', s)
    # unify punctuation that PDF text and our data may spell differently
    for a, b in [('‘',"'"),('’',"'"),('“','"'),('”','"'),
                 ('–','-'),('—','-'),('−','-'),('­',''),
                 ('ﬁ','fi'),('ﬂ','fl'),(' ',' ')]:
        s = s.replace(a, b)
    s = re.sub(r'-\s*\n\s*', '', s)      # join hyphenated line breaks
    s = re.sub(r'\s+', ' ', s)           # collapse all whitespace
    return s.strip()

def load(path):
    raw = open(path, encoding='utf-8').read()
    return raw, norm(raw)

def check(quote, raw, flat):
    """Returns (found, ctrlf_safe). ctrlf_safe = quote sits on ONE line in the PDF text,
    so a viewer's find will match it without soft-wrap or hyphenation trouble."""
    q = norm(quote)
    found = q in flat
    safe = any(q in norm(line) and norm(line).find(q) >= 0 and '\n' not in line
               for line in raw.split('\n'))
    return found, safe
