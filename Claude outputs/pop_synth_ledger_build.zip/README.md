# Pop Synth Ledger — build

Compares population-synthesis papers' stated model assumptions side by side.
Every value carries the paper's own verbatim sentence, checked against the PDF
text at build time so it can be pasted straight into Ctrl-F.

## Build

    python3 build.py

Outputs `pop_synth_ledger.html` and `pop_synth_ledger_parameters.xlsx`.
Requires `openpyxl`. `ref.xlsx` is the COMPAS parameter reference; keep it here.

## Adding a paper

    pdftotext paper.pdf newid.txt          # quotes are checked against this
    python3 new_paper.py newid "Short Label"
    #  ... fill in papers/newid.py ...
    python3 build.py

That is the whole procedure. The generator discovers `papers/*.py`, assigns a
colour, widens the grid, adds the picker chip, the spreadsheet column group and
the notes entry. Files starting with `_` are ignored, so `papers/_TEMPLATE.py`
stays as a reference copy. Designed and load-tested for up to 25 papers.

## Files

| file | what it is |
|---|---|
| `papers/<id>.py` | one paper: metadata, values, quotes, flags, sub-models |
| `papers/_TEMPLATE.py` | blank scaffold, all rows pre-filled NOT SPECIFIED |
| `ledger_rows.py` | the 10 sections / 59 row names, what each parameter means, and manual agreement overrides |
| `build.py` | discovers papers, verifies quotes, writes both outputs |
| `template.py` | the HTML (CSS + client-side renderer) |
| `build_xlsx_multi.py` | the spreadsheet |
| `qverify.py` | text normalisation used by the quote checker |
| `<id>.txt` | `pdftotext` output for that paper |

## What a paper file carries

* `PAPER` — code name and version, which systems the simulation covers (BBH / BNS / BHNS / ...),
  the purpose of the paper, and a summary of what the model did. These fill the **Papers** sheet
  and the Legend & Notes tab.
* `ENTRIES[row]` — `value` (prose), `num` (machine-readable numbers), `desc`, `src`, `quote`.
* `num` keys are self-describing with the unit in the name — `IMF_M_min_Msun`,
  `R_z0.2_stable_Gpc3_yr`, `zeta_ad_HG` — because one row often pins several numbers at once.
* `primary` (optional) names the one quantity that is the fiducial value for that row.

### How numeric rows are displayed

There is no separate numeric column. Where a paper states numbers for a parameter, the
**value cell holds the numbers and nothing else** — no units, no prose — so the column can be
read straight into an analysis. The wording the paper used moves to the top of the description
cell after `Stated as:`. Three rules keep this honest:

* a cell with `primary` set (or exactly one quantity) is written as a **real number**, not text —
  in the HTML and as a real Excel number in the Core Ledger sheet;
* a row pinning several numbers at once lists them as name/number pairs, still numbers only;
* a `NOT SPECIFIED` cell stays `NOT SPECIFIED`. Numbers attached to such a row are context the
  paper mentions, not a value it states, and are flagged `context only` in the Numeric Values sheet.

The **Numeric Values** sheet is the analysis surface: one row per (paper, parameter, quantity,
value, is-a-stated-value, source), values as real numbers, ready to pivot.

### Columns

The HTML table has five columns per paper: Parameter | What the parameter is | Fiducial
Value/Flag | Description & Notes | Verbatim quote & source. The definition column is
deliberately repeated in every paper group so it always sits beside the parameter name you are
reading; it is written once in `PARAM_DESC` and repeated at render time, so a new paper file
never restates it. Toggle it off and it falls back to a small line under each parameter name.
In the workbook it is column D of the Core Ledger sheet, unrepeated. Parameter | Fiducial Value/Flag | Description &
Notes | Verbatim quote & source. There is no separate Source column — the source sits under
the quote it belongs to, because the two are only meaningful together. A row quote is sourced
to the row; the paper-level scope statement is sourced to itself and says so, and where the row
is also discussed elsewhere that appears as `row discussed at ...`.

The spreadsheet keeps source as its own column, since a flat column is easier to filter on than
a merged cell.

## Rules the build enforces

* A value appears only if the paper states it; otherwise `NOT SPECIFIED`.
  Nothing is inferred from code defaults, from another paper, or from cited works.
* Every non-empty quote must appear verbatim in that paper's text, or the build
  fails and names the offending quote.
* Duplicate paper ids and unknown COMPAS flag names abort the build.

## Notes

* Agreement shading is computed live over the *selected* papers, using token
  overlap (≥3 shared tokens, or ≥50% of the smaller set). Where that heuristic
  is wrong, add an entry to `MATCH_OVERRIDE` in `ledger_rows.py`; overridden
  rows are marked "⚠ manual call" in the table.
* Quotes are kept prose-only. PDF viewers match equation fragments, superscripts
  and words hyphenated across a line break unreliably.
* The `Default` column in the full list is from COMPAS commit 5f7cc502
  (2026-08-20) — current COMPAS, not the version any paper used.
