# -*- coding: utf-8 -*-
"""HTML template. Layout, CSS and colour language cloned from
COMPAS_COSMIC_SEVN_v32.html; the table itself is rendered client-side so the
same file works with 2 papers or 25."""
import json


def TEMPLATE(d):
    P = d['papers']
    DATA = json.dumps(d, ensure_ascii=False)
    badges = "\n    ".join(
        f'<span class="badge" style="background:rgba({p["tint"]},.6);color:{p["fg"]};'
        f'border:1px solid rgba({p["tint"]},.45)">{p["code"]} &middot; {p["cite"]} &middot; '
        f'{p["arxiv"]} &middot; {p.get("systems", p["focus"])}</span>' for p in P)
    n_default = min(3, len(P))
    n_papers = len(P)

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Pop Synth Ledger &mdash; Model Assumptions</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Mono:wght@300;400;500&family=Libre+Baskerville:wght@400;700&family=Space+Grotesk:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
:root {{
  --same-bg: rgba(160,220,176,0.13); --same-txt: #7cd890; --same-bdr: rgba(130,196,150,0.35);
  --diff-bg: rgba(220,140,155,0.11); --diff-txt: #e09098; --diff-bdr: rgba(200,110,125,0.35);
  --noequiv-bg: rgba(140,185,230,0.09); --noequiv-txt: #88aad0; --noequiv-bdr: rgba(110,160,210,0.3);
  --alt-bg: rgba(200,175,70,0.10); --alt-txt: #c8b850; --alt-bdr: rgba(190,165,60,0.35);
  --bg: #0c1118; --s1: #131820; --s2: #1a2232; --s3: #1f2a3e;
  --bdr: #252f42; --bdr2: #1e2838;
  --txt: #dce4f0; --dim: #7a8898; --faint: #4a5868;
  --accent: #c8a050;
  --mono: 'DM Mono', monospace;
  --serif: 'Libre Baskerville', serif;
  --sans: 'Space Grotesk', sans-serif;
  --hdr-h: 150px;
}}
*, *::before, *::after {{ box-sizing: border-box; margin: 0; padding: 0; }}
body {{ background: var(--bg); color: var(--txt); font-family: var(--sans); font-size: 12px; line-height: 1.5; }}

.masthead {{
  position: fixed; top: 0; left: 0; right: 0; z-index: 300;
  background: linear-gradient(180deg,#0a0f18,#0e1520);
  border-bottom: 1px solid var(--bdr); padding: 14px 28px 10px;
}}
.masthead-title {{ font-family: var(--serif); font-size: 17px; font-weight: 700; color: var(--accent); margin-bottom: 7px; }}
.badges-wrap {{ position:relative; margin-bottom: 8px; }}
.badges {{ display: flex; gap: 6px; flex-wrap: wrap; max-height:50px; overflow:hidden; }}
.badges.open {{ max-height:none; }}
.badges-wrap.clipped .badges:not(.open)::after {{ content:''; position:absolute; left:0; right:0; bottom:0;
  height:16px; background:linear-gradient(to bottom, transparent, var(--bg)); pointer-events:none; }}
.badges-toggle {{ display:none; margin-top:4px; padding:2px 8px; border-radius:3px; cursor:pointer;
  font-family: var(--mono); font-size:9.5px; letter-spacing:.06em; text-transform:uppercase;
  background:transparent; color:var(--faint); border:1px solid var(--rule); }}
.badges-wrap.clipped .badges-toggle {{ display:inline-block; }}
.badges-toggle:hover {{ color:var(--ink); border-color:var(--faint); }}
.badge {{ padding: 3px 9px; border-radius: 3px; font-family: var(--mono); font-size: 10px; font-weight: 500; letter-spacing:.04em; }}
.legend-row {{ display:flex; gap:14px; align-items:center; flex-wrap:wrap; }}
.li {{ display:flex; align-items:center; gap:5px; font-size:10.5px; color:var(--dim); }}
.ld {{ width:10px; height:10px; border-radius:2px; flex-shrink:0; }}
.ld-same    {{ background:var(--same-bg);   border:1px solid var(--same-bdr); }}
.ld-diff    {{ background:var(--diff-bg);   border:1px solid var(--diff-bdr); }}
.ld-noequiv {{ background:var(--noequiv-bg);border:1px solid var(--noequiv-bdr); }}
.ld-alt     {{ background:var(--alt-bg);    border:1px solid var(--alt-bdr); }}

.tabbar {{
  position: fixed; left: 0; right: 0; z-index: 290;
  background: #090d14; border-bottom: 1px solid var(--bdr);
  display: flex; align-items: center; padding: 0 28px;
}}
.tbtn {{
  padding: 9px 16px; border:none; background:transparent;
  font-family:var(--mono); font-size:10.5px; font-weight:500; letter-spacing:.08em; text-transform:uppercase;
  color:var(--dim); border-bottom:2px solid transparent; cursor:pointer; transition:all .12s; white-space:nowrap;
}}
.tbtn:hover {{ color:var(--txt); }}
.tbtn.active {{ color:var(--accent); border-bottom-color:var(--accent); }}
.fullbtn {{
  margin-left:auto; display:inline-flex; align-items:center; gap:7px;
  padding:5px 12px; border-radius:4px; cursor:pointer;
  background:var(--s2); border:1px solid var(--accent); color:var(--accent);
  font-family:var(--mono); font-size:10px; font-weight:600; letter-spacing:.08em; text-transform:uppercase;
  transition:all .12s; white-space:nowrap;
}}
.fullbtn:hover, .fullbtn.on {{ background:var(--accent); color:#0c1118; }}
.zoom-ctrls {{ margin-left:14px; display:flex; align-items:center; gap:7px; }}
.zbtn {{ width:22px; height:22px; border-radius:3px; border:1px solid var(--bdr); background:var(--s2); color:var(--dim);
        font-size:15px; cursor:pointer; display:flex; align-items:center; justify-content:center; transition:all .12s; flex-shrink:0; }}
.zbtn:hover {{ border-color:var(--accent); color:var(--accent); }}
#zslider {{ -webkit-appearance:none; appearance:none; width:90px; height:3px; background:var(--bdr); border-radius:2px; outline:none; cursor:pointer; }}
#zslider::-webkit-slider-thumb {{ -webkit-appearance:none; width:12px; height:12px; border-radius:50%; background:var(--accent); cursor:pointer; }}
#zlabel {{ font-family:var(--mono); font-size:10px; color:var(--dim); min-width:34px; text-align:right; }}

/* ── PAPER PICKER ── */
.pickbar {{ display:flex; gap:6px; align-items:center; flex-wrap:wrap; padding:10px 28px 0; }}
.chip {{
  display:inline-flex; align-items:center; gap:6px; padding:4px 10px; border-radius:12px;
  font-family:var(--mono); font-size:10px; cursor:pointer; user-select:none;
  border:1px solid var(--bdr); background:var(--s1); color:var(--faint); transition:all .12s;
}}
.chip .dot {{ width:8px; height:8px; border-radius:50%; flex-shrink:0; opacity:.35; }}
.chip.on {{ color:var(--txt); background:var(--s2); border-color:var(--dim); }}
.chip.on .dot {{ opacity:1; }}
.chip:hover {{ border-color:var(--accent); }}
.minibtn {{ padding:3px 9px; border-radius:3px; font-family:var(--mono); font-size:9.5px; cursor:pointer;
           border:1px solid var(--bdr); background:var(--s2); color:var(--dim); }}
.minibtn:hover {{ border-color:var(--accent); color:var(--accent); }}

.fbar {{ display:flex; gap:6px; align-items:center; flex-wrap:wrap; padding:10px 28px 10px; }}
.flbl {{ font-size:10px; color:var(--faint); font-family:var(--mono); text-transform:uppercase; letter-spacing:.08em; }}
.fbtn {{ padding:4px 10px; border-radius:3px; font-family:var(--mono); font-size:10px; font-weight:500; cursor:pointer;
        border:1px solid var(--bdr); background:var(--s2); color:var(--dim); transition:all .12s; }}
.fbtn:hover {{ border-color:var(--accent); color:var(--accent); }}
.fbtn.active {{ background:var(--accent); color:#0c1118; border-color:var(--accent); font-weight:700; }}

.panel {{ display:none; }}
.panel.active {{ display:block; }}
.zoom-wrap {{ padding: 0 28px 0; overflow-x: auto; }}
.zoom-inner {{ transform-origin: top left; display: inline-block; min-width: 100%; }}

.sec-block {{ margin-bottom: 24px; border:1px solid var(--bdr); border-radius:5px; overflow:hidden; }}
.sec-lbl {{ display:flex; align-items:center; gap:10px; padding:8px 16px;
  font-family:var(--mono); font-size:10.5px; font-weight:600; letter-spacing:.1em; text-transform:uppercase; color:#fff; }}
.sec-num {{ opacity:.5; font-size:9.5px; }}

.ghdr, .grow {{ display: grid; border-bottom: 1px solid var(--bdr2); }}
.grow:last-child {{ border-bottom:none; }}
.ghdr {{ background:var(--s3); border-bottom:1px solid var(--bdr); }}
.chdr {{ padding:7px 12px; font-family:var(--mono); font-size:9.5px; font-weight:600; letter-spacing:.09em; text-transform:uppercase; }}
.chdr-sep {{ background:var(--bdr); padding:0; }}
.chdr-p {{ opacity:.72; font-weight:400; white-space:nowrap; }}
.chdr-lead {{ background:var(--s3); color:var(--dim); }}

.cell {{ padding:10px 12px; font-size:11.5px; line-height:1.55;
  border-right:1px solid rgba(255,255,255,.04); word-break:break-word; }}
.cell:last-child {{ border-right:none; }}
.cell-sep {{ background:var(--bdr) !important; padding:0; }}
.cell-lead {{ background:var(--s2); font-weight:600; color:var(--txt); }}
.cdef {{ font-size:11px; line-height:1.55; opacity:.82; }}
.cpar {{ font-weight:600; }}
.pdesc {{ display:block; font-weight:400; font-size:10px; line-height:1.45; color:var(--dim); opacity:.8; margin-top:5px; }}
.cnum {{ font-family:var(--mono); font-size:10px; }}
.cnum1 {{ font-family:var(--mono); font-size:14px; font-weight:500; letter-spacing:.01em; }}
.stated {{ display:block; font-family:var(--mono); font-size:9.5px; color:var(--faint); margin-bottom:6px;
          padding-bottom:5px; border-bottom:1px dotted rgba(255,255,255,.10); white-space:pre-line; }}
.cnum .nq {{ display:block; word-break:break-word; overflow-wrap:anywhere; margin-bottom:3px; }}
.cnum .nq:last-child {{ margin-bottom:0; }}
.cnum .nk {{ opacity:.6; }}
.cnum .nv {{ font-weight:500; }}
.cnum .nnone {{ opacity:.45; font-style:italic; }}
.ovflag {{ display:block; font-family:var(--mono); font-size:8.5px; letter-spacing:.06em; text-transform:uppercase; color:var(--diff-txt); opacity:.85; margin-top:4px; cursor:help; }}
.cfid {{ font-family:var(--mono); font-size:10.5px; }}
.csrc {{ font-family:var(--mono); font-size:10px; opacity:.65; }}

/* verbatim quote cell */
.cquo {{ font-size:10.5px; line-height:1.55; position:relative; cursor:pointer; }}
.cquo .qt {{ font-style:italic; color:var(--txt); opacity:.9; }}
.cquo .qt::before {{ content:'\\201C'; }}
.cquo .qt::after  {{ content:'\\201D'; }}
.cquo .qnone {{ font-family:var(--mono); font-size:9.5px; color:var(--faint); font-style:normal; }}
.cquo .qsrc {{ display:block; font-family:var(--mono); font-size:10px; color:var(--txt); opacity:.62;
               margin-top:7px; padding-top:6px; border-top:1px dotted rgba(255,255,255,.13); }}
.cquo .qtag {{ display:block; font-family:var(--mono); font-size:8.5px; letter-spacing:.08em; text-transform:uppercase;
              color:var(--faint); margin-top:5px; }}
.cquo:hover .qtag::after {{ content:' &middot; click to copy'; }}
.cquo.copied .qtag {{ color:var(--same-txt); }}
.cquo.defer .qt {{ opacity:.62; }}

.fill-same    {{ background:var(--same-bg);   color:var(--same-txt); }}
.fill-diff    {{ background:var(--diff-bg);   color:var(--diff-txt); }}
.fill-noequiv {{ background:var(--noequiv-bg);color:var(--noequiv-txt); }}
.fill-noequiv.cfid {{ opacity:.75; font-style:italic; }}
.fill-alt     {{ background:var(--alt-bg);    color:var(--alt-txt); }}
.fill-meta    {{ background:rgba(255,255,255,.028); color:var(--txt); }}
.fill-meta.cdsc {{ line-height:1.6; }}
.grow:hover .cell {{ filter:brightness(1.06); }}
.grow.hidden, .sec-block.hidden {{ display:none; }}

/* ── PAPERS ── */
.papers-wrap {{ padding:0 28px 60px; display:flex; flex-direction:column; gap:18px; max-width:1180px; }}
.pcard {{ border:1px solid var(--bdr); border-radius:6px; overflow:hidden; background:var(--s1); }}
.pcard-hdr {{ padding:11px 16px; color:#fff; display:flex; align-items:baseline; gap:12px; flex-wrap:wrap; }}
.pcard-hdr .pc-cite {{ font-family:var(--serif); font-size:15px; font-weight:700; }}
.pcard-hdr .pc-meta {{ font-family:var(--mono); font-size:10px; opacity:.85; margin-left:auto; }}
.pc-title {{ padding:11px 16px; font-size:12.5px; line-height:1.55; color:var(--txt); background:var(--s2); border-bottom:1px solid var(--bdr); }}
.pc-grid {{ display:grid; grid-template-columns:150px 1fr; }}
.pc-k {{ padding:11px 16px; background:var(--s2); font-family:var(--mono); font-size:10px; font-weight:600;
        letter-spacing:.09em; text-transform:uppercase; color:var(--accent); border-top:1px solid var(--bdr2);
        border-right:1px solid var(--bdr2); }}
.pc-v {{ padding:11px 16px; font-size:12.5px; line-height:1.65; border-top:1px solid var(--bdr2); }}
.pc-v.mono {{ font-family:var(--mono); font-size:11px; }}
.pc-v .sub {{ display:block; color:var(--dim); font-size:11.5px; margin-top:5px; }}
.pc-quote {{ font-style:italic; color:var(--dim); cursor:pointer; }}
.plink {{ color:var(--accent); text-decoration:none; border-bottom:1px dotted rgba(200,160,80,.5); word-break:break-all; }}
.plink:hover {{ color:#e8c880; border-bottom-style:solid; }}
.citelist {{ display:flex; flex-direction:column; gap:7px; }}
.cite {{ padding-bottom:6px; border-bottom:1px dotted rgba(255,255,255,.07); }}
.cite:last-child {{ border-bottom:none; padding-bottom:0; }}
.cite .cw {{ display:block; color:var(--dim); font-size:11.5px; line-height:1.5; margin-top:2px; }}

/* ── SUB-MODELS ── */
.sub-wrap {{ padding:0 28px 60px; }}
.sub-grid {{ display:grid; gap:18px; }}
.sub-col {{ display:flex; flex-direction:column; gap:8px; min-width:0; }}
.sub-col-hdr {{ padding:9px 14px; font-family:var(--mono); font-size:11px; font-weight:700; letter-spacing:.1em; text-transform:uppercase; color:#fff; border-radius:4px 4px 0 0; }}
.sub-grp {{ padding:5px 12px 3px; font-family:var(--mono); font-size:9.5px; font-weight:600; letter-spacing:.1em; text-transform:uppercase; color:var(--faint); border-top:1px solid var(--bdr); margin-top:6px; }}
.sub-card {{ background:var(--s2); border:1px solid var(--bdr); border-radius:4px; padding:10px 12px; font-size:11px; }}
.sub-panel {{ font-family:var(--mono); font-size:11px; font-weight:700; color:var(--accent); margin-bottom:3px; }}
.sub-changed {{ font-weight:600; color:var(--txt); margin-bottom:5px; }}
.sub-vals {{ display:grid; grid-template-columns:1fr 1fr; gap:4px; margin:4px 0 6px; }}
.sub-fid {{ background:var(--same-bg); border-radius:3px; padding:3px 7px; font-family:var(--mono); font-size:10px; color:var(--same-txt); }}
.sub-alt-val {{ background:var(--diff-bg); border-radius:3px; padding:3px 7px; font-family:var(--mono); font-size:10px; color:var(--diff-txt); }}
.sub-effect {{ font-size:10.5px; color:var(--dim); line-height:1.5; border-top:1px solid var(--bdr2); padding-top:5px; margin-top:4px; }}
.sub-src {{ font-family:var(--mono); font-size:9.5px; color:var(--faint); margin-top:3px; }}

/* ── FULL LIST ── */
.full-wrap {{ padding:0 28px 60px; }}
.full-bar {{ display:flex; gap:6px; align-items:center; flex-wrap:wrap; padding:12px 0 10px; }}
#fsearch {{ background:var(--s1); border:1px solid var(--bdr); border-radius:3px; color:var(--txt);
  font-family:var(--mono); font-size:10.5px; padding:5px 9px; width:280px; outline:none; }}
#fsearch:focus {{ border-color:var(--accent); }}
#fcount {{ font-family:var(--mono); font-size:10px; color:var(--faint); margin-left:auto; }}
.full-scroll {{ overflow-x:auto; }}
.full-tbl {{ border:1px solid var(--bdr); border-radius:5px; }}
.fhdr, .frow {{ display:grid; border-bottom:1px solid var(--bdr2); }}
.fhdr {{ background:var(--s3); border-bottom:1px solid var(--bdr); }}
.full-tbl > .fhdr:first-child {{ border-radius:5px 5px 0 0; }}
.fhdr-rep {{ border-top:1px solid var(--bdr); }}
.fhdr > div {{ border-right:1px solid rgba(255,255,255,.05); }}
.fhdr > div:last-child {{ border-right:none; }}
.fhdr > div {{ padding:7px 11px; font-family:var(--mono); font-size:9.5px; font-weight:600; letter-spacing:.09em; text-transform:uppercase; color:var(--dim); }}
.frow {{ align-items:stretch; }}
.frow > div {{ padding:8px 11px; font-size:11px; border-right:1px solid rgba(255,255,255,.035);
              word-break:break-word; overflow-wrap:anywhere; min-width:0; }}
.frow > div:last-child {{ border-right:none; }}
.f-par {{ font-family:var(--mono); font-size:10.5px; color:var(--accent); font-weight:500; }}
.f-typ {{ font-family:var(--mono); font-size:9.5px; color:var(--faint); }}
.f-def {{ font-family:var(--mono); font-size:9.5px; color:var(--dim); }}
.f-val {{ font-family:var(--mono); font-size:10px; }}
.f-val small {{ display:block; font-family:var(--sans); font-size:10px; color:var(--dim); margin-top:3px; font-style:normal; }}
.f-val .fq {{ display:block; font-family:var(--sans); font-size:9.5px; font-style:italic; color:var(--dim);
             margin-top:5px; padding-top:5px; border-top:1px dotted rgba(255,255,255,.12); cursor:pointer; }}
.v-ns {{ background:var(--noequiv-bg); color:var(--noequiv-txt); font-style:italic; }}
.f-desc {{ color:var(--dim); font-size:10.5px; line-height:1.5; }}
.f-desc small {{ display:block; margin-top:4px; color:var(--faint); }}
.catrow {{ grid-column:1/-1; background:var(--s2); border-top:1px solid var(--bdr); }}
.catrow span {{ display:block; padding:7px 12px; font-family:var(--mono); font-size:10px; font-weight:700; letter-spacing:.12em; text-transform:uppercase; color:var(--accent); }}
.ci-tbl {{ margin-top:26px; }}
.full-note {{ font-family:var(--mono); font-size:10px; color:var(--faint); margin-top:12px; line-height:1.65; }}

/* ── NOTES ── */
.notes-wrap {{ padding:0 28px 60px; }}
.notes-grid {{ border:1px solid var(--bdr); border-radius:5px; overflow:hidden; }}
.nrow {{ display:grid; grid-template-columns:260px 1fr; border-bottom:1px solid var(--bdr2); }}
.nrow:last-child {{ border-bottom:none; }}
.nhdr {{ grid-column:1/-1; background:var(--s3); border-bottom:1px solid var(--bdr); }}
.nhdr span {{ display:block; padding:8px 16px; font-family:var(--mono); font-size:10px; font-weight:700; letter-spacing:.12em; text-transform:uppercase; color:var(--accent); }}
.nkey {{ background:var(--s2); padding:12px 16px; font-family:var(--mono); font-size:11px; font-weight:600; color:var(--accent); border-right:1px solid var(--bdr2); line-height:1.4; }}
.nval {{ background:var(--s1); padding:12px 16px; font-size:12px; color:var(--txt); line-height:1.65; }}
.nval code {{ font-family:var(--mono); font-size:11px; color:var(--accent); }}
.nval em.q {{ font-style:italic; color:var(--dim); }}

#toast {{ position:fixed; bottom:22px; left:50%; transform:translateX(-50%) translateY(20px);
  background:var(--accent); color:#0c1118; font-family:var(--mono); font-size:11px; font-weight:600;
  padding:8px 16px; border-radius:4px; opacity:0; transition:all .18s; pointer-events:none; z-index:500; }}
#toast.show {{ opacity:1; transform:translateX(-50%) translateY(0); }}

::-webkit-scrollbar {{ width:5px; height:8px; }}
::-webkit-scrollbar-track {{ background:var(--bg); }}
::-webkit-scrollbar-thumb {{ background:#2a3545; border-radius:3px; }}
</style>
</head>
<body>

<div class="masthead" id="masthead">
  <div class="masthead-title">Pop Synth Ledger &mdash; Population Synthesis Model Assumptions</div>
  <div class="badges-wrap" id="badgesWrap">
    <div class="badges" id="badges">
    {badges}
    </div>
    <button class="badges-toggle" id="badgesToggle" type="button"></button>
  </div>
  <div class="legend-row">
    <span style="font-size:9.5px;color:var(--faint);font-family:var(--mono);text-transform:uppercase;letter-spacing:.08em;margin-right:4px;">Shading:</span>
    <span class="li"><span class="ld ld-same"></span>Same</span>
    <span class="li"><span class="ld ld-diff"></span>Different</span>
    <span class="li"><span class="ld ld-noequiv"></span>NOT SPECIFIED / no equivalent</span>
    <span class="li"><span class="ld ld-alt"></span>Stated in one paper only</span>
    <span class="li" style="margin-left:6px;color:var(--faint)">Every value carries the paper's verbatim sentence &mdash; click a quote to copy it for Ctrl-F.</span>
  </div>
</div>

<div class="tabbar" id="tabbar">
  <button class="tbtn active" onclick="switchTab('main',this)">Main Parameters</button>
  <button class="tbtn" onclick="switchTab('papers',this)">Papers</button>
  <button class="tbtn" onclick="switchTab('sub',this)">Sub-Models</button>
  <button class="tbtn" onclick="switchTab('notes',this)">Legend &amp; Notes</button>
  <button class="fullbtn" id="fullbtn" onclick="switchTab('full',null)">&#9638;&nbsp; Full list &middot; <span id="fullcount"></span> params</button>
  <div class="zoom-ctrls">
    <button class="zbtn" onclick="adjustZoom(-0.05)">&#8722;</button>
    <input type="range" id="zslider" min="0.25" max="3" step="0.01" value="1" oninput="setZoom(parseFloat(this.value))">
    <button class="zbtn" onclick="adjustZoom(0.05)">&#43;</button>
    <span id="zlabel">100%</span>
    <button class="zbtn" onclick="resetZoom()" title="Reset">&#8635;</button>
  </div>
</div>

<div class="panel active" id="panel-main">
  <div class="pickbar">
    <span class="flbl">Papers:</span>
    <span id="chips"></span>
    <button class="minibtn" onclick="pickAll(true)">All</button>
    <button class="minibtn" onclick="pickAll(false)">None</button>
    <span class="flbl" style="margin-left:14px;">Columns:</span>
    <span id="colchips"></span>
  </div>
  <div class="fbar"><span class="flbl">Filter:</span>
    <button class="fbtn active" onclick="filterRows('all',this)">All</button>
    <button class="fbtn" onclick="filterRows('all-same',this)">&#x1F7E2; Same</button>
    <button class="fbtn" onclick="filterRows('all-diff',this)">&#x1F534; Different</button>
    <button class="fbtn" onclick="filterRows('alt',this)">&#x1F7E1; One paper only</button>
    <button class="fbtn" onclick="filterRows('noequiv',this)">&#x1F535; NOT SPECIFIED</button>
    <span class="flbl" id="rowcount" style="margin-left:12px;"></span>
  </div>
  <div class="zoom-wrap"><div class="zoom-inner" id="zoom-inner"></div></div>
</div>

<div class="panel" id="panel-papers"><div class="papers-wrap" id="papers-wrap"></div></div>

<div class="panel" id="panel-sub"><div class="sub-wrap"><div class="sub-grid" id="sub-grid"></div></div></div>

<div class="panel" id="panel-full">
<div class="full-wrap">
  <div class="full-bar">
    <input id="fsearch" type="text" placeholder="Search flag, category or description&hellip;" oninput="renderFull()">
    <button class="fbtn active" onclick="fullScope('all',this)">All</button>
    <button class="fbtn" onclick="fullScope('physical',this)">Physical</button>
    <button class="fbtn" onclick="fullScope('admin',this)">Administrative</button>
    <button class="fbtn" onclick="fullScope('specified',this)">&#9733; Stated by a paper</button>
    <span id="fcount"></span>
  </div>
  <div class="full-scroll">
    <div class="full-tbl"><div class="fhdr" id="fhdr"></div><div id="full-body"></div></div>
    <div class="full-tbl ci-tbl" id="ci-wrap"><div class="fhdr" id="ci-hdr"></div><div id="ci-body"></div></div>
  </div>
  <div class="full-note">
    * COMPAS defaults come from the supplied parameter reference (repository commit 5f7cc502, 2026-08-20). They are <em>not</em> the defaults of the
    versions used in these papers &mdash; orientation only, never a paper's value.<br>
    The cosmic-integration block lists Cosmic Integration suite inputs, which are not COMPAS <code>--flags</code> and so have no row above.
  </div>
</div>
</div>

<div class="panel" id="panel-notes"><div class="notes-wrap"><div class="notes-grid" id="notes-grid"></div></div></div>
<div id="toast"></div>

<script>
const D = {DATA};
const NS = D.NS;
const PAPERS = D.papers;
const COLS = [
  {{key:'param', label:'Parameter',            w:190, on:true}},
  {{key:'pdesc', label:'What the parameter is', w:240, on:true}},
  {{key:'value', label:'Fiducial Value / Flag', w:225, on:true}},
  {{key:'desc',  label:'Description &amp; Notes',   w:300, on:true}},
  {{key:'quote', label:'Verbatim quote &amp; source', w:330, on:true}}
];
let sel = new Set(PAPERS.slice(0, {n_default}).map(p => p.id));
let curFilter = 'all';
let fscope = 'all';

/* ───────── equivalence: same rule the reference file documents ───────── */
const FILLER = new Set(['the','a','an','of','in','to','and','or','for','with','at','on','from','by',
  'is','are','be','as','not','no','all','et','al','see','sec','eq','fig','p','pp','this','that','its']);
function toks(s) {{
  return new Set(String(s).replace(/<[^>]*>/g,' ').toLowerCase()
    .split(/[^a-z0-9.\\-]+/).filter(t => t.length > 1 && !FILLER.has(t)));
}}
function equiv(a, b) {{
  const A = toks(a), B = toks(b);
  if (!A.size || !B.size) return false;
  let sh = 0; A.forEach(t => {{ if (B.has(t)) sh++; }});
  const m = Math.min(A.size, B.size);
  return sh >= 3 || (sh >= 2 && sh >= 0.5 * m);
}}
function isNS(v) {{ return String(v).startsWith(NS); }}

function statusFor(cells, ids, rowName) {{
  const stated = ids.filter(id => cells[id] && !isNS(cells[id][0]));
  const fill = {{}};
  ids.forEach(id => fill[id] = 'fill-noequiv');
  if (stated.length === 0) return {{status:'noequiv', fill}};
  if (stated.length === 1) {{ fill[stated[0]] = 'fill-alt'; return {{status:'alt', fill}}; }}
  const ov = D.override[rowName];
  if (ov) {{
    if (ov[0] === 'groups' && ov[2]) {{
      let green = 0, red = 0;
      stated.forEach(id => {{
        const g = ov[2].find(gr => gr.indexOf(id) !== -1);
        const withMe = g ? stated.filter(o => g.indexOf(o) !== -1).length : 1;
        if (withMe > 1) {{ fill[id] = 'fill-same'; green++; }} else {{ fill[id] = 'fill-diff'; red++; }}
      }});
      const st = (green && red) ? 'pairwise' : (red ? 'all-diff' : 'all-same');
      return {{status: st, fill, ov: ov[1]}};
    }}
    const cls = ov[0] === 'same' ? 'fill-same' : 'fill-diff';
    stated.forEach(id => fill[id] = cls);
    return {{status: ov[0] === 'same' ? 'all-same' : 'all-diff', fill, ov: ov[1]}};
  }}
  // cluster by equivalence
  const clusters = [];
  stated.forEach(id => {{
    const hit = clusters.find(c => c.some(o => equiv(cells[id][0], cells[o][0])));
    if (hit) hit.push(id); else clusters.push([id]);
  }});
  if (clusters.length === 1) {{ stated.forEach(id => fill[id] = 'fill-same'); return {{status:'all-same', fill}}; }}
  if (clusters.every(c => c.length === 1)) {{ stated.forEach(id => fill[id] = 'fill-diff'); return {{status:'all-diff', fill}}; }}
  const big = clusters.reduce((a, b) => b.length > a.length ? b : a);
  stated.forEach(id => fill[id] = big.includes(id) ? 'fill-same' : 'fill-diff');
  return {{status:'pairwise', fill}};
}}

/* Paper-level rows appended as a final section of the main table. These describe
   the paper as a whole rather than one assumption, so they are never shaded for
   agreement and are hidden by every filter except All. */
const META_ROWS = [
  ['Code &amp; version',      'Which code and release the simulation was run with.',
   p => p.code_version || '', p => (p.code_name || '')],
  ['Systems covered',         'Which kinds of system the simulation actually produces.',
   p => p.systems || '',      p => p.systems_detail || ''],
  ['Purpose of the paper',    'Why the paper was written, in one sentence.',
   p => '', p => p.purpose || ''],
  ['What the model did',      'What the simulation and analysis actually consisted of.',
   p => '', p => p.summary || ''],
  ['Link to the paper',       'Where to read the paper itself.',
   p => '', p => p.url ? '<a class="plink" href="' + p.url + '" target="_blank" rel="noopener">' + p.url + '</a>' : ''],
  ['Cite these',              'Works a result taken from this paper rests on.',
   p => (p.citations || []).length ? (p.citations || []).length : '',
   p => (p.citations || []).map(c => '<a class="plink" href="' + c[1] + '" target="_blank" rel="noopener">' + c[0] + '</a>').join(' &middot; ')],
  ['Scope statement',         'The paper\u2019s own sentence for why a class of parameters is absent.',
   p => '', p => '', true],
];

function metaSection(ids, g) {{
  let body = META_ROWS.map(([name, pdescTxt, valFn, descFn, isScope]) => {{
    const pdesc = COLS[1].on ? '' : '<span class="pdesc">' + pdescTxt + '</span>';
    let r = '<div class="grow" data-status="meta" style="grid-template-columns:' + g.css + ';width:' + g.width + 'px">';
    r += leadCells(name);
    ids.forEach((id, i) => {{
      if (i) r += '<div class="cell cell-sep"></div>';
      const p = paper(id);
      const lb = 'border-left:3px solid rgba(' + p.tint + ',.75) !important;';
      visCols().forEach((col, j) => {{
        const style = j === 0 ? ' style="' + lb + '"' : '';
        if (col.key === 'pdesc') r += '<div class="cell cdef fill-meta"' + style + '>' + pdescTxt + '</div>';
        else if (col.key === 'param') r += '<div class="cell cpar fill-meta"' + style + '>' + name + pdesc + '</div>';
        else if (col.key === 'value') r += '<div class="cell cfid fill-meta"' + style + '>' + (valFn(p) || '&mdash;') + '</div>';
        else if (col.key === 'desc') r += '<div class="cell cdsc fill-meta"' + style + '>' + (descFn(p) || '&mdash;') + '</div>';
        else if (isScope && p.deferral) r += '<div class="cell cquo defer fill-meta" data-q="' + p.deferral.replace(/"/g,'&quot;') +
          '"><span class="qt">' + p.deferral + '</span><span class="qsrc">' + (p.deferral_src || '') +
          '</span><span class="qtag">scope statement &middot; verbatim</span></div>';
        else r += '<div class="cell cquo fill-meta"><span class="qnone">&mdash;</span></div>';
      }});
    }});
    return r + '</div>';
  }}).join('');

  let hdr = '<div class="ghdr" style="grid-template-columns:' + g.css + ';width:' + g.width + 'px">';
  hdr += (COLS[0].on ? '' : '<div class="chdr chdr-lead">Paper-level</div>');
  ids.forEach((id, i) => {{
    if (i) hdr += '<div class="chdr chdr-sep"></div>';
    const p = paper(id);
    visCols().forEach(col => {{
      hdr += '<div class="chdr" style="background:rgba(' + p.tint + ',.35);color:' + p.fg + '">' +
             col.label + ' <span class="chdr-p">(' + p.label + ')</span></div>';
    }});
  }});
  hdr += '</div>';

  return '<div class="sec-block" style="width:' + g.width + 'px">' +
    '<div class="sec-lbl" style="background:#4c5a6e;width:' + g.width + 'px">' +
    '<span class="sec-num">&sect;11</span><span>THE PAPER ITSELF</span>' +
    '<span style="margin-left:auto;opacity:.7;font-size:9.5px">Paper-level, not per-parameter &middot; not shaded for agreement</span>' +
    '</div>' + hdr + body + '</div>';
}}

/* ───────── main table ───────── */
function visCols() {{ return COLS.filter(c => c.on); }}
function selIds() {{ return PAPERS.filter(p => sel.has(p.id)).map(p => p.id); }}
function paper(id) {{ return PAPERS.find(p => p.id === id); }}

function gridSpec(ids) {{
  const vc = visCols();
  const per = vc.map(c => c.w + 'px').join(' ');
  const lead = COLS[0].on ? '' : '220px ';
  return {{
    css: lead + ids.map(() => per).join(' 6px '),
    width: (COLS[0].on ? 0 : 220) + ids.length * vc.reduce((s, c) => s + c.w, 0) + (ids.length - 1) * 6
  }};
}}
function leadHdr()  {{ return COLS[0].on ? '' : '<div class="chdr chdr-lead">Parameter</div>'; }}
function leadCells(name) {{ return COLS[0].on ? '' : '<div class="cell cell-lead">' + name + '</div>'; }}

function esc(s) {{ return String(s == null ? '' : s); }}

// A row is numeric when the paper states numbers for it. Then the value cell holds
// the numbers and nothing else, so the column is directly analysable; whatever prose
// the paper used is preserved in the Description column.
function valueCell(cell, fillCls, style) {{
  const n = cell[4] || {{}};
  // A NOT SPECIFIED cell stays NOT SPECIFIED. Numbers attached to such a row are
  // context (a range the paper mentions), not a value the paper states, and must
  // never be shown as one.
  const keys = isNS(cell[0]) ? [] : Object.keys(n);
  if (!keys.length)
    return '<div class="cell cfid ' + fillCls + '"' + style + '>' + esc(cell[0]) + '</div>';
  const prim = (cell[5] && n[cell[5]] !== undefined) ? cell[5] : (keys.length === 1 ? keys[0] : null);
  if (prim)
    return '<div class="cell cfid cnum1 ' + fillCls + '"' + style + ' title="' + prim +
           (keys.length > 1 ? ' (fiducial; ' + (keys.length - 1) + ' more in the Numeric Values sheet)' : '') +
           '">' + n[prim] + '</div>';
  return '<div class="cell cfid cnum ' + fillCls + '"' + style + '>' + keys.map(k =>
    '<span class="nq" title="' + k + ' = ' + n[k] + '"><span class="nk">' + k + '</span> <span class="nv">' + n[k] + '</span></span>').join('') + '</div>';
}}

// The quote cell carries the sentence and, underneath it, where that sentence is.
// A row quote is sourced to the row; the paper-level scope statement is sourced to
// itself and says so, which is why such a row has no section of its own.
function quoteCell(cell, p, fillCls) {{
  const q = cell[3], rowSrc = (cell[2] && cell[2] !== '\u2014') ? cell[2] : '';
  if (q) return '<div class="cell cquo ' + fillCls + '" data-q="' + q.replace(/"/g,'&quot;') +
    '"><span class="qt">' + q + '</span>' +
    '<span class="qsrc">' + (rowSrc || 'verbatim') + '</span>' +
    '<span class="qtag">' + p.label + ' &middot; verbatim</span></div>';
  if (p.deferral) return '<div class="cell cquo defer ' + fillCls + '" data-q="' + p.deferral.replace(/"/g,'&quot;') +
    '"><span class="qt">' + p.deferral + '</span>' +
    '<span class="qsrc">' + (p.deferral_src || '') +
      (rowSrc && rowSrc !== p.deferral_src ? ' &nbsp;|&nbsp; row discussed at ' + rowSrc : '') + '</span>' +
    '<span class="qtag">why it is absent &middot; paper-level, not this row</span></div>';
  return '<div class="cell cquo ' + fillCls + '"><span class="qnone">&mdash; no statement in paper &mdash;</span>' +
    (rowSrc ? '<span class="qsrc">row discussed at ' + rowSrc + '</span>' : '') + '</div>';
}}

function renderMain() {{
  const ids = selIds();
  const host = document.getElementById('zoom-inner');
  if (!ids.length) {{ host.innerHTML = '<div style="padding:40px;color:var(--faint);font-family:var(--mono)">Select at least one paper above.</div>'; return; }}
  const g = gridSpec(ids), vc = visCols();
  let shown = 0, out = [];
  D.sections.forEach(([num, title, colour, rows]) => {{
    let body = [], secShown = 0;
    rows.forEach(row => {{
      const name = row[0], cells = row[1];
      const st = statusFor(cells, ids, name);
      const pdesc = (!COLS[1].on && row[2]) ? '<span class="pdesc">' + row[2] + '</span>' : '';
      const hide = (curFilter !== 'all' && st.status !== curFilter);
      if (!hide) {{ secShown++; shown++; }}
      let r = '<div class="grow' + (hide ? ' hidden' : '') + '" data-status="' + st.status + '" style="grid-template-columns:' + g.css + ';width:' + g.width + 'px">';
      r += leadCells(name);
      ids.forEach((id, i) => {{
        if (i) r += '<div class="cell cell-sep"></div>';
        const p = paper(id), c = cells[id] || [NS, '', '—', '', {{}}, ''], f = st.fill[id];
        const lb = 'border-left:3px solid rgba(' + p.tint + ',.75) !important;';
        vc.forEach((col, j) => {{
          const style = j === 0 ? ' style="' + lb + '"' : '';
          if (col.key === 'pdesc') r += '<div class="cell cdef ' + f + '"' + style + '>' + (row[2] || '&mdash;') + '</div>';
          else if (col.key === 'param') r += '<div class="cell cpar ' + f + '"' + style + ' title="' +
              (st.ov ? String(st.ov).replace(/"/g,'&quot;') : '') + '">' + name +
              (st.ov ? '<span class="ovflag">&#9888; manual call</span>' : '') + pdesc + '</div>';
          else if (col.key === 'value') r += valueCell(c, f, style);
          else if (col.key === 'desc') {{
            const hasNum = !isNS(c[0]) && Object.keys(c[4] || {{}}).length > 0;
            const asStated = hasNum ? '<span class="stated">Stated as: ' + esc(c[0]) + '</span>' : '';
            r += '<div class="cell cdsc ' + f + '"' + style + '>' + asStated + esc(c[1]) + '</div>';
          }}
          else r += quoteCell(c, p, f);
        }});
      }});
      body.push(r + '</div>');
    }});
    let hdr = '<div class="ghdr" style="grid-template-columns:' + g.css + ';width:' + g.width + 'px">';
    hdr += leadHdr();
    ids.forEach((id, i) => {{
      if (i) hdr += '<div class="chdr chdr-sep"></div>';
      const p = paper(id);
      vc.forEach(col => {{
        hdr += '<div class="chdr" style="background:rgba(' + p.tint + ',.35);color:' + p.fg + '">' +
               col.label + ' <span class="chdr-p">(' + p.label + ')</span></div>';
      }});
    }});
    hdr += '</div>';
    out.push('<div class="sec-block' + (secShown ? '' : ' hidden') + '" style="width:' + g.width + 'px">' +
      '<div class="sec-lbl" style="background:' + colour + ';width:' + g.width + 'px"><span class="sec-num">&sect;' + num +
      '</span><span>' + title + '</span></div>' + hdr + body.join('') + '</div>');
  }});
  if (curFilter === 'all') out.push(metaSection(ids, g));
  host.innerHTML = out.join('');
  document.getElementById('rowcount').textContent =
    shown + ' of ' + D.nParams + ' rows · ' + ids.length + ' of ' + PAPERS.length + ' papers · 10 sections';
  syncZoomHeight();
}}

function filterRows(t, btn) {{
  curFilter = t;
  document.querySelectorAll('#panel-main .fbtn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  renderMain();
}}

/* ───────── chips ───────── */
function renderChips() {{
  document.getElementById('chips').innerHTML = PAPERS.map(p =>
    '<span class="chip' + (sel.has(p.id) ? ' on' : '') + '" onclick="togglePaper(\\'' + p.id + '\\')">' +
    '<span class="dot" style="background:' + p.colour + '"></span>' + p.label + '</span>').join(' ');
  document.getElementById('colchips').innerHTML = COLS.map((c, i) =>
    '<span class="chip' + (c.on ? ' on' : '') + '" onclick="toggleCol(' + i + ')">' + c.label + '</span>').join(' ');
}}
function togglePaper(id) {{ sel.has(id) ? sel.delete(id) : sel.add(id); renderChips(); renderMain(); renderSub(); renderFull(); }}
function pickAll(on) {{ sel = on ? new Set(PAPERS.map(p => p.id)) : new Set(); renderChips(); renderMain(); renderSub(); renderFull(); }}
function toggleCol(i) {{
  if (COLS[i].on && visCols().length === 1) return;
  COLS[i].on = !COLS[i].on; renderChips(); renderMain();
}}

/* ───────── papers ───────── */
function renderPapers() {{
  document.getElementById('papers-wrap').innerHTML = PAPERS.map(p => {{
    const row = (k, v, cls) => v ? '<div class="pc-k">' + k + '</div><div class="pc-v ' + (cls || '') + '">' + v + '</div>' : '';
    return '<div class="pcard">'
      + '<div class="pcard-hdr" style="background:' + p.colour + '">'
      +   '<span class="pc-cite">' + p.cite + '</span>'
      +   '<span class="pc-meta">' + (p.code_name || '') + ' ' + (p.code_version || '') + ' &middot; ' + p.arxiv + '</span>'
      + '</div>'
      + (p.title ? '<div class="pc-title">' + p.title + '</div>' : '')
      + '<div class="pc-grid">'
      +   row('Code', (p.code_name || '') + ' <b>' + (p.code_version || '') + '</b>', 'mono')
      +   row('Systems covered', '<b>' + (p.systems || '') + '</b>' +
              (p.systems_detail ? '<span class="sub">' + p.systems_detail + '</span>' : ''))
      +   row('Purpose of the paper', p.purpose)
      +   row('What the model did', p.summary)
      +   row('Link to the paper', p.url
              ? '<a class="plink" href="' + p.url + '" target="_blank" rel="noopener">' + p.url + '</a>'
              : '', 'mono')
      +   row('Cite these' + (p.citations && p.citations.length ? ' (' + p.citations.length + ')' : ''),
              (p.citations || []).length
                ? '<div class="citelist">' + p.citations.map(c =>
                    '<div class="cite"><a class="plink" href="' + c[1] + '" target="_blank" rel="noopener">' +
                    c[0] + '</a><span class="cw">' + c[2] + '</span></div>').join('') + '</div>'
                : '')
      +   row('Scope statement', p.deferral ? '<span class="pc-quote cquo" data-q="' +
              p.deferral.replace(/"/g,'&quot;') + '">&ldquo;' + p.deferral + '&rdquo;</span>' +
              (p.deferral_src ? '<span class="sub">' + p.deferral_src + ' &middot; click to copy</span>' : '') : '')
      +   row('Data / code', p.extra, 'mono')
      + '</div></div>';
  }}).join('');
}}

/* ───────── sub-models ───────── */
function renderSub() {{
  const ids = selIds();
  const grid = document.getElementById('sub-grid');
  grid.style.gridTemplateColumns = 'repeat(' + Math.max(1, Math.min(ids.length, 3)) + ', minmax(340px, 1fr))';
  grid.innerHTML = ids.map(id => {{
    const p = paper(id), sm = D.submodels.find(s => s.id === id);
    let o = '<div class="sub-col"><div class="sub-col-hdr" style="background:' + p.colour + '">' + p.cite + ' &mdash; Sub-Models</div>';
    if (sm && sm.subtitle) o += '<div class="sub-grp">' + sm.subtitle + '</div>';
    if (!sm || !sm.groups.length) o += '<div class="sub-card" style="color:var(--faint)">No variation grid recorded for this paper.</div>';
    (sm ? sm.groups : []).forEach(([g, cards]) => {{
      o += '<div class="sub-grp">' + g + '</div>';
      cards.forEach(c => {{
        o += '<div class="sub-card"><div class="sub-panel">' + c[0] + '</div><div class="sub-changed">' + c[1] + '</div>' +
             '<div class="sub-vals"><div class="sub-fid">' + c[2] + '</div><div class="sub-alt-val">' + c[3] + '</div></div>' +
             '<div class="sub-effect">' + c[4] + '</div><div class="sub-src">' + c[5] + '</div>';
        if (c[6]) o += '<div class="sub-effect cquo" data-q="' + c[6].replace(/"/g,'&quot;') + '"><span class="qt">' + c[6] + '</span><span class="qtag">verbatim</span></div>';
        o += '</div>';
      }});
    }});
    return o + '</div>';
  }}).join('');
}}

/* ───────── full list ───────── */
function fullScope(s, btn) {{
  fscope = s;
  document.querySelectorAll('.full-bar .fbtn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active'); renderFull();
}}
function renderFull() {{
  const ids = selIds();
  const q = (document.getElementById('fsearch').value || '').trim().toLowerCase();
  const spec = '250px 82px 190px ' + ids.map(() => '250px').join(' ') + ' minmax(320px,1fr)';
  let hdr = '<div>Parameter (COMPAS <code>--flag</code>)</div><div>Type</div><div>COMPAS default*</div>';
  ids.forEach(id => {{ const p = paper(id);
    hdr += '<div style="background:rgba(' + p.tint + ',.35);color:' + p.fg + '">' + p.cite + '</div>'; }});
  hdr += '<div>COMPAS description</div>';
  const fh = document.getElementById('fhdr');
  fh.style.gridTemplateColumns = spec; fh.innerHTML = hdr;
  const repHdr = '<div class="fhdr fhdr-rep" style="grid-template-columns:' + spec + '">' + hdr + '</div>';

  let out = [], lastCat = null, n = 0;
  D.flags.forEach(r => {{
    if (fscope === 'physical' && r.kind !== 'physical') return;
    if (fscope === 'admin' && r.kind !== 'admin') return;
    if (fscope === 'specified' && !ids.some(id => r.v[id] && !isNS(r.v[id][0]))) return;
    if (q) {{
      const hay = (r.par+' '+r.cat+' '+r.desc+' '+r.dflt+' '+r.allowed+' '+
                   ids.map(id => (r.v[id]||[]).join(' ')).join(' ')).toLowerCase();
      if (hay.indexOf(q) === -1) return;
    }}
    if (r.cat !== lastCat) {{
      out.push('<div class="frow" style="grid-template-columns:' + spec + '"><div class="catrow"><span>' + r.cat + '</span></div></div>');
      if (n) out.push(repHdr);   // repeat the column names under every category banner
      lastCat = r.cat;
    }}
    n++;
    let row = '<div class="frow" style="grid-template-columns:' + spec + '">'
      + '<div class="f-par">--' + r.par + '</div><div class="f-typ">' + r.typ + '</div>'
      + '<div class="f-def">' + (r.dflt || '&mdash;') + '</div>';
    ids.forEach(id => {{
      const p = paper(id), v = r.v[id] || [NS, '', ''];
      const ns = isNS(v[0]);
      const style = ns ? '' : ' style="background:rgba(' + p.tint + ',.22);color:' + p.fg + '"';
      row += '<div class="f-val' + (ns ? ' v-ns' : '') + '"' + style + '>' + v[0]
           + (v[1] ? '<small>' + v[1] + '</small>' : '')
           + (v[2] ? '<span class="fq cquo" data-q="' + v[2].replace(/"/g,'&quot;') + '">&ldquo;' + v[2] + '&rdquo;</span>' : '')
           + '</div>';
    }});
    const allowed = r.allowed ? '<small>Allowed: ' + r.allowed + '</small>' : '';
    out.push(row + '<div class="f-desc">' + r.desc + allowed + '</div></div>');
  }});
  document.getElementById('full-body').innerHTML = out.join('');
  document.getElementById('fcount').textContent = n + ' of ' + D.flags.length + ' rows shown';
  document.getElementById('fullcount').textContent = D.flags.length;

  // cosmic-integration block
  const ciRows = [];
  ids.forEach(id => (D.cosmic.find(c => c.id === id) || {{rows:[]}}).rows.forEach(r => ciRows.push([id, r])));
  const ciWrap = document.getElementById('ci-wrap');
  ciWrap.style.display = ciRows.length ? '' : 'none';
  if (ciRows.length) {{
    const cspec = '210px 200px 260px minmax(300px,1fr) 190px';
    const ch = document.getElementById('ci-hdr');
    ch.style.gridTemplateColumns = cspec;
    ch.innerHTML = '<div>Cosmic-integration parameter</div><div>Paper</div><div>Value</div><div>Description</div><div>Source</div>';
    document.getElementById('ci-body').innerHTML = ciRows.map(([id, r]) => {{
      const p = paper(id);
      return '<div class="frow" style="grid-template-columns:' + cspec + '">'
        + '<div class="f-par">' + r[0] + '</div>'
        + '<div class="f-typ" style="color:' + p.fg + '">' + p.label + '</div>'
        + '<div class="f-val" style="background:rgba(' + p.tint + ',.22);color:' + p.fg + '">' + r[1]
        + (r[4] ? '<span class="fq cquo" data-q="' + String(r[4]).replace(/"/g,'&quot;') + '">&ldquo;' + r[4] + '&rdquo;</span>' : '') + '</div>'
        + '<div class="f-desc">' + r[2] + '</div><div class="f-typ">' + r[3] + '</div></div>';
    }}).join('');
  }}
}}

/* ───────── notes ───────── */
function renderNotes() {{
  const rows = [];
  const H = t => rows.push('<div class="nrow nhdr"><span>' + t + '</span></div>');
  const R = (k, v) => rows.push('<div class="nrow"><div class="nkey">' + k + '</div><div class="nval">' + v + '</div></div>');

  H('COLOUR SCHEME');
  R('&#x1F7E2; Green fill', 'Same or directly comparable value between two or more of the displayed papers. Colouring is per paper: if two papers agree, those cells are green while a third disagreeing paper is red.');
  R('&#x1F534; Red fill', 'Different choice made by this paper compared to the others displayed.');
  R('&#x1F535; Blue fill', 'NOT SPECIFIED &mdash; the paper does not state a value; or no direct equivalent / not applicable / not modelled. Usually the largest category.');
  R('&#x1F7E1; Yellow fill', 'Stated in exactly one of the displayed papers. That paper&rsquo;s cells are yellow; the silent papers are blue.');
  R('Recomputed live', 'Shading is computed over the <em>currently selected</em> papers, so adding or removing a paper with the chips re-colours the table.');

  H('VERBATIM QUOTES');
  R('What they are', 'Each cell&rsquo;s quote column carries a sentence copied verbatim from that paper, so it can be checked with Ctrl-F in the PDF. Click any quote to copy it to the clipboard.');
  R('Build-time check', D.nQuotes + ' quotes are verified against the papers&rsquo; extracted text on every build; the build fails if any quote is not literally present. Quotes are kept prose-only (no equation fragments, super- or subscripts) because PDF viewers match those unreliably.');
  R('Hyphenation caveat', 'A word broken across a line in the PDF (&ldquo;log-<br>uniformly&rdquo;) will not match a Ctrl-F search that spans the break. Quotes are chosen to avoid this, and any that end mid-phrase were trimmed for exactly that reason.');
  R('Two kinds of quote', 'A quote tagged with the paper name and a section is a <b>row quote</b>: the sentence in which that paper states that parameter, and it always matches the Source column beside it. A quote tagged <em>why it is absent &middot; paper-level, not this row</em> is the paper&rsquo;s single scope or deferral statement, reused on every NOT SPECIFIED row. It is dimmer, and it carries its own location rather than the row&rsquo;s &mdash; which is why such a row can show a quote while its Source column reads &ldquo;&mdash;&rdquo;: the paper never states that parameter anywhere, so there is no section to point at.');
  R('Source without a row quote', 'Some NOT SPECIFIED rows do have a location: the paper touches the topic (defines a channel, names a caveat) without ever stating a value. Those appear under the scope statement as <em>row discussed at &hellip;</em>, kept visibly separate from the scope statement&rsquo;s own location.');

  H('NUMERIC VALUES');
  R('Numeric rows carry numbers only', 'Where a paper states a number for a parameter, the Fiducial Value cell holds <em>the number and nothing else</em> &mdash; no units, no prose &mdash; so the column can be read straight into an analysis. The sentence the paper actually used is not lost: it moves to the top of the Description cell, marked <em>Stated as:</em>. Rows with no numeric content keep their prose value as normal, so nothing is forced into a number that is not one.');
  R('Units and multiple numbers', 'Units live in the quantity name rather than the cell (<code>IMF_M_min_Msun</code>, <code>R_z0.2_stable_Gpc3_yr</code>, <code>zeta_ad_HG</code>). A single number is shown bare; where one ledger row pins down several at once &mdash; a stability criterion fixing zeta and both critical mass ratios, say &mdash; the cell lists them as name/number pairs. ' + D.nNumeric + ' numbers in total.');
  R('For analysis', 'The workbook has a tidy <b>Numeric Values</b> sheet &mdash; one row per (paper, parameter, quantity, value), values written as real numbers, not text &mdash; which pivots directly. In the Core Ledger sheet, a value cell holding exactly one number is written as a real number too.');

  H('COLUMN STRUCTURE');
  R('What the parameter is', 'The second column of every paper group defines the row &mdash; what the parameter actually means. It is deliberately identical across paper groups, so the definition always sits next to the parameter name you are reading rather than back at the far left of a wide table. It is written once in <code>PARAM_DESC</code> and repeated at render time, so a new paper file never restates it. Toggle it off with its chip and it drops back to a small line under each parameter name. In the workbook it is column D of the Core Ledger sheet, unrepeated.');
  R(visCols().length + ' columns per paper', 'Parameter | Fiducial Value/Flag | Description &amp; Notes | Verbatim quote &amp; source, with a thin separator between paper groups. There is no separate Source column: the source sits under the quote it belongs to, since the two are only meaningful together. Toggle columns and papers with the chips above the filter bar. Turning the Parameter column off collapses it into one shared leading column, which is how the table stays readable past about six papers.');
  R('Papers', PAPERS.length + ' loaded, ' + selIds().length + ' displayed. The file is built from one source file per paper and is sized for up to 25.');

  H('MATCHING');
  R('Method', 'Values come from a full read of each PDF. A value appears only where the paper states it in its own text, table, equation or figure, with the section / equation / page in the Source column and the sentence itself in the quote column. Nothing is inferred from COMPAS defaults, from another paper, or from works a paper cites &mdash; those are written as NOT SPECIFIED.');
  R('Manual overrides', Object.keys(D.override).length + ' rows carry a manual agreement call that beats the automatic heuristic, marked <span style="color:var(--diff-txt)">&#9888; manual call</span> in the Parameter cell (hover for the reason): ' +
    Object.entries(D.override).map(([k, v]) => '<br><code>' + k + '</code> &rarr; forced <em>' + v[0] + '</em> &mdash; ' + v[1]).join(''));
  R('Agreement detection', 'Pairwise agreement is detected by keyword token overlap: &ge;3 shared tokens, or &ge;50% overlap with the smaller token set (minimum 2 tokens), after removing filler words. Same rule as the COMPAS &times; COSMIC &times; SEVN comparison, so it scales as papers are added.');

  H('CITATIONS');
  R('What the list is', 'Each paper on the <b>Papers</b> tab carries a <b>Cite these</b> row: the works a result taken from that paper actually rests on &mdash; the code and version, the prescriptions it adopts, and the inputs it inherits from earlier papers &mdash; each linked to its DOI, arXiv entry or ADS record. It is derived from what the paper states and from what this ledger records in its rows, <em>not</em> from the paper&rsquo;s whole reference list, so it is a starting point for your own bibliography rather than a substitute for checking it.');
  R('Inherited attribution', 'Watch the chains. van Son et al. (2023) states almost no binary physics of its own: a result you take from that column is really a result of van Son et al. (2022b), which in turn inherits its star-formation history from van Son et al. (2022a). Those are marked in the list.');

  H('PAPERS IN THIS LEDGER');
  R('Where this lives', 'Each paper&rsquo;s purpose, what its model actually did, and which systems its simulation covers appear in three places: as <b>&sect;11 The Paper Itself</b> at the foot of the Main Parameters table, on the <b>Papers</b> tab in full, and in the workbook as the <b>Papers</b> sheet (column F = systems covered, H = purpose, I = what the model did). &sect;11 is paper-level rather than per-parameter, so it is never shaded for agreement and is hidden by every filter except All.');
  PAPERS.forEach(p => {{
    let v = '<span style="color:' + p.fg + '">' + (p.code_name || '') + ' ' + (p.code_version || '') +
            ' &middot; ' + p.arxiv + '</span><br><b>' + (p.title || '') + '</b>';
    if (p.systems) v += '<br><br><b>Systems covered:</b> ' + p.systems +
      (p.systems_detail ? ' &mdash; ' + p.systems_detail : '');
    if (p.purpose) v += '<br><br><b>Purpose:</b> ' + p.purpose;
    if (p.summary) v += '<br><br><b>What the model did:</b> ' + p.summary;
    if (p.extra) v += '<br><br><span style="color:var(--faint)">' + p.extra + '</span>';
    if (p.deferral) v += '<br><em class="q">Scope statement: &ldquo;' + p.deferral + '&rdquo;</em>';
    R(p.cite, v);
  }});

  H('FULL PARAMETER LIST');
  R('Contents', D.flags.length + ' rows &mdash; ' + D.nPhys + ' physical parameters and ' + D.nAdm +
    ' administrative / output options &mdash; taken verbatim from <code>COMPAS_Parameter_Reference.xlsx</code>, one column per displayed paper. ' +
    D.nSpec + ' rows carry a value from at least one paper; the rest are NOT SPECIFIED throughout. That is why it sits behind the corner button rather than in the main table.');
  R('Default column caveat', 'The COMPAS default column reflects repository commit <code>5f7cc502</code> (2026-08-20), i.e. <em>current</em> COMPAS. Several defaults have changed since these papers &mdash; <code>remnant-mass-prescription</code> and <code>kick-magnitude-distribution</code> are both now <code>MULLERMANDEL</code>. Do not read it as any paper&rsquo;s assumption.');

  H('ADDING A PAPER');
  R('How', 'Copy <code>papers/_TEMPLATE.py</code> to <code>papers/&lt;id&gt;.py</code>, fill in PAPER / ENTRIES / FLAGS / SUBMODELS / COSMIC, drop the paper&rsquo;s <code>pdftotext</code> output beside it, and run <code>python3 build.py</code>. The generator discovers the file, assigns a colour, widens the grid, adds the chip, the spreadsheet columns and the notes entry, and re-verifies every quote.');
  R('Structure', 'Section set, column layout, colour language, sub-model cards and notes structure adapted from the COMPAS &times; COSMIC &times; SEVN model-assumptions comparison.');

  document.getElementById('notes-grid').innerHTML = rows.join('');
}}

/* ───────── copy-to-clipboard ───────── */
function toast(msg) {{
  const t = document.getElementById('toast');
  t.textContent = msg; t.classList.add('show');
  clearTimeout(t._h); t._h = setTimeout(() => t.classList.remove('show'), 1400);
}}
document.addEventListener('click', e => {{
  const el = e.target.closest('.cquo');
  if (!el || !el.dataset.q) return;
  const txt = el.dataset.q;
  const done = () => {{ el.classList.add('copied'); toast('Quote copied — paste into Ctrl-F'); setTimeout(() => el.classList.remove('copied'), 1400); }};
  if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(txt).then(done, fallback);
  else fallback();
  function fallback() {{
    const ta = document.createElement('textarea');
    ta.value = txt; ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select();
    try {{ document.execCommand('copy'); done(); }} catch (_) {{ toast('Copy blocked — select the text manually'); }}
    document.body.removeChild(ta);
  }}
}});

/* ───────── chrome ───────── */
function applyHeaderOffset() {{
  const mh = document.getElementById('masthead'), tb = document.getElementById('tabbar');
  tb.style.top = mh.offsetHeight + 'px';
  const h = mh.offsetHeight + tb.offsetHeight;
  document.documentElement.style.setProperty('--hdr-h', h + 'px');
  document.querySelectorAll('.panel').forEach(p => p.style.paddingTop = (h + 10) + 'px');
}}
function switchTab(id, btn) {{
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  document.getElementById('panel-' + id).classList.add('active');
  const btns = document.querySelectorAll('.tbtn');
  btns.forEach(b => b.classList.remove('active'));
  if (btn && btn.classList.contains('tbtn')) btn.classList.add('active');
  else {{ const m = {{main:0, papers:1, sub:2, notes:3}}; if (m[id] !== undefined) btns[m[id]].classList.add('active'); }}
  document.getElementById('fullbtn').classList.toggle('on', id === 'full');
  if (id === 'main') syncZoomHeight();
  window.scrollTo(0, 0);
}}
function syncZoomHeight() {{
  const wrap = document.querySelector('.zoom-wrap'), inner = document.getElementById('zoom-inner');
  if (!inner.offsetParent) {{ wrap.style.height = ''; return; }}
  const prev = inner.style.transform;
  inner.style.transform = 'none';
  const h = inner.getBoundingClientRect().height;
  inner.style.transform = prev;
  wrap.style.height = h ? (h * z + 24) + 'px' : '';
}}
let z = 1.0;
function setZoom(v) {{
  z = Math.min(3, Math.max(0.25, v));
  document.getElementById('zoom-inner').style.transform = 'scale(' + z + ')';
  document.getElementById('zslider').value = z;
  document.getElementById('zlabel').textContent = Math.round(z * 100) + '%';
  syncZoomHeight();
}}
function adjustZoom(d) {{ setZoom(z + d); }}
function resetZoom() {{ setZoom(1.0); }}

window.addEventListener('resize', applyHeaderOffset);
var _bWrap = document.getElementById('badgesWrap'),
    _bStrip = document.getElementById('badges'),
    _bBtn   = document.getElementById('badgesToggle');
function syncBadges() {{
  var open = _bStrip.classList.contains('open');
  _bStrip.classList.remove('open');
  var overflows = _bStrip.scrollHeight - _bStrip.clientHeight > 2;
  if (open) _bStrip.classList.add('open');
  _bWrap.classList.toggle('clipped', overflows || open);
  _bBtn.textContent = open ? '\u25b4 collapse' : '\u25be all {n_papers} papers';
}}
_bBtn.addEventListener('click', function (e) {{
  e.stopPropagation(); _bStrip.classList.toggle('open'); syncBadges(); applyHeaderOffset();
}});
window.addEventListener('resize', syncBadges);
renderChips(); renderMain(); renderPapers(); renderSub(); renderFull(); renderNotes();
syncBadges(); applyHeaderOffset(); setZoom(1.0);
</script>
</body>
</html>
"""
